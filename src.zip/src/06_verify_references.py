#!/usr/bin/env python3
"""
Step 4 (Part 1): Programmatic Bibliographic Reference Builder & Verifier.

Queries NCBI PubMed E-utilities (esearch, esummary, efetch XML) and CrossRef REST API
(https://api.crossref.org/works/<doi>), strictly sleeping >= 0.45s between HTTP requests,
to build and verify 100% of references in results/verified_references.json.

Usage:
  python src/06_verify_references.py               # Build & verify results/verified_references.json
  python src/06_verify_references.py --verify-only # Re-verify existing results/verified_references.json
"""

import argparse
import datetime
import html
import json
import os
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

MIN_SLEEP_SEC = 0.48
USER_AGENT = "BiblioScienceVerifier/1.0 (mailto:cpeb4_research_audit@proton.me)"
CROSSREF_MAILTO = "cpeb4_research_audit@proton.me"

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = PROJECT_ROOT / "results" / "verified_references.json"

_LAST_HTTP_TIME = 0.0


def rate_limited_get(url: str, timeout: int = 30, max_retries: int = 4) -> str:
    """Perform HTTP GET respecting MIN_SLEEP_SEC >= 0.45s between requests with 429/503 backoff."""
    global _LAST_HTTP_TIME
    for attempt in range(max_retries):
        elapsed = time.monotonic() - _LAST_HTTP_TIME
        if elapsed < MIN_SLEEP_SEC:
            time.sleep(MIN_SLEEP_SEC - elapsed)
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            _LAST_HTTP_TIME = time.monotonic()
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 503) and attempt < max_retries - 1:
                backoff = (attempt + 1) * 2.5
                print(f"[WARN] HTTP {exc.code} on {url}; backing off {backoff:.1f}s", file=sys.stderr)
                time.sleep(backoff)
            else:
                raise
        except urllib.error.URLError:
            if attempt < max_retries - 1:
                time.sleep(2.0)
            else:
                raise
    raise RuntimeError(f"Failed HTTP GET after {max_retries} attempts: {url}")


def normalize_text(text: str) -> str:
    """Fold Unicode accents and lowercase alphanumeric tokens for robust fuzzy comparison."""
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def token_jaccard(a: str, b: str) -> float:
    ta = set(normalize_text(a).split())
    tb = set(normalize_text(b).split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def token_overlap_ratio(expected: str, observed: str) -> float:
    te = set(normalize_text(expected).split())
    to = set(normalize_text(observed).split())
    if not te:
        return 0.0
    return len(te & to) / len(te)


# Curated registry of candidate manuscript references (all PMIDs/DOIs verified live against APIs)
REFERENCE_SPECS = [
    # 1. CPEB4 microexon 4 in ASD, SCZ, Biophysics, and SSO Therapy
    {
        "key": "parras_2018",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "30111840",
        "doi": "10.1038/s41586-018-0423-5",
        "expected_first_author": "Parras",
        "expected_year": "2018",
        "expected_title_hint": "Autism-like phenotype and risk gene mRNA deadenylation by CPEB4 mis-splicing",
        "key_claim_supported": "Decreased inclusion of neuronal-specific CPEB4 microexon 4 in idiopathic ASD brains drives poly(A)-tail shortening and reduced protein expression of high-confidence ASD risk genes, and CPEB4-delta4 mice recapitulate ASD-like neuroanatomical, electrophysiological, and behavioral phenotypes.",
    },
    {
        "key": "olla_2023",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "36958377",
        "doi": "10.1016/j.biopsych.2023.03.010",
        "expected_first_author": "Olla",
        "expected_year": "2023",
        "expected_title_hint": "Pathogenic Mis-splicing of CPEB4 in Schizophrenia",
        "key_claim_supported": "SCZ-associated genes are enriched among CPEB4-binder transcripts, CPEB4 microexon 4 inclusion is decreased in antipsychotic-free SCZ postmortem brains (correlating with reduced target protein levels), and mild CPEB4-delta4 overexpression in mice induces SCZ-linked molecular and behavioral phenotypes.",
    },
    {
        "key": "garcia_cabau_2025",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "39633052",
        "doi": "10.1038/s41586-024-08289-w",
        "expected_first_author": "Garcia-Cabau",
        "expected_year": "2025",
        "expected_title_hint": "Mis-splicing of a neuronal microexon promotes CPEB4 aggregation in ASD",
        "key_claim_supported": "Neuronal CPEB4 forms biomolecular condensates that dissolve upon depolarization to switch from translational repression to activation; heterotypic interactions between microexon 4 and a histidine cluster prevent irreversible homotypic aggregation, explaining the dominant-negative effect of modest me4 loss.",
    },
    {
        "key": "martinez_pizarro_2025",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "41267683",
        "doi": "10.1093/narmme/ugaf035",
        "expected_first_author": "Martinez-Pizarro",
        "expected_year": "2025",
        "expected_title_hint": "Oligonucleotides targeting the 3' splice site downstream of a microexon as an innovative therapy for autism",
        "key_claim_supported": "Splice-switching antisense oligonucleotides (SSOs) targeting the downstream 3' splice site of CPEB4 exon 5 increase CPEB4 microexon 4 inclusion in a dose-dependent manner and restore protein levels of CPEB4 target ASD risk genes such as AUTS2 and DYRK1A.",
    },
    {
        "key": "huang_2025",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "39824163",
        "doi": "10.1016/j.molcel.2024.12.022",
        "expected_first_author": "Huang",
        "expected_year": "2025",
        "expected_title_hint": "Microexon in action: How tiny fragments in a protein tune function, drive disease",
        "key_claim_supported": "Commentary highlighting how inclusion/exclusion of the 8-residue microexon 4 within the intrinsically disordered region of CPEB4 tunes phase separation and condensate reversibility in neurodevelopmental disease.",
    },
    {
        "key": "guillen_boixet_2016",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "27802129",
        "doi": "10.7554/eLife.19298",
        "expected_first_author": "Guillen-Boixet",
        "expected_year": "2016",
        "expected_title_hint": "CPEB4 is regulated during cell cycle by ERK2/Cdk1-mediated phosphorylation and its assembly into liquid-like droplets",
        "key_claim_supported": "CPEB4 N-terminal intrinsically disordered domain mediates assembly into inactive liquid-like droplets/condensates that dissolve into active monomers upon multisite ERK2/Cdk1 phosphorylation.",
    },
    {
        "key": "afroz_2014",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "24990967",
        "doi": "10.1101/gad.241133.114",
        "expected_first_author": "Afroz",
        "expected_year": "2014",
        "expected_title_hint": "A fly trap mechanism provides sequence-specific RNA recognition by CPEB proteins",
        "key_claim_supported": "Structural characterization of CPEB4 tandem RNA recognition motifs (RRMs) binding U-rich cytoplasmic polyadenylation element (CPE) sequences in target 3' UTRs via a fly-trap mechanism.",
    },
    {
        "key": "novoa_2010",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "20364142",
        "doi": "10.1038/ncb2046",
        "expected_first_author": "Novoa",
        "expected_year": "2010",
        "expected_title_hint": "Mitotic cell-cycle progression is regulated by CPEB1 and CPEB4-dependent translational control",
        "key_claim_supported": "Foundational demonstration of sequential CPEB1-to-CPEB4 cytoplasmic polyadenylation and translational activation waves.",
    },
    {
        "key": "ortiz_zapater_2012",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "22138752",
        "doi": "10.1038/nm.2540",
        "expected_first_author": "Ortiz-Zapater",
        "expected_year": "2012",
        "expected_title_hint": "Key contribution of CPEB4-mediated translational control to cancer progression",
        "key_claim_supported": "Demonstrates CPEB4-mediated cytoplasmic polyadenylation and translational reprogramming of target mRNA networks.",
    },
    {
        "key": "ivshina_2014",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "25068488",
        "doi": "10.1146/annurev-cellbio-101011-155831",
        "expected_first_author": "Ivshina",
        "expected_year": "2014",
        "expected_title_hint": "Cytoplasmic polyadenylation element binding proteins in development, health, and disease",
        "key_claim_supported": "Comprehensive review of CPEB1-4 family molecular mechanisms in cytoplasmic polyadenylation, synaptic plasticity, development, and disease.",
    },
    {
        "key": "shin_2016",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "27381259",
        "doi": "10.1038/srep29395",
        "expected_first_author": "Shin",
        "expected_year": "2016",
        "expected_title_hint": "Impaired neurodevelopment by the low complexity domain of CPEB4 reveals a convergent pathway with neurodegeneration",
        "key_claim_supported": "Shows that the unstructured low-complexity domain (LCD) of CPEB4 drives self-assembly and can impair neurodevelopment when dysregulated.",
    },
    {
        "key": "tseng_2017",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "29166615",
        "doi": "10.1016/j.celrep.2017.10.100",
        "expected_first_author": "Tseng",
        "expected_year": "2017",
        "expected_title_hint": "Olfactory-Experience- and Developmental-Stage-Dependent Control of CPEB4 Regulates c-Fos mRNA Translation for Granule Cell Survival",
        "key_claim_supported": "Demonstrates developmental-stage- and activity-dependent CPEB4 translational control in mice: CPEB4 acts as a survival factor exclusively for early postnatal (first 2 weeks) olfactory bulb granule cells via c-Fos mRNA translation, disengaging in adult granule cells.",
    },
    {
        "key": "pico_2021",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "34586830",
        "doi": "10.1126/scitranslmed.abe7104",
        "expected_first_author": "Pico",
        "expected_year": "2021",
        "expected_title_hint": "CPEB alteration and aberrant transcriptome-polyadenylation lead to a treatable SLC19A3 deficiency in Huntington's disease",
        "key_claim_supported": "Establishes that altered CPEB4 isoform/protein balance and aberrant transcriptome poly(A)-tail length contribute to neuropathology beyond ASD.",
    },
    {
        "key": "gonzalez_paz_2026",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "41581680",
        "doi": "10.1016/j.mcn.2026.104072",
        "expected_first_author": "Gonzalez-Paz",
        "expected_year": "2026",
        "expected_title_hint": "Modeling the functional impact of CPEB3 and CPEB4 dysregulation in autism: A theoretical-computational framework",
        "key_claim_supported": "Theoretical-computational model integrating transcriptomic expression and coarse-grained MD simulations of CPEB3/CPEB4 aggregation in ASD (showing CPEB4 forms more stable condensates than CPEB3), without modeling developmental timing windows or ASD-vs-SCZ polygenic bifurcation.",
    },
    {
        "key": "alvarado_2026",
        "domain": "CPEB4_ASD_SCZ_Biophysics_SSO",
        "pmid": "42476190",
        "doi": "10.1088/1478-3975/ae8d70",
        "expected_first_author": "Alvarado",
        "expected_year": "2026",
        "expected_title_hint": "A cross-scale physical framework for transcription-associated CPEB4 microexon susceptibility and crowding-enhanced isoform self-association: toward a biophysical mechanism of idiopathic autism",
        "key_claim_supported": "Cross-scale physical model linking transcriptional kinetic pressure to CPEB4 me4 skipping susceptibility and crowding-enhanced delta-4 self-association in idiopathic ASD, without modeling neurodevelopmental timing windows or ASD-vs-SCZ polygenic background.",
    },
    # 2. Neuronal Microexons, Splicing & Postmortem Transcriptomics
    {
        "key": "irimia_2014",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "25525873",
        "doi": "10.1016/j.cell.2014.11.035",
        "expected_first_author": "Irimia",
        "expected_year": "2014",
        "expected_title_hint": "A highly conserved program of neuronal microexons is misregulated in autistic brains",
        "key_claim_supported": "Discovery of a conserved 3-27 nt (especially 3-15 nt) neuronal microexon splicing program regulated by nSR100/SRRM4 that modulates protein interaction domains and is broadly misregulated in ASD brains.",
    },
    {
        "key": "quesnel_vallieres_2016",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "27984743",
        "doi": "10.1016/j.molcel.2016.11.033",
        "expected_first_author": "Quesnel-Vallieres",
        "expected_year": "2016",
        "expected_title_hint": "Misregulation of an Activity-Dependent Splicing Network as a Common Mechanism Underlying Autism Spectrum Disorders",
        "key_claim_supported": "Demonstrates that nSR100/SRRM4 and its target neuronal microexon splicing program are activity-dependent and causally linked to autistic-like synaptic and behavioral phenotypes in mice.",
    },
    {
        "key": "gonatopoulos_pournatzis_2020",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "32535349",
        "doi": "10.1016/j.gde.2020.03.007",
        "expected_first_author": "Gonatopoulos-Pournatzis",
        "expected_year": "2020",
        "expected_title_hint": "Microexons: at the nexus of nervous system development, behaviour and autism spectrum disorder",
        "key_claim_supported": "Review synthesizing how SRRM4-regulated neuronal microexons remodel protein-protein interaction surfaces during nervous system development and converge on ASD pathophysiology.",
    },
    {
        "key": "tapial_2017",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "28855263",
        "doi": "10.1101/gr.220962.117",
        "expected_first_author": "Tapial",
        "expected_year": "2017",
        "expected_title_hint": "An atlas of alternative splicing profiles and functional associations reveals new regulatory programs and genes that simultaneously express multiple major isoforms",
        "key_claim_supported": "VastDB resource providing tissue- and cell-type-resolved alternative splicing and microexon inclusion profiles across vertebrate tissues including brain.",
    },
    {
        "key": "parikshak_2016",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "27919067",
        "doi": "10.1038/nature20612",
        "expected_first_author": "Parikshak",
        "expected_year": "2016",
        "expected_title_hint": "Genome-wide changes in lncRNA, splicing, and regional gene expression patterns in autism",
        "key_claim_supported": "Postmortem cortical transcriptomic profiling in ASD showing widespread alternative splicing alterations, microexon misregulation, and attenuation of cortical regional identity.",
    },
    {
        "key": "gandal_2018",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "30545856",
        "doi": "10.1126/science.aat8127",
        "expected_first_author": "Gandal",
        "expected_year": "2018",
        "expected_title_hint": "Transcriptome-wide isoform-level dysregulation in ASD, schizophrenia, and bipolar disorder",
        "key_claim_supported": "PsychENCODE cross-disorder analysis of 1,695 postmortem brains showing that isoform-level and splicing dysregulation capture the largest disease effects and genetic enrichments across ASD, SCZ, and bipolar disorder.",
    },
    {
        "key": "li_2018",
        "domain": "Neuronal_Microexons_Splicing_Transcriptomics",
        "pmid": "30545854",
        "doi": "10.1126/science.aat7615",
        "expected_first_author": "Li",
        "expected_year": "2018",
        "expected_title_hint": "Integrative functional genomic analysis of human brain development and neuropsychiatric risks",
        "key_claim_supported": "PsychENCODE developmental human brain transcriptomic and epigenomic atlas spanning prenatal through adult stages, revealing developmental timing windows of neuropsychiatric risk gene expression.",
    },
    # 3. Biomolecular Condensates & Liquid-to-Solid Aging
    {
        "key": "banani_2017",
        "domain": "Biomolecular_Condensates_Aging",
        "pmid": "28225081",
        "doi": "10.1038/nrm.2017.7",
        "expected_first_author": "Banani",
        "expected_year": "2017",
        "expected_title_hint": "Biomolecular condensates: organizers of cellular biochemistry",
        "key_claim_supported": "Foundational framework defining biomolecular condensates, multivalent scaffold-client phase separation, and kinetic/thermodynamic regulation of membraneless organelles.",
    },
    {
        "key": "shin_brangwynne_2017",
        "domain": "Biomolecular_Condensates_Aging",
        "pmid": "28935776",
        "doi": "10.1126/science.aaf4382",
        "expected_first_author": "Shin",
        "expected_year": "2017",
        "expected_title_hint": "Liquid phase condensation in cell physiology and disease",
        "key_claim_supported": "Synthesizes physical principles of intracellular liquid-liquid phase separation, viscoelastic condensate maturation, and transitions to pathological solid-like aggregates.",
    },
    {
        "key": "alberti_hyman_2021",
        "domain": "Biomolecular_Condensates_Aging",
        "pmid": "33510441",
        "doi": "10.1038/s41580-020-00326-6",
        "expected_first_author": "Alberti",
        "expected_year": "2021",
        "expected_title_hint": "Biomolecular condensates at the nexus of cellular stress, protein aggregation disease and ageing",
        "key_claim_supported": "Details how failure to control condensate properties, dissolution, and proteostasis drives aberrant liquid-to-solid aging and irreversible protein aggregation.",
    },
    {
        "key": "patel_2015",
        "domain": "Biomolecular_Condensates_Aging",
        "pmid": "26317470",
        "doi": "10.1016/j.cell.2015.07.047",
        "expected_first_author": "Patel",
        "expected_year": "2015",
        "expected_title_hint": "A Liquid-to-Solid Phase Transition of the ALS Protein FUS Accelerated by Disease Mutation",
        "key_claim_supported": "Classic experimental demonstration that dynamic liquid-like RNA-binding protein droplets age over time into solid fibrous/irreversible aggregates, accelerated by disease perturbations.",
    },
    # 4. Human Neurodevelopment, Synaptogenesis & Adolescent Pruning
    {
        "key": "huttenlocher_1979",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "427544",
        "doi": "10.1016/0006-8993(79)90349-4",
        "expected_first_author": "Huttenlocher",
        "expected_year": "1979",
        "expected_title_hint": "Synaptic density in human frontal cortex - developmental changes and effects of aging",
        "key_claim_supported": "Classic quantitative electron microscopy of human middle frontal gyrus showing postnatal synaptogenesis peaking in early childhood followed by progressive synaptic elimination through adolescence.",
    },
    {
        "key": "huttenlocher_dabholkar_1997",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "9336221",
        "doi": "10.1002/(sici)1096-9861(19971020)387:2<167::aid-cne1>3.0.co;2-z",
        "expected_first_author": "Huttenlocher",
        "expected_year": "1997",
        "expected_title_hint": "Regional differences in synaptogenesis in human cerebral cortex",
        "key_claim_supported": "Demonstrates heterochronous cortical maturation in humans, with prefrontal synaptogenesis and pruning trailing sensory cortices and extending into late childhood/adolescence.",
    },
    {
        "key": "petanjek_2011",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "21788513",
        "doi": "10.1073/pnas.1105108108",
        "expected_first_author": "Petanjek",
        "expected_year": "2011",
        "expected_title_hint": "Extraordinary neoteny of synaptic spines in the human prefrontal cortex",
        "key_claim_supported": "Shows prolonged developmental overproduction and protracted adolescent-to-young-adult pruning of dendritic spines in human prefrontal cortex.",
    },
    {
        "key": "feinberg_1982",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "7187776",
        "doi": "10.1016/0022-3956(82)90038-3",
        "expected_first_author": "Feinberg",
        "expected_year": "1982",
        "expected_title_hint": "Schizophrenia: caused by a fault in programmed synaptic elimination during adolescence",
        "key_claim_supported": "Seminal hypothesis proposing that schizophrenia arises from aberrant programmed synaptic pruning during adolescent cortical maturation.",
    },
    {
        "key": "keshavan_1994",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "7932285",
        "doi": "10.1016/0022-3956(94)90009-4",
        "expected_first_author": "Keshavan",
        "expected_year": "1994",
        "expected_title_hint": "Is schizophrenia due to excessive synaptic pruning in the prefrontal cortex? The Feinberg hypothesis revisited",
        "key_claim_supported": "Synthesizes neurobiological, metabolic, and neuroimaging evidence supporting excessive prefrontal synaptic pruning during adolescence in schizophrenia.",
    },
    {
        "key": "sekar_2016",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "26814963",
        "doi": "10.1038/nature16549",
        "expected_first_author": "Sekar",
        "expected_year": "2016",
        "expected_title_hint": "Schizophrenia risk from complex variation of complement component 4",
        "key_claim_supported": "Establishes that common structural alleles increasing brain C4A expression drive schizophrenia risk and mediate postnatal complement-dependent synaptic pruning.",
    },
    {
        "key": "sellgren_2019",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "30718903",
        "doi": "10.1038/s41593-018-0334-7",
        "expected_first_author": "Sellgren",
        "expected_year": "2019",
        "expected_title_hint": "Increased synapse elimination by microglia in schizophrenia patient-derived models of synaptic pruning",
        "key_claim_supported": "Demonstrates elevated microglia-mediated synapse engulfment in schizophrenia patient-derived cellular models linked to C4 risk alleles.",
    },
    {
        "key": "kang_2011",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "22031440",
        "doi": "10.1038/nature10523",
        "expected_first_author": "Kang",
        "expected_year": "2011",
        "expected_title_hint": "Spatio-temporal transcriptome of the human brain",
        "key_claim_supported": "BrainSpan exon-level human brain developmental transcriptome dataset spanning fetal development through adulthood across brain regions.",
    },
    {
        "key": "miller_2014",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "24695229",
        "doi": "10.1038/nature13185",
        "expected_first_author": "Miller",
        "expected_year": "2014",
        "expected_title_hint": "Transcriptional landscape of the prenatal human brain",
        "key_claim_supported": "BrainSpan anatomical and transcriptional atlas of the prenatal human brain contextualizing mid-gestational neurodevelopmental gene programs.",
    },
    {
        "key": "koopmans_2019",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "31171447",
        "doi": "10.1016/j.neuron.2019.05.002",
        "expected_first_author": "Koopmans",
        "expected_year": "2019",
        "expected_title_hint": "SynGO: An Evidence-Based, Expert-Curated Knowledge Base for the Synapse",
        "key_claim_supported": "SynGO curated synaptic gene ontology distinguishing presynaptic, postsynaptic, and synapse-assembly/pruning functional compartments.",
    },
    {
        "key": "semple_2013",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "23583307",
        "doi": "10.1016/j.pneurobio.2013.04.001",
        "expected_first_author": "Semple",
        "expected_year": "2013",
        "expected_title_hint": "Brain development in rodents and humans: Identifying benchmarks of maturation and vulnerability to injury across species",
        "key_claim_supported": "Cross-species neurodevelopmental alignment benchmarks mapping rodent embryonic (e.g., E14.5), early postnatal (P7-P10), and juvenile/adolescent (P35-P42) stages onto human gestational, perinatal/early-childhood, and adolescent brain maturation windows.",
    },
    {
        "key": "workman_2013",
        "domain": "Neurodevelopment_Synaptogenesis_Pruning",
        "pmid": "23616543",
        "doi": "10.1523/JNEUROSCI.5746-12.2013",
        "expected_first_author": "Workman",
        "expected_year": "2013",
        "expected_title_hint": "Modeling transformations of neurodevelopmental sequences across mammalian species",
        "key_claim_supported": "Translating Time model fitting 271 neurodevelopmental events across 18 mammalian species to map equivalent cortical neurogenesis, axon extension, synaptogenesis, and connectivity refinement ages between rodents and humans.",
    },
    # 5. ASD, SCZ, Cross-Disorder Genetics, Epidemiology & Methodology
    {
        "key": "abrahams_2013",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "24090431",
        "doi": "10.1186/2040-2392-4-36",
        "expected_first_author": "Abrahams",
        "expected_year": "2013",
        "expected_title_hint": "SFARI Gene 2.0: a community-driven knowledgebase for the autism spectrum disorders (ASDs)",
        "key_claim_supported": "SFARI Gene curated ASD risk gene knowledgebase and evidence-scoring framework.",
    },
    {
        "key": "satterstrom_2020",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "31981491",
        "doi": "10.1016/j.cell.2019.12.036",
        "expected_first_author": "Satterstrom",
        "expected_year": "2020",
        "expected_title_hint": "Large-Scale Exome Sequencing Study Implicates Both Developmental and Functional Changes in the Neurobiology of Autism",
        "key_claim_supported": "Large-scale ASD exome sequencing (n=35,584) identifying 102 ASD risk genes enriched in gene expression regulation and neuronal communication during fetal/early brain development.",
    },
    {
        "key": "fu_2022",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "35982160",
        "doi": "10.1038/s41588-022-01104-0",
        "expected_first_author": "Fu",
        "expected_year": "2022",
        "expected_title_hint": "Rare coding variation provides insight into the genetic architecture and phenotypic context of autism",
        "key_claim_supported": "Joint rare coding and CNV analysis (n=63,237) identifying 72 ASD genes at FDR<=0.001 and 185 at FDR<=0.05.",
    },
    {
        "key": "grove_2019",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "30804558",
        "doi": "10.1038/s41588-019-0344-8",
        "expected_first_author": "Grove",
        "expected_year": "2019",
        "expected_title_hint": "Identification of common genetic risk variants for autism spectrum disorder",
        "key_claim_supported": "iPSYCH-PGC ASD GWAS meta-analysis (18,381 cases, 27,969 controls) establishing common polygenic architecture of ASD and genetic correlations.",
    },
    {
        "key": "singh_2022",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "35396579",
        "doi": "10.1038/s41586-022-04556-w",
        "expected_first_author": "Singh",
        "expected_year": "2022",
        "expected_title_hint": "Rare coding variants in ten genes confer substantial risk for schizophrenia",
        "key_claim_supported": "SCHEMA whole-exome meta-analysis (24,248 SCZ cases, 97,322 controls) implicating ultra-rare coding variants in 10 genes (and 32 at FDR<5%) enriched in synaptic formation, structure, and function.",
    },
    {
        "key": "trubetskoy_2022",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "35396580",
        "doi": "10.1038/s41586-022-04434-5",
        "expected_first_author": "Trubetskoy",
        "expected_year": "2022",
        "expected_title_hint": "Mapping genomic loci implicates genes and synaptic biology in schizophrenia",
        "key_claim_supported": "PGC3 SCZ GWAS (up to 76,755 cases, 243,649 controls) identifying 287 loci and 120 prioritized genes concentrated in excitatory and inhibitory CNS neurons and synaptic biology.",
    },
    {
        "key": "lee_2019",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "31835028",
        "doi": "10.1016/j.cell.2019.11.020",
        "expected_first_author": "Cross-Disorder",
        "expected_year": "2019",
        "expected_title_hint": "Genomic Relationships, Novel Loci, and Pleiotropic Mechanisms across Eight Psychiatric Disorders",
        "key_claim_supported": "PGC Cross-Disorder analysis across 8 psychiatric disorders (232,964 cases) demonstrating shared pleiotropic loci and genetic correlations including between ASD and SCZ.",
    },
    {
        "key": "owen_odonovan_2017",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "28941101",
        "doi": "10.1002/wps.20440",
        "expected_first_author": "Owen",
        "expected_year": "2017",
        "expected_title_hint": "Schizophrenia and the neurodevelopmental continuum:evidence from genomics",
        "key_claim_supported": "Neurodevelopmental continuum framework positing shared genetic and developmental origins across intellectual disability, ASD, and schizophrenia with divergent phenotypic expression.",
    },
    {
        "key": "chisholm_2015",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "25956249",
        "doi": "10.1016/j.neubiorev.2015.04.012",
        "expected_first_author": "Chisholm",
        "expected_year": "2015",
        "expected_title_hint": "The association between autism and schizophrenia spectrum disorders: A review of eight alternate models of co-occurrence",
        "key_claim_supported": "Evaluates elevated clinical comorbidity and shared liability models linking autism spectrum and schizophrenia spectrum disorders.",
    },
    {
        "key": "zheng_2018",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "30284394",
        "doi": "10.1002/aur.1977",
        "expected_first_author": "Zheng",
        "expected_year": "2018",
        "expected_title_hint": "Association between schizophrenia and autism spectrum disorder: A systematic review and meta-analysis",
        "key_claim_supported": "Meta-analysis of 1,950,113 participants (14,945 with ASD) demonstrating elevated schizophrenia prevalence in individuals with ASD vs controls (OR = 3.55, 95% CI: 2.08-6.05, P < 0.001) and ASD prevalence in schizophrenia ranging from 3.4% to 52%.",
    },
    {
        "key": "solmi_2022",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "34079068",
        "doi": "10.1038/s41380-021-01161-7",
        "expected_first_author": "Solmi",
        "expected_year": "2022",
        "expected_title_hint": "Age at onset of mental disorders worldwide: large-scale meta-analysis of 192 epidemiological studies",
        "key_claim_supported": "Global meta-analysis of 192 studies (n = 708,561) showing neurodevelopmental disorders peak at 5.5 years (median 12, IQR 7-16; ASD/ADHD median 8-13 years; 61.5% onset <14 y), whereas schizophrenia-spectrum disorders peak at 20.5 years (median 25, IQR 20-34; only 3% <14 y, 12.3% <18 y).",
    },
    {
        "key": "maenner_2023",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "36952288",
        "doi": "10.15585/mmwr.ss7202a1",
        "expected_first_author": "Maenner",
        "expected_year": "2023",
        "expected_title_hint": "Prevalence and Characteristics of Autism Spectrum Disorder Among Children Aged 8 Years - Autism and Developmental Disabilities Monitoring Network, 11 Sites, United States, 2020",
        "key_claim_supported": "US CDC ADDM Network 2020 surveillance estimate of 27.6 per 1,000 (2.76%, 1 in 36) children aged 8 years with ASD (male:female ratio 3.8:1; median diagnosis age 49 months).",
    },
    {
        "key": "zeidan_2022",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "35238171",
        "doi": "10.1002/aur.2696",
        "expected_first_author": "Zeidan",
        "expected_year": "2022",
        "expected_title_hint": "Global prevalence of autism: A systematic review update",
        "key_claim_supported": "Global systematic review (99 estimates from 71 studies) reporting a median global autism prevalence of 100 per 10,000 (~1.0%; range 1.09-436.0/10,000) and median male:female ratio of 4.2.",
    },
    {
        "key": "mcgrath_2008",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "18480098",
        "doi": "10.1093/epirev/mxn001",
        "expected_first_author": "McGrath",
        "expected_year": "2008",
        "expected_title_hint": "Schizophrenia: a concise overview of incidence, prevalence, and mortality",
        "key_claim_supported": "Systematic epidemiological synthesis reporting median schizophrenia incidence of 15.2/100,000, median lifetime morbid risk of 7.2/1,000 (0.72%), male:female rate ratio 1.4:1, and SMR 2.6.",
    },
    {
        "key": "charlson_2018",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "29762765",
        "doi": "10.1093/schbul/sby058",
        "expected_first_author": "Charlson",
        "expected_year": "2018",
        "expected_title_hint": "Global Epidemiology and Burden of Schizophrenia: Findings From the Global Burden of Disease Study 2016",
        "key_claim_supported": "GBD 2016 global age-standardized point prevalence of schizophrenia of 0.28% (95% UI: 0.24-0.31%), totaling 20.9 million prevalent cases in 2016.",
    },
    {
        "key": "ochoa_2023",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "36399499",
        "doi": "10.1093/nar/gkac1046",
        "expected_first_author": "Ochoa",
        "expected_year": "2023",
        "expected_title_hint": "The next-generation Open Targets Platform: reimagined, redesigned, rebuilt",
        "key_claim_supported": "Open Targets Platform providing harmonized gene-disease association evidence scores across rare and common genetic variants for cross-disorder target prioritization.",
    },
    {
        "key": "uniprot_2025",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "39552041",
        "doi": "10.1093/nar/gkae1010",
        "expected_first_author": "UniProt",
        "expected_year": "2025",
        "expected_title_hint": "UniProt: the Universal Protein Knowledgebase in 2025",
        "key_claim_supported": "UniProt Knowledgebase reference for canonical human CPEB4 isoform sequences (Q17RY0) and microexon 4 domain boundaries.",
    },
    {
        "key": "saltelli_2010",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": None,
        "doi": "10.1016/j.cpc.2009.09.018",
        "expected_first_author": "Saltelli",
        "expected_year": "2010",
        "expected_title_hint": "Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index",
        "key_claim_supported": "Sobol variance-based global sensitivity analysis estimators (first-order S_i and total-order S_Ti indices).",
    },
    {
        "key": "marino_2008",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "18572196",
        "doi": "10.1016/j.jtbi.2008.04.011",
        "expected_first_author": "Marino",
        "expected_year": "2008",
        "expected_title_hint": "A methodology for performing global uncertainty and sensitivity analysis in systems biology",
        "key_claim_supported": "Latin Hypercube Sampling and Partial Rank Correlation Coefficient (LHS-PRCC) methodology for global sensitivity analysis in nonlinear dynamical systems.",
    },
    {
        "key": "benjamini_hochberg_1995",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": None,
        "doi": "10.1111/j.2517-6161.1995.tb02031.x",
        "expected_first_author": "Benjamini",
        "expected_year": "1995",
        "expected_title_hint": "Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing",
        "key_claim_supported": "Benjamini-Hochberg step-up procedure for false discovery rate (FDR) control across multiple hypothesis tests.",
    },
    {
        "key": "akaike_1974",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": None,
        "doi": "10.1109/tac.1974.1100705",
        "expected_first_author": "Akaike",
        "expected_year": "1974",
        "expected_title_hint": "A new look at the statistical model identification",
        "key_claim_supported": "Akaike Information Criterion (AIC) for statistical model selection.",
    },
    {
        "key": "schwarz_1978",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": None,
        "doi": "10.1214/aos/1176344136",
        "expected_first_author": "Schwarz",
        "expected_year": "1978",
        "expected_title_hint": "Estimating the Dimension of a Model",
        "key_claim_supported": "Bayesian Information Criterion (BIC) for penalized model selection.",
    },
    {
        "key": "wagenmakers_farrell_2004",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": "15117008",
        "doi": "10.3758/bf03206482",
        "expected_first_author": "Wagenmakers",
        "expected_year": "2004",
        "expected_title_hint": "AIC model selection using Akaike weights",
        "key_claim_supported": "Information-theoretic Akaike weights (w_i) for quantifying relative likelihood among competing mechanistic models.",
    },
    {
        "key": "burnham_anderson_2004",
        "domain": "Genetics_Epidemiology_Methodology",
        "pmid": None,
        "doi": "10.1177/0049124104268644",
        "expected_first_author": "Burnham",
        "expected_year": "2004",
        "expected_title_hint": "Multimodel Inference: Understanding AIC and BIC in Model Selection",
        "key_claim_supported": "Multimodel inference framework comparing AIC and BIC delta-thresholds and model-averaging criteria.",
    },
]


def pubmed_esearch_pmid(pmid: str) -> bool:
    """Confirm PMID exists via NCBI E-utilities esearch (with retry on transient empty backend response)."""
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={urllib.parse.quote(pmid + '[PMID]')}&retmode=json"
    for attempt in range(3):
        data = json.loads(rate_limited_get(url))
        if str(pmid) in data.get("esearchresult", {}).get("idlist", []):
            return True
        if attempt < 2:
            time.sleep(1.5)
    return False


def pubmed_esummary_batch(pmids: list[str]) -> dict[str, dict]:
    """Fetch NCBI E-utilities esummary JSON in batches of 20."""
    results = {}
    for i in range(0, len(pmids), 20):
        chunk = pmids[i : i + 20]
        url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id={','.join(chunk)}&retmode=json"
        data = json.loads(rate_limited_get(url)).get("result", {})
        for pmid in chunk:
            if pmid in data:
                results[pmid] = data[pmid]
    return results


def pubmed_efetch_batch(pmids: list[str]) -> dict[str, dict]:
    """Fetch and parse NCBI E-utilities efetch XML in batches of 20."""
    results = {}
    for i in range(0, len(pmids), 20):
        chunk = pmids[i : i + 20]
        url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={','.join(chunk)}&retmode=xml"
        root = ET.fromstring(rate_limited_get(url))
        for art in root.findall(".//PubmedArticle"):
            pmid = (art.findtext(".//MedlineCitation/PMID") or "").strip()
            title_el = art.find(".//Article/ArticleTitle")
            title = "".join(title_el.itertext()).strip() if title_el is not None else ""
            journal_ta = (art.findtext(".//MedlineCitation/MedlineJournalInfo/MedlineTA") or "").strip()
            journal_iso = (art.findtext(".//Article/Journal/ISOAbbreviation") or "").strip()
            year = (
                art.findtext(".//Article/Journal/JournalIssue/PubDate/Year")
                or art.findtext(".//Article/Journal/JournalIssue/PubDate/MedlineDate")
                or ""
            ).strip()
            vol = (art.findtext(".//Article/Journal/JournalIssue/Volume") or "").strip()
            issue = (art.findtext(".//Article/Journal/JournalIssue/Issue") or "").strip()
            pages = (art.findtext(".//Article/Pagination/MedlinePgn") or "").strip()

            pii = ""
            doi = ""
            for eloc in art.findall(".//Article/ELocationID"):
                eid_type = eloc.attrib.get("EIdType", "")
                if eid_type == "pii" and not pii:
                    pii = (eloc.text or "").strip()
                elif eid_type == "doi" and not doi:
                    doi = (eloc.text or "").strip()
            for aid in art.findall(".//PubmedData/ArticleIdList/ArticleId"):
                if aid.attrib.get("IdType") == "doi" and (aid.text or "").strip():
                    doi = aid.text.strip()

            authors = []
            for au in art.findall(".//Article/AuthorList/Author"):
                ln = au.findtext("LastName")
                ini = au.findtext("Initials")
                cn = au.findtext("CollectiveName")
                if ln:
                    name = f"{ln.strip()} {(ini or '').strip()}".strip()
                    authors.append(name)
                elif cn:
                    cleaned_cn = re.sub(r"\.\s*Electronic address:.*$", "", cn.strip()).strip()
                    if cleaned_cn and cleaned_cn not in authors:
                        authors.append(cleaned_cn)

            abs_parts = []
            for ab in art.findall(".//Article/Abstract/AbstractText"):
                lbl = ab.attrib.get("Label")
                txt = "".join(ab.itertext()).strip()
                if txt:
                    abs_parts.append(f"{lbl}: {txt}" if lbl else txt)
            abstract = " ".join(abs_parts)

            results[pmid] = {
                "pmid": pmid,
                "doi": doi,
                "authors": authors,
                "title": title,
                "journal_abbrev": journal_ta or journal_iso.replace(".", ""),
                "year": year,
                "volume": vol,
                "issue": issue,
                "pages": pages or pii,
                "abstract": abstract,
            }
    return results


def crossref_fetch_doi(doi: str) -> dict:
    """Fetch metadata from CrossRef REST API /works/<doi>."""
    encoded = urllib.parse.quote(doi, safe="")
    url = f"https://api.crossref.org/works/{encoded}?mailto={CROSSREF_MAILTO}"
    raw = json.loads(rate_limited_get(url))
    msg = raw.get("message", {})

    title = html.unescape((msg.get("title") or [""])[0])
    subtitle = html.unescape((msg.get("subtitle") or [""])[0])
    if subtitle and subtitle.lower() not in title.lower():
        full_title = f"{title}: {subtitle}"
    else:
        full_title = title

    authors = []
    for a in msg.get("author", []):
        family = (a.get("family") or "").strip()
        given = (a.get("given") or "").strip()
        name = (a.get("name") or "").strip()
        if family:
            initials = "".join(part[0].upper() for part in re.split(r"[\s.-]+", given) if part)
            authors.append(f"{family} {initials}".strip())
        elif name:
            authors.append(name)

    year = None
    for key in ("published-print", "published-online", "issued", "created"):
        dp = msg.get(key, {}).get("date-parts")
        if dp and dp[0] and dp[0][0]:
            year = str(dp[0][0])
            break

    short_titles = [html.unescape(t) for t in (msg.get("short-container-title") or [])]
    full_titles = [html.unescape(t) for t in (msg.get("container-title") or [])]
    journal = (short_titles[0] if short_titles else (full_titles[0] if full_titles else "")).replace(".", "").strip()
    # Clean standard CrossRef journal abbreviations when PubMed isn't available
    journal_overrides = {
        "J R Stat Soc Series B": "J R Stat Soc Series B Stat Methodol",
        "Journal of the Royal Statistical Society Series B: Statistical Methodology": "J R Stat Soc Series B Stat Methodol",
        "IEEE Trans Automat Contr": "IEEE Trans Automat Contr",
        "Ann Statist": "Ann Stat",
        "Computer Physics Communications": "Comput Phys Commun",
        "Sociological Methods & Research": "Sociol Methods Res",
    }
    journal = journal_overrides.get(journal, journal)

    abstract_raw = msg.get("abstract") or ""
    abstract_clean = re.sub(r"<[^>]+>", " ", abstract_raw)
    abstract_clean = re.sub(r"\s+", " ", abstract_clean).strip()

    return {
        "doi": msg.get("DOI", doi),
        "authors": authors,
        "title": full_title.strip(),
        "journal_abbrev": journal,
        "year": year or "",
        "print_year": str((msg.get("published-print", {}).get("date-parts") or [[""]])[0][0] or ""),
        "volume": str(msg.get("volume") or "").strip(),
        "issue": str(msg.get("issue") or "").strip(),
        "pages": str(msg.get("page") or msg.get("article-number") or "").strip(),
        "abstract": abstract_clean,
    }


def format_vancouver(authors: list[str], title: str, journal: str, year: str, volume: str, issue: str, pages: str, doi: str) -> str:
    """Format exact Nature/Vancouver citation string: Authors (up to 6, then et al.). Title. Journal. Year;Vol(Issue):Pages. doi:XXX"""
    if len(authors) > 6:
        author_str = ", ".join(authors[:6]) + ", et al."
    else:
        author_str = ", ".join(authors)
    if not author_str.endswith("."):
        author_str += "."

    clean_title = re.sub(r"\s+", " ", title).strip()
    if not clean_title.endswith((".", "?", "!")):
        clean_title += "."

    clean_journal = journal.rstrip(".")
    loc = year
    if volume:
        loc += f";{volume}"
        if issue:
            loc += f"({issue})"
        if pages:
            loc += f":{pages}"
    elif pages:
        loc += f":{pages}"
    loc += "."

    doi_part = f" doi:{doi}" if doi else ""
    return f"{author_str} {clean_title} {clean_journal}. {loc}{doi_part}"


def verify_and_build(output_path: Path) -> int:
    pmids = [spec["pmid"] for spec in REFERENCE_SPECS if spec.get("pmid")]
    print(f"Querying NCBI PubMed efetch & esummary for {len(pmids)} PMIDs (rate limit >= {MIN_SLEEP_SEC}s)...")
    efetch_map = pubmed_efetch_batch(pmids)
    esummary_map = pubmed_esummary_batch(pmids)

    verified_refs = {}
    failures = []

    for idx, spec in enumerate(REFERENCE_SPECS, 1):
        key = spec["key"]
        pmid = spec.get("pmid")
        doi = spec.get("doi")

        pm_data = efetch_map.get(pmid) if pmid else None
        es_data = esummary_map.get(pmid) if pmid else None
        cr_data = None

        # Exercise esearch verification for a subset or any missing/cross-checked PMID
        esearch_ok = True
        if pmid and pm_data is None:
            esearch_ok = pubmed_esearch_pmid(pmid)

        if pmid and not pm_data:
            failures.append((key, f"PMID {pmid} not returned by efetch"))
            continue

        resolved_doi = doi or (pm_data.get("doi") if pm_data else "")
        if resolved_doi:
            try:
                cr_data = crossref_fetch_doi(resolved_doi)
            except Exception as exc:
                failures.append((key, f"CrossRef lookup failed for DOI {resolved_doi}: {exc}"))
                continue

        # Merge authoritative metadata (PubMed primary for indexed biomedical papers, CrossRef supplements missing print year/pages; CrossRef primary for non-PubMed)
        if pm_data:
            authors = pm_data["authors"]
            title = pm_data["title"]
            journal = pm_data["journal_abbrev"]
            year = pm_data["year"]
            # If Epub year precedes print year by 1 (e.g., Ortiz-Zapater 2011 epub / 2012 print Vol 18(1)), use print year when matching expected
            if cr_data and cr_data.get("print_year") and year != cr_data["print_year"]:
                if cr_data["print_year"] == spec["expected_year"]:
                    year = cr_data["print_year"]
            volume = pm_data["volume"] or (cr_data.get("volume", "") if cr_data else "")
            issue = pm_data["issue"] or (cr_data.get("issue", "") if cr_data else "")
            pages = pm_data["pages"] or (cr_data.get("pages", "") if cr_data else "")
            abstract = pm_data["abstract"] or (cr_data.get("abstract", "") if cr_data else "")
            source = "PubMed+CrossRef" if cr_data else "PubMed"
        else:
            authors = cr_data["authors"]
            title = cr_data["title"]
            journal = cr_data["journal_abbrev"]
            year = cr_data["year"]
            volume = cr_data["volume"]
            issue = cr_data["issue"]
            pages = cr_data["pages"]
            abstract = cr_data["abstract"]
            source = "CrossRef"

        # Validation checks
        title_overlap = token_overlap_ratio(spec["expected_title_hint"], title)
        first_author = authors[0] if authors else ""
        author_match = normalize_text(spec["expected_first_author"]).split()[0] in normalize_text(first_author)
        year_ok = spec["expected_year"] in year or (
            year.isdigit() and abs(int(year) - int(spec["expected_year"])) <= 1
        )
        cr_title_ok = True
        if pm_data and cr_data:
            cr_title_ok = token_overlap_ratio(title, cr_data["title"]) >= 0.65

        esummary_ok = True
        if pmid and es_data:
            esummary_ok = token_overlap_ratio(title, es_data.get("title", "")) >= 0.65

        passed = bool(
            authors
            and title
            and journal
            and year
            and resolved_doi
            and title_overlap >= 0.70
            and author_match
            and year_ok
            and cr_title_ok
            and esummary_ok
            and esearch_ok
        )

        if not passed:
            failures.append((
                key,
                f"Validation failed: overlap={title_overlap:.2f}, author_match={author_match} ({first_author}), "
                f"year_ok={year_ok} ({year} vs {spec['expected_year']}), cr_title_ok={cr_title_ok}, esum_ok={esummary_ok}",
            ))
            continue

        vancouver = format_vancouver(authors, title, journal, year, volume, issue, pages, resolved_doi)

        verified_refs[key] = {
            "key": key,
            "domain": spec["domain"],
            "pmid": pmid,
            "doi": resolved_doi,
            "authors": authors,
            "first_author": first_author,
            "title": title,
            "journal_abbrev": journal,
            "year": year,
            "volume": volume or None,
            "issue": issue or None,
            "pages": pages or None,
            "vancouver_citation": vancouver,
            "abstract": abstract,
            "key_claim_supported": spec["key_claim_supported"],
            "verified": True,
            "verification_source": source,
            "verification_checks": {
                "title_token_overlap": round(title_overlap, 4),
                "author_match": author_match,
                "year_match": year_ok,
                "crossref_title_match": cr_title_ok,
                "esummary_title_match": esummary_ok,
            },
        }
        print(f"[{idx:02d}/{len(REFERENCE_SPECS)}] VERIFIED ({source}): {key} -> {vancouver[:95]}...")

    if failures:
        print("\nFAILURES DETECTED:", file=sys.stderr)
        for k, msg in failures:
            print(f"  - {k}: {msg}", file=sys.stderr)
        return 1

    payload = {
        "metadata": {
            "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "verifier_script": "src/06_verify_references.py",
            "total_references": len(REFERENCE_SPECS),
            "verified_count": len(verified_refs),
            "verification_rate": 1.0,
            "apis_used": [
                "NCBI PubMed E-utilities (esearch, esummary, efetch XML)",
                "CrossRef REST API (https://api.crossref.org/works/<doi>)",
            ],
        },
        "references": verified_refs,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)

    print(f"\nSUCCESS: {len(verified_refs)}/{len(REFERENCE_SPECS)} references verified and written to {output_path}")
    return 0


def verify_existing(input_path: Path) -> int:
    """Re-verify an existing verified_references.json against live PubMed & CrossRef APIs."""
    with open(input_path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    refs = data.get("references", {})
    pmids = [r["pmid"] for r in refs.values() if r.get("pmid")]
    efetch_map = pubmed_efetch_batch(pmids)

    failures = []
    for key, rec in refs.items():
        pmid = rec.get("pmid")
        doi = rec.get("doi")
        if not rec.get("verified"):
            failures.append((key, "verified flag is False"))
            continue
        if pmid:
            if not pubmed_esearch_pmid(pmid):
                failures.append((key, f"esearch failed for PMID {pmid}"))
                continue
            pm = efetch_map.get(pmid)
            if not pm or token_overlap_ratio(rec["title"], pm["title"]) < 0.75:
                failures.append((key, f"PubMed efetch title mismatch for PMID {pmid}"))
                continue
        if doi:
            cr = crossref_fetch_doi(doi)
            if token_overlap_ratio(rec["title"], cr["title"]) < 0.65:
                failures.append((key, f"CrossRef title mismatch for DOI {doi}"))
                continue
        print(f"RE-VERIFIED: {key} (PMID={pmid}, DOI={doi})")

    if failures:
        for k, msg in failures:
            print(f"FAIL {k}: {msg}", file=sys.stderr)
        return 1
    print(f"\nALL {len(refs)}/{len(refs)} REFERENCES PASSED LIVE RE-VERIFICATION.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Build and verify verified_references.json via PubMed & CrossRef.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Path to verified_references.json")
    parser.add_argument("--verify-only", action="store_true", help="Re-verify existing JSON file instead of rebuilding")
    args = parser.parse_args()

    if args.verify_only:
        return verify_existing(args.output)
    return verify_and_build(args.output)


if __name__ == "__main__":
    raise SystemExit(main())
