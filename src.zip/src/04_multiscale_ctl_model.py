"""Step 3 Part 2 (Task A): Multiscale Condensate-Timing-Liability (CTL) Model (Eqs. 7-16).

Implements Equations (7)-(16) coupling Scale 1 heterotypic-buffering condensate kinetics
(imported from results/biophysical_calibration.json) with empirical BrainSpan prefrontal
activity drive D_act_emp(t) and V_ASD_emp(t) (from results/brainspan_empirical_kernels.csv)
over human neurodevelopmental time t in [-0.5754, 30.0] yr (8 pcw to 30 yr):

  Eq. (7):  Prefrontal synaptic density ODE dNs/dt calibrated to Huttenlocher & Dabholkar
            (1997) and Petanjek et al. (2011) human PFC developmental landmarks.
  Eqs. (8)-(9): Bivariate correlated polygenic liability (r_G = 0.211, Grove et al. 2019)
            and smooth bounded genetic amplification g_d(P_d).
  Eqs. (10)-(11): Cumulative developmental liabilities L_ASD(t) and L_SCZ(t) weighted by
            normalized BrainSpan-anchored vulnerability kernels V_ASD(t) and V_SCZ(t).
  Eqs. (12)-(13): Diagnostic regime classification (Resilient, ASD-only, SCZ-only, Comorbid)
            and Phenotypic Bias Index Psi in [-1, +1] (Psi = 0 separatrix).
  Eqs. (14)-(16): Conditional induction protocol chi_delta4(t; tau_on, delta_chi),
            splice-switching oligonucleotide (SSO) rescue law chi_delta4^SSO(t; tau_rx, d_SSO),
            and Therapeutic Reversibility Index R_d(tau_rx, d_SSO).

Verifies full coupled non-autonomous (L, S, Ns) ODE integration using RK45 vs Radau
(rtol=1e-10, atol=1e-12, convergence < 1e-7) with exact 365.25 day/yr unit conversion,
verifies simplex & positivity invariance and adiabatic QSS agreement, and exports:
  - results/ctl_phase_diagrams.json
  - results/ctl_trajectories.csv
  - results/phase_grid_tau_chi.csv
  - results/phase_grid_prs_chi.csv
"""

from __future__ import annotations

import json
import math
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.special import expit

SEED = 20261119
DAYS_PER_YEAR = 365.25
WORKSPACE = Path(__file__).resolve().parent.parent
RESULTS_DIR = WORKSPACE / "results"

# Canonical developmental time grid bounds (8 pcw to 30 yr postnatal)
T_MAX_YEARS = 30.0
CHI_CTRL = 0.30
SWITCH_EPS_YEARS = 0.04  # ~14.6 days smooth induction / SSO switching timescale

# Calibrated Scale 2-3 CTL parameters (documented in results/ctl_phase_diagrams.json)
# Synaptogenesis & pruning parameters fitted strictly to Control (chi=0.30, P=0)
# Huttenlocher & Dabholkar (1997) / Petanjek et al. (2011) human PFC landmarks.
CTL_DEFAULT_PARAMS: dict[str, Any] = {
    "r_G": 0.211,           # Grove et al. (2019) ASD-SCZ genetic correlation
    "c_P": 3.0,             # Smooth bounded PRS saturation scale (Eq. 9)
    "gamma_ASD": 0.45,      # Polygenic amplification slope for ASD targets
    "gamma_SCZ": 0.40,      # Polygenic amplification slope for SCZ targets
    "Ns_init": 0.05,        # Pre-synaptogenesis cortical density at 8 pcw (norm. to adult=1)
    "delta_0": 0.25,        # Basal adult synaptic turnover rate (yr^-1)
    "kappa_1": 0.45,        # Synaptogenesis suppression coupling to CPEB4 deficit (1 - Phi)
    "kappa_2": 0.65,        # Adolescent pruning amplification coupling to (1 - Phi)
    # Synaptogenesis rate alpha_syn(t) parameters (fitted to Control PFC landmarks)
    "a_peri": 2.722,        # Perinatal synaptogenesis burst amplitude (yr^-1)
    "t_peri": -0.181,       # Perinatal burst center (yr)
    "s_peri": 0.137,        # Perinatal burst width (yr)
    "a_inf": 0.477,         # Early-childhood synaptogenesis extension amplitude (yr^-1)
    "t_inf": 1.279,         # Early-childhood extension center (yr)
    "s_inf": 0.796,         # Early-childhood extension width (yr)
    # Adolescent pruning rate beta_prun(t) parameters (coupled to BrainSpan D_act_emp(t))
    "b_prun": 0.081,        # Adolescent pruning peak amplitude (yr^-1)
    "t_prun_on": 3.910,     # Pruning onset inflection age (yr)
    "t_prun_pk": 13.229,    # Pruning peak age (yr)
    "s_prun": 4.332,        # Pruning Gaussian width (yr)
    # BrainSpan-anchored developmental vulnerability kernels V_ASD(t) & V_SCZ(t)
    "V_ASD_t_center": 2.0,  # Early W1 center (yr), anchored to V_ASD_emp & Fu22 ASD185
    "V_ASD_sigma": 2.2,     # Early W1 kernel width (yr)
    "V_SCZ_t_on": 11.0,     # Late W2 onset inflection (yr), anchored to SCHEMA & D_act
    "V_SCZ_t_center": 19.5, # Late W2 peak (yr), aligned with D_act peak 18.84 yr & Solmi 20.5 yr
    "V_SCZ_sigma": 3.8,     # Late W2 kernel width (yr)
    # Cumulative liability weights (Eqs. 10-11)
    "w_P_ASD": 0.80,
    "w_Phi_ASD": 4.20,
    "w_N_ASD": 3.10,
    "w_P_SCZ": 0.85,
    "w_Phi_SCZ": 2.60,
    "w_N_SCZ": 2.30,
    # Population-calibrated diagnostic thresholds (calibrated ONLY to 1.80% ASD & 0.85% SCZ
    # prevalences in 100,000 birth cohort in 05_sensitivity_and_cohort.py; stored here as defaults
    # and synchronized during calibration)
    "theta_ASD": 3.959575,
    "theta_SCZ": 3.819487,
    # SSO dose-response half-saturation constant (Eq. 15)
    "K_SSO": 0.25,
    # Conditional murine developmental stage equivalents (Semple et al. 2013; Workman et al. 2013)
    "mouse_stage_ages_yr": {
        "E14.5": -0.44,  # ~15 pcw mid-fetal cortical neurogenesis/early migration
        "P10": 0.15,     # ~2 mos postnatal term/early-infancy synaptogenesis spurt
        "P42": 14.0,     # ~14 yr human adolescence PFC maturation onset
    },
}


def load_scale1_and_brainspan() -> dict[str, Any]:
    """Load calibrated Scale 1 parameters and BrainSpan empirical PFC kernels."""
    calib_path = RESULTS_DIR / "biophysical_calibration.json"
    kernels_path = RESULTS_DIR / "brainspan_empirical_kernels.csv"
    if not calib_path.exists() or not kernels_path.exists():
        raise FileNotFoundError("Missing Step 2 / Step 3 Part 1 artifacts in results/.")

    calib = json.loads(calib_path.read_text(encoding="utf-8"))
    p1 = calib["eq4_to_eq6_ode_parameters_and_provenance"]["parameters"]
    kernels = pd.read_csv(kernels_path)
    return {"calib": calib, "p1": p1, "kernels": kernels}


class EmpiricalBrainSpanInterpolator:
    """Fast O(1) C2-smooth cubic spline interpolator for BrainSpan D_act_emp(t) and V_ASD_emp(t)."""

    def __init__(self, kernels: pd.DataFrame) -> None:
        self.t_min = float(kernels["age_years_postnatal"].min())
        self.t_max = T_MAX_YEARS
        self.l2_grid = kernels["log2_pcw"].to_numpy(dtype=float)
        self.d_grid = kernels["D_act_emp"].to_numpy(dtype=float)
        self.v_grid = kernels["V_ASD_emp"].to_numpy(dtype=float)

        self._d_cs = CubicSpline(self.l2_grid, self.d_grid, bc_type="natural")
        self._v_cs = CubicSpline(self.l2_grid, self.v_grid, bc_type="natural")

        self._c_d = self._d_cs.c
        self._x_d = self._d_cs.x
        self._dl2 = float(self._x_d[1] - self._x_d[0])
        self._n_seg = len(self._x_d) - 1

    def d_act_scalar(self, t: float) -> float:
        l2 = math.log2(max(38.0 + 52.14 * t, 8.0))
        if l2 <= self._x_d[0]:
            val = float(self.d_grid[0])
        elif l2 >= self._x_d[-1]:
            val = float(self.d_grid[-1])
        else:
            idx = min(int((l2 - self._x_d[0]) / self._dl2), self._n_seg - 1)
            dx = l2 - self._x_d[idx]
            val = ((self._c_d[0, idx] * dx + self._c_d[1, idx]) * dx + self._c_d[2, idx]) * dx + self._c_d[3, idx]
        return 0.0 if val < 0.0 else (1.0 if val > 1.0 else val)

    def d_act_vec(self, t: np.ndarray | float) -> np.ndarray:
        l2 = np.log2(np.maximum(38.0 + 52.14 * np.asarray(t, dtype=float), 8.0))
        return np.clip(self._d_cs(l2), 0.0, 1.0)

    def v_asd_emp_vec(self, t: np.ndarray | float) -> np.ndarray:
        l2 = np.log2(np.maximum(38.0 + 52.14 * np.asarray(t, dtype=float), 8.0))
        return np.clip(self._v_cs(l2), 0.0, 1.0)


def build_ctl_context(
    params_override: dict[str, Any] | None = None,
    n_grid: int = 801,
) -> dict[str, Any]:
    """Build complete precomputed CTL context (Scale 1 + BrainSpan + Scale 2-3 parameters)."""
    loaded = load_scale1_and_brainspan()
    p1 = dict(loaded["p1"])
    kernels = loaded["kernels"]
    interp = EmpiricalBrainSpanInterpolator(kernels)

    p23 = dict(CTL_DEFAULT_PARAMS)
    if params_override:
        p23.update(params_override)

    t0 = interp.t_min
    t1 = T_MAX_YEARS
    t_grid = np.linspace(t0, t1, n_grid)
    dt = float(t_grid[1] - t_grid[0])

    d_act_grid = interp.d_act_vec(t_grid)
    v_asd_emp_grid = interp.v_asd_emp_vec(t_grid)

    # Eq. (7) steady-state basal synaptogenesis rate so Control adult plateau -> 1.00
    phi_ctrl_inf = qss_phi_scalar(CHI_CTRL, float(d_act_grid[-1]), p1)
    alpha_base = p23["delta_0"] / (1.0 - p23["kappa_1"] * (1.0 - phi_ctrl_inf))
    p23["alpha_base"] = float(alpha_base)

    # Normalized BrainSpan-anchored vulnerability kernels V_ASD(t), V_SCZ(t)
    v_asd_raw = (
        (0.40 + 0.60 * v_asd_emp_grid)
        * expit((t_grid + 0.45) / 0.12)
        * np.exp(-0.5 * ((t_grid - p23["V_ASD_t_center"]) / p23["V_ASD_sigma"]) ** 2)
    )
    v_asd = v_asd_raw / float(np.trapezoid(v_asd_raw, t_grid))

    v_scz_raw = (
        d_act_grid
        * expit((t_grid - p23["V_SCZ_t_on"]) / 1.8)
        * np.exp(-0.5 * ((t_grid - p23["V_SCZ_t_center"]) / p23["V_SCZ_sigma"]) ** 2)
    )
    v_scz = v_scz_raw / float(np.trapezoid(v_scz_raw, t_grid))

    alpha_grid = alpha_syn_eval(t_grid, p23)
    beta_grid = beta_prun_eval(t_grid, d_act_grid, p23)

    # Control baseline trajectories (adiabatic QSS & full coupled ODE)
    ctx = {
        "p1": p1,
        "p23": p23,
        "interp": interp,
        "calib": loaded["calib"],
        "kernels": kernels,
        "t0": t0,
        "t1": t1,
        "t_grid": t_grid,
        "dt": dt,
        "d_act_grid": d_act_grid,
        "v_asd_emp_grid": v_asd_emp_grid,
        "V_ASD_grid": v_asd,
        "V_SCZ_grid": v_scz,
        "alpha_grid": alpha_grid,
        "beta_grid": beta_grid,
    }
    ctrl_ode = solve_coupled_ode(
        chi_fn=lambda _t: CHI_CTRL,
        p_asd=0.0,
        p_scz=0.0,
        ctx=ctx,
        t_eval=t_grid,
        method="Radau",
    )
    ctx["Phi_ctrl_grid"] = ctrl_ode["Phi"]
    ctx["Ns_ctrl_grid"] = ctrl_ode["Ns"]
    ctx["Phi_ctrl_qss_grid"] = eval_qss_phi_vec(np.full_like(t_grid, CHI_CTRL), d_act_grid, p1)
    ctx["Ns_ctrl_qss_grid"] = solve_ns_crank_nicolson(
        ctx["Phi_ctrl_qss_grid"][None, :],
        np.ones((1, 1)),
        np.ones((1, 1)),
        ctx,
    )[0]
    return ctx


# ---------------------------------------------------------------------------
# Scale 1 & Scale 2-3 Core Equations (Eqs. 7-16)
# ---------------------------------------------------------------------------

def qss_state_scalar(chi_delta4: float, d_act: float, p1: dict[str, Any]) -> tuple[float, float, float]:
    """Exact closed-form Scale 1 QSS (L*, S*, Phi*) at scalar (chi_delta4, D_act)."""
    chi = max(min(float(chi_delta4), 1.0), 1e-9)
    a_norm = float(expit(p1["n_H"] * (math.log(chi) - math.log(p1["chi_c_ref_pH8"]))))
    b_val = 1.0 + (p1["k_diss"] * p1["R_rev"] * d_act) / p1["k_form"]
    c_val = p1["k_lock"] * (1.0 + p1["lambda_D"] * d_act) / p1["k_clr"]
    beta = 1.0 + p1["k_clr"] / p1["k_form"]
    denom = b_val + beta * c_val * a_norm
    l_star = 1.0 / denom
    s_star = (c_val * a_norm) / denom
    phi_star = 1.0 - p1["eta_S"] * s_star - p1["eta_L"] * l_star
    return l_star, s_star, phi_star


def qss_phi_scalar(chi_delta4: float, d_act: float, p1: dict[str, Any]) -> float:
    return qss_state_scalar(chi_delta4, d_act, p1)[2]


def eval_qss_phi_vec(
    chi_mat: np.ndarray, d_act_grid: np.ndarray, p1: dict[str, Any]
) -> np.ndarray:
    """Vectorized closed-form Scale 1 QSS Phi*(t) for arbitrary arrays broadcastable to d_act_grid."""
    chi = np.maximum(np.asarray(chi_mat, dtype=float), 1e-9)
    a_norm = expit(p1["n_H"] * (np.log(chi) - math.log(p1["chi_c_ref_pH8"])))
    b_val = 1.0 + (p1["k_diss"] * p1["R_rev"] * d_act_grid) / p1["k_form"]
    c_val = p1["k_lock"] * (1.0 + p1["lambda_D"] * d_act_grid) / p1["k_clr"]
    beta = 1.0 + p1["k_clr"] / p1["k_form"]
    denom = b_val + beta * c_val * a_norm
    l_star = 1.0 / denom
    s_star = (c_val * a_norm) / denom
    return 1.0 - p1["eta_S"] * s_star - p1["eta_L"] * l_star


def eq8_sample_prs(
    n_samples: int,
    r_g: float = 0.211,
    rng: np.random.Generator | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Eq. (8): Draw bivariate correlated polygenic risk scores (P_ASD, P_SCZ) ~ N(0, Sigma)."""
    if rng is None:
        rng = np.random.default_rng(SEED)
    z1 = rng.standard_normal(n_samples)
    z2 = rng.standard_normal(n_samples)
    p_asd = z1
    p_scz = r_g * z1 + math.sqrt(max(0.0, 1.0 - r_g * r_g)) * z2
    return p_asd, p_scz


def eq9_polygenic_amplification(
    p_d: float | np.ndarray, gamma_d: float, c_p: float = 3.0
) -> float | np.ndarray:
    """Eq. (9): Smooth bounded polygenic amplification g_d(P_d) = exp(gamma_d * c_P * tanh(P_d / c_P))."""
    return np.exp(gamma_d * c_p * np.tanh(np.asarray(p_d, dtype=float) / c_p))


def alpha_syn_eval(t: float | np.ndarray, p23: dict[str, Any]) -> float | np.ndarray:
    """Eq. (7a): Developmental prefrontal synaptogenesis rate alpha_syn(t) (yr^-1)."""
    t_arr = np.asarray(t, dtype=float)
    peri = p23["a_peri"] * np.exp(-0.5 * ((t_arr - p23["t_peri"]) / p23["s_peri"]) ** 2) * expit((t_arr + 0.34) / 0.05)
    inf = p23["a_inf"] * np.exp(-0.5 * ((t_arr - p23["t_inf"]) / p23["s_inf"]) ** 2) * expit((t_arr - 0.10) / 0.25)
    val = p23["alpha_base"] + peri + inf
    return float(val) if np.ndim(t) == 0 else val


def beta_prun_eval(
    t: float | np.ndarray, d_act: float | np.ndarray, p23: dict[str, Any]
) -> float | np.ndarray:
    """Eq. (7b): BrainSpan D_act-coupled adolescent synaptic pruning rate beta_prun(t) (yr^-1)."""
    t_arr = np.asarray(t, dtype=float)
    d_arr = np.asarray(d_act, dtype=float)
    val = (
        p23["b_prun"]
        * d_arr
        * expit((t_arr - p23["t_prun_on"]) / 1.0)
        * np.exp(-0.5 * ((t_arr - p23["t_prun_pk"]) / p23["s_prun"]) ** 2)
    )
    return float(val) if np.ndim(t) == 0 and np.ndim(d_act) == 0 else val


def eq14_chi_induction(
    t: float | np.ndarray,
    tau_on: float,
    delta_chi: float,
    chi_ctrl: float = CHI_CTRL,
    eps_yr: float = SWITCH_EPS_YEARS,
) -> float | np.ndarray:
    """Eq. (14): Conditional splicing induction protocol chi_delta4(t; tau_on, delta_chi)."""
    t_arr = np.asarray(t, dtype=float)
    z = np.clip((t_arr - tau_on) / eps_yr, -60.0, 60.0)
    val = np.clip(chi_ctrl + delta_chi * expit(z), 0.0, 1.0)
    return float(val) if np.ndim(t) == 0 else val


def eq15_sso_efficacy(d_sso: float | np.ndarray, k_sso: float = 0.25) -> float | np.ndarray:
    """Eq. (15a): Saturating dose-response fraction f_SSO(d_SSO) in [0, 1] for d_SSO in [0, 1]."""
    d = np.clip(np.asarray(d_sso, dtype=float), 0.0, 1.0)
    val = ((1.0 + k_sso) * d) / (d + k_sso)
    return float(val) if np.ndim(d_sso) == 0 else val


def eq15_chi_sso_rescue(
    t: float | np.ndarray,
    chi_path: float | np.ndarray,
    tau_rx: float,
    d_sso: float,
    chi_ctrl: float = CHI_CTRL,
    k_sso: float = 0.25,
    eps_yr: float = SWITCH_EPS_YEARS,
) -> float | np.ndarray:
    """Eq. (15): Splice-switching oligonucleotide (SSO) rescue trajectory chi_delta4^SSO(t)."""
    t_arr = np.asarray(t, dtype=float)
    f_dose = float(eq15_sso_efficacy(d_sso, k_sso=k_sso))
    z = np.clip((t_arr - tau_rx) / eps_yr, -60.0, 60.0)
    val = np.clip(chi_ctrl + (np.asarray(chi_path, dtype=float) - chi_ctrl) * (1.0 - f_dose * expit(z)), 0.0, 1.0)
    return float(val) if np.ndim(t) == 0 and np.ndim(chi_path) == 0 else val


def eq12_classify_regime(l_asd_norm: float, l_scz_norm: float) -> str:
    """Eq. (12): Mutually exclusive diagnostic regime classification at t = T_max."""
    asd_pos = l_asd_norm >= 1.0
    scz_pos = l_scz_norm >= 1.0
    if asd_pos and scz_pos:
        return "Comorbid"
    if asd_pos:
        return "ASD-only"
    if scz_pos:
        return "SCZ-only"
    return "Resilient"


def eq13_phenotypic_bias_index(l_asd_norm: float, l_scz_norm: float) -> float:
    """Eq. (13): Phenotypic Bias Index Psi = (L~_SCZ - L~_ASD) / (L~_SCZ + L~_ASD) in [-1, +1]."""
    a = max(0.0, float(l_asd_norm))
    s = max(0.0, float(l_scz_norm))
    denom = s + a
    if denom <= 1e-15:
        return 0.0
    return float(max(-1.0, min(1.0, (s - a) / denom)))


def eq16_reversibility_index(
    l_treated: float, l_untreated: float, l_baseline_ctrl_splicing: float
) -> float:
    """Eq. (16): Therapeutic Reversibility Index R_d(tau_rx, d_SSO) in [0, 1]."""
    denom = l_untreated - l_baseline_ctrl_splicing
    if denom <= 1e-12:
        return 1.0
    val = 1.0 - (l_treated - l_baseline_ctrl_splicing) / denom
    return float(max(0.0, min(1.0, val)))


# ---------------------------------------------------------------------------
# Full Coupled Non-Autonomous (L, S, Ns) ODE Solver (Eqs. 4-7)
# ---------------------------------------------------------------------------

def solve_coupled_ode(
    chi_fn: Callable[[float], float],
    p_asd: float,
    p_scz: float,
    ctx: dict[str, Any],
    t_eval: np.ndarray | None = None,
    method: str = "Radau",
    rtol: float = 1e-10,
    atol: float = 1e-12,
) -> dict[str, Any]:
    """Integrate the full coupled 3-ODE system (L, S, Ns) over t in [t0, 30.0] yr."""
    p1 = ctx["p1"]
    p23 = ctx["p23"]
    interp: EmpiricalBrainSpanInterpolator = ctx["interp"]
    t0, t1 = ctx["t0"], ctx["t1"]
    if t_eval is None:
        t_eval = ctx["t_grid"]

    g_asd = float(eq9_polygenic_amplification(p_asd, p23["gamma_ASD"], p23["c_P"]))
    g_scz = float(eq9_polygenic_amplification(p_scz, p23["gamma_SCZ"], p23["c_P"]))

    chi_c_ref = p1["chi_c_ref_pH8"]
    log_chi_c = math.log(chi_c_ref)
    n_h = p1["n_H"]
    k_form = p1["k_form"]
    k_diss = p1["k_diss"]
    r_rev = p1["R_rev"]
    k_lock = p1["k_lock"]
    k_clr = p1["k_clr"]
    lam_d = p1["lambda_D"]
    eta_s = p1["eta_S"]
    eta_l = p1["eta_L"]

    delta0 = p23["delta_0"]
    kappa1 = p23["kappa_1"]
    kappa2 = p23["kappa_2"]
    alpha_base = p23["alpha_base"]
    a_peri, t_peri, s_peri = p23["a_peri"], p23["t_peri"], p23["s_peri"]
    a_inf, t_inf, s_inf = p23["a_inf"], p23["t_inf"], p23["s_inf"]
    b_prun, tp_on, tp_pk, s_prun = p23["b_prun"], p23["t_prun_on"], p23["t_prun_pk"], p23["s_prun"]

    def _rates(t: float) -> tuple[float, float, float, float, float]:
        d_act = interp.d_act_scalar(t)
        chi = max(min(float(chi_fn(t)), 1.0), 1e-9)
        z_h = n_h * (math.log(chi) - log_chi_c)
        a_norm = 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, z_h))))
        diss_rate = k_diss * d_act * r_rev
        lock_rate = k_lock * a_norm * (1.0 + lam_d * d_act)
        alpha_t = (
            alpha_base
            + a_peri * math.exp(-0.5 * ((t - t_peri) / s_peri) ** 2) / (1.0 + math.exp(-max(-60.0, min(60.0, (t + 0.34) / 0.05))))
            + a_inf * math.exp(-0.5 * ((t - t_inf) / s_inf) ** 2) / (1.0 + math.exp(-max(-60.0, min(60.0, (t - 0.10) / 0.25))))
        )
        beta_t = (
            b_prun
            * d_act
            / (1.0 + math.exp(-max(-60.0, min(60.0, (t - tp_on) / 1.0))))
            * math.exp(-0.5 * ((t - tp_pk) / s_prun) ** 2)
        )
        return diss_rate, lock_rate, alpha_t, beta_t, d_act

    def rhs(t: float, y: np.ndarray) -> list[float]:
        l_val, s_val, ns_val = float(y[0]), float(y[1]), float(y[2])
        diss_rate, lock_rate, alpha_t, beta_t, _ = _rates(t)
        dl = DAYS_PER_YEAR * (k_form * (1.0 - l_val - s_val) - (diss_rate + lock_rate) * l_val)
        ds = DAYS_PER_YEAR * (lock_rate * l_val - k_clr * s_val)
        phi = 1.0 - eta_s * s_val - eta_l * l_val
        prod_gate = max(0.0, 1.0 - kappa1 * (1.0 - phi) * g_asd)
        loss_rate = delta0 + beta_t * (1.0 + kappa2 * (1.0 - phi) * g_scz)
        dns = alpha_t * prod_gate - loss_rate * ns_val
        return [dl, ds, dns]

    def jac(t: float, y: np.ndarray) -> np.ndarray:
        l_val, s_val, ns_val = float(y[0]), float(y[1]), float(y[2])
        diss_rate, lock_rate, alpha_t, beta_t, _ = _rates(t)
        phi = 1.0 - eta_s * s_val - eta_l * l_val
        ind = 1.0 if (1.0 - kappa1 * (1.0 - phi) * g_asd) > 0.0 else 0.0
        j20 = -alpha_t * kappa1 * eta_l * g_asd * ind - beta_t * kappa2 * eta_l * g_scz * ns_val
        j21 = -alpha_t * kappa1 * eta_s * g_asd * ind - beta_t * kappa2 * eta_s * g_scz * ns_val
        j22 = -(delta0 + beta_t * (1.0 + kappa2 * (1.0 - phi) * g_scz))
        return np.array(
            [
                [-DAYS_PER_YEAR * (k_form + diss_rate + lock_rate), -DAYS_PER_YEAR * k_form, 0.0],
                [DAYS_PER_YEAR * lock_rate, -DAYS_PER_YEAR * k_clr, 0.0],
                [j20, j21, j22],
            ],
            dtype=float,
        )

    l0, s0, _ = qss_state_scalar(chi_fn(t0), interp.d_act_scalar(t0), p1)
    y0 = [l0, s0, p23["Ns_init"]]

    kw: dict[str, Any] = {"method": method, "t_eval": t_eval, "rtol": rtol, "atol": atol}
    if method in ("Radau", "BDF", "LSODA"):
        kw["jac"] = jac
    sol = solve_ivp(rhs, (t0, t1), y0, **kw)
    if not sol.success:
        raise RuntimeError(f"ODE solver ({method}) failed: {sol.message}")

    l_arr, s_arr, ns_arr = sol.y[0], sol.y[1], sol.y[2]
    phi_arr = 1.0 - eta_s * s_arr - eta_l * l_arr
    chi_arr = np.array([chi_fn(float(tv)) for tv in t_eval], dtype=float)
    return {
        "t": t_eval,
        "chi": chi_arr,
        "L": l_arr,
        "S": s_arr,
        "Phi": phi_arr,
        "Ns": ns_arr,
        "g_ASD": g_asd,
        "g_SCZ": g_scz,
        "nfev": int(sol.nfev),
    }


def solve_ns_crank_nicolson(
    phi_mat: np.ndarray,
    g_asd: np.ndarray,
    g_scz: np.ndarray,
    ctx: dict[str, Any],
) -> np.ndarray:
    """Vectorized 2nd-order Crank-Nicolson integrator for Eq. (7) across N trajectories."""
    p23 = ctx["p23"]
    alpha_t = ctx["alpha_grid"]
    beta_t = ctx["beta_grid"]
    dt = ctx["dt"]
    n_traj, n_t = phi_mat.shape

    ns = np.empty((n_traj, n_t), dtype=float)
    ns[:, 0] = p23["Ns_init"]

    defic = 1.0 - phi_mat
    prod_mat = alpha_t[None, :] * np.maximum(0.0, 1.0 - p23["kappa_1"] * defic * g_asd)
    rate_mat = p23["delta_0"] + beta_t[None, :] * (1.0 + p23["kappa_2"] * defic * g_scz)

    half_dt = 0.5 * dt
    for j in range(n_t - 1):
        pm = 0.5 * (prod_mat[:, j] + prod_mat[:, j + 1])
        rm = 0.5 * (rate_mat[:, j] + rate_mat[:, j + 1])
        ns[:, j + 1] = (ns[:, j] * (1.0 - half_dt * rm) + dt * pm) / (1.0 + half_dt * rm)
    return ns


def compute_liabilities_and_regimes(
    phi_mat: np.ndarray,
    ns_mat: np.ndarray,
    p_asd: np.ndarray,
    p_scz: np.ndarray,
    g_asd: np.ndarray,
    g_scz: np.ndarray,
    ctx: dict[str, Any],
    eps_asd: np.ndarray | None = None,
    eps_scz: np.ndarray | None = None,
    use_ode_ctrl: bool = False,
) -> dict[str, Any]:
    """Compute Eqs. (10)-(13) cumulative liability trajectories, final scores, Psi, and regimes."""
    p23 = ctx["p23"]
    t_grid = ctx["t_grid"]
    dt = ctx["dt"]
    v_asd = ctx["V_ASD_grid"]
    v_scz = ctx["V_SCZ_grid"]

    phi_ctrl = ctx["Phi_ctrl_grid"] if use_ode_ctrl else ctx["Phi_ctrl_qss_grid"]
    ns_ctrl = ctx["Ns_ctrl_grid"] if use_ode_ctrl else ctx["Ns_ctrl_qss_grid"]
    defic_ctrl = 1.0 - phi_ctrl

    n_traj, n_t = phi_mat.shape
    ea = np.zeros((n_traj, 1), dtype=float) if eps_asd is None else eps_asd[:, None]
    es = np.zeros((n_traj, 1), dtype=float) if eps_scz is None else eps_scz[:, None]
    pa = np.asarray(p_asd, dtype=float)[:, None]
    ps = np.asarray(p_scz, dtype=float)[:, None]

    syn_loss = np.maximum(0.0, ns_ctrl[None, :] - ns_mat)

    int_asd = v_asd[None, :] * (
        p23["w_P_ASD"] * pa
        + ea
        + p23["w_Phi_ASD"] * ((1.0 - phi_mat) * g_asd - defic_ctrl[None, :])
        + p23["w_N_ASD"] * syn_loss
    )
    int_scz = v_scz[None, :] * (
        p23["w_P_SCZ"] * ps
        + es
        + p23["w_Phi_SCZ"] * ((1.0 - phi_mat) * g_scz - defic_ctrl[None, :])
        + p23["w_N_SCZ"] * syn_loss
    )

    l_asd_traj = np.zeros((n_traj, n_t), dtype=float)
    l_scz_traj = np.zeros((n_traj, n_t), dtype=float)
    l_asd_traj[:, 1:] = np.cumsum(0.5 * (int_asd[:, :-1] + int_asd[:, 1:]) * dt, axis=1)
    l_scz_traj[:, 1:] = np.cumsum(0.5 * (int_scz[:, :-1] + int_scz[:, 1:]) * dt, axis=1)

    l_asd_final = l_asd_traj[:, -1]
    l_scz_final = l_scz_traj[:, -1]
    l_asd_norm = np.maximum(0.0, l_asd_final) / p23["theta_ASD"]
    l_scz_norm = np.maximum(0.0, l_scz_final) / p23["theta_SCZ"]

    denom = l_scz_norm + l_asd_norm
    psi = np.where(denom > 1e-15, (l_scz_norm - l_asd_norm) / np.maximum(denom, 1e-15), 0.0)
    psi = np.clip(psi, -1.0, 1.0)

    return {
        "L_ASD_traj": l_asd_traj,
        "L_SCZ_traj": l_scz_traj,
        "L_ASD_final": l_asd_final,
        "L_SCZ_final": l_scz_final,
        "L_ASD_norm": l_asd_norm,
        "L_SCZ_norm": l_scz_norm,
        "Psi": psi,
    }


def first_crossing_ages(
    traj: np.ndarray, threshold: float, mask: np.ndarray, t_grid: np.ndarray
) -> np.ndarray:
    """Linearly interpolate first age t where L_d(t) >= threshold among affected cases."""
    dt = float(t_grid[1] - t_grid[0])
    idx_cases = np.where(mask)[0]
    onsets = np.empty(len(idx_cases), dtype=float)
    for k, i in enumerate(idx_cases):
        row = traj[i]
        j = int(np.argmax(row >= threshold))
        if j == 0:
            onsets[k] = float(t_grid[0])
        else:
            y0, y1 = float(row[j - 1]), float(row[j])
            frac = (threshold - y0) / max(y1 - y0, 1e-12)
            onsets[k] = float(t_grid[j - 1] + max(0.0, min(1.0, frac)) * dt)
    return onsets


def evaluate_single_ode_scenario(
    name: str,
    chi_fn: Callable[[float], float],
    p_asd: float,
    p_scz: float,
    ctx: dict[str, Any],
    method: str = "Radau",
) -> dict[str, Any]:
    """Evaluate a single mechanistic trajectory via the full coupled ODE and Eqs. (10)-(13)."""
    p23 = ctx["p23"]
    sol = solve_coupled_ode(chi_fn, p_asd, p_scz, ctx, t_eval=ctx["t_grid"], method=method)
    liab = compute_liabilities_and_regimes(
        phi_mat=sol["Phi"][None, :],
        ns_mat=sol["Ns"][None, :],
        p_asd=np.array([p_asd]),
        p_scz=np.array([p_scz]),
        g_asd=np.array([[sol["g_ASD"]]]),
        g_scz=np.array([[sol["g_SCZ"]]]),
        ctx=ctx,
        use_ode_ctrl=True,
    )
    la_n = float(liab["L_ASD_norm"][0])
    ls_n = float(liab["L_SCZ_norm"][0])
    psi = float(liab["Psi"][0])
    regime = eq12_classify_regime(la_n, ls_n)

    t_g = ctx["t_grid"]
    ns = sol["Ns"]
    idx_pk = int(np.argmax(ns))
    idx_w1 = int(np.argmin(np.abs(t_g - 1.5)))
    idx_w2 = int(np.argmin(np.abs(t_g - 18.84)))
    ns_birth_0 = float(np.interp(0.0, t_g, ns))

    oa = first_crossing_ages(liab["L_ASD_traj"], p23["theta_ASD"], np.array([la_n >= 1.0]), t_g)
    os_ = first_crossing_ages(liab["L_SCZ_traj"], p23["theta_SCZ"], np.array([ls_n >= 1.0]), t_g)

    return {
        "scenario": name,
        "P_ASD": float(p_asd),
        "P_SCZ": float(p_scz),
        "Phi_W1_1.5yr": float(sol["Phi"][idx_w1]),
        "Phi_W2_18.8yr": float(sol["Phi"][idx_w2]),
        "S_W2_18.8yr": float(sol["S"][idx_w2]),
        "Ns_birth_0yr": ns_birth_0,
        "Ns_peak": float(ns[idx_pk]),
        "t_peak_yr": float(t_g[idx_pk]),
        "Ns_adult_30yr": float(ns[-1]),
        "pruning_decline_pct": float(100.0 * (ns[idx_pk] - ns[-1]) / ns[idx_pk]),
        "L_ASD_final": float(liab["L_ASD_final"][0]),
        "L_SCZ_final": float(liab["L_SCZ_final"][0]),
        "L_ASD_norm": la_n,
        "L_SCZ_norm": ls_n,
        "Psi": psi,
        "regime": regime,
        "onset_ASD_yr": float(oa[0]) if len(oa) > 0 else None,
        "onset_SCZ_yr": float(os_[0]) if len(os_) > 0 else None,
        "_arrays": {
            "t": t_g,
            "chi": sol["chi"],
            "L": sol["L"],
            "S": sol["S"],
            "Phi": sol["Phi"],
            "Ns": sol["Ns"],
            "L_ASD": liab["L_ASD_traj"][0],
            "L_SCZ": liab["L_SCZ_traj"][0],
        },
    }


def verify_numerical_convergence_and_qss(ctx: dict[str, Any]) -> dict[str, Any]:
    """Verify RK45 vs Radau (rtol=1e-10, atol=1e-12), simplex/positivity invariance, and adiabatic QSS."""
    p23 = ctx["p23"]
    t_g = ctx["t_grid"]
    scenarios = [
        ("Control_0.30", lambda _t: 0.30, 0.0, 0.0),
        ("Early_ASD_0.45", lambda _t: 0.45, 0.0, 0.0),
        ("Adolescent_SCZ_0.38", lambda t: eq14_chi_induction(t, 12.0, 0.08), 0.0, 1.5),
        ("Comorbid_DualPRS", lambda t: eq14_chi_induction(t, -0.44, 0.16), 1.5, 1.5),
        ("SSO_Rescue_2yr", lambda t: eq15_chi_sso_rescue(t, 0.45, 2.0, 1.0, k_sso=p23["K_SSO"]), 1.0, 0.0),
    ]

    max_rk45_radau_state = 0.0
    max_rk45_radau_phi = 0.0
    max_rk45_radau_ns = 0.0
    max_simplex_viol = 0.0
    max_ns_neg_viol = 0.0
    max_qss_ns_diff = 0.0
    max_qss_psi_diff = 0.0
    details = []

    for label, chi_fn, pa, ps in scenarios:
        sol_rad = solve_coupled_ode(chi_fn, pa, ps, ctx, t_eval=t_g, method="Radau", rtol=1e-10, atol=1e-12)
        sol_rk = solve_coupled_ode(chi_fn, pa, ps, ctx, t_eval=t_g, method="RK45", rtol=1e-10, atol=1e-12)

        diff_l = float(np.max(np.abs(sol_rk["L"] - sol_rad["L"])))
        diff_s = float(np.max(np.abs(sol_rk["S"] - sol_rad["S"])))
        diff_phi = float(np.max(np.abs(sol_rk["Phi"] - sol_rad["Phi"])))
        diff_ns = float(np.max(np.abs(sol_rk["Ns"] - sol_rad["Ns"])))
        diff_state = max(diff_l, diff_s, diff_ns)

        max_rk45_radau_state = max(max_rk45_radau_state, diff_state)
        max_rk45_radau_phi = max(max_rk45_radau_phi, diff_phi)
        max_rk45_radau_ns = max(max_rk45_radau_ns, diff_ns)

        min_ls = float(min(np.min(sol_rad["L"]), np.min(sol_rad["S"])))
        max_sum_ls = float(np.max(sol_rad["L"] + sol_rad["S"]))
        min_ns = float(np.min(sol_rad["Ns"]))
        max_simplex_viol = max(max_simplex_viol, max(0.0, -min_ls), max(0.0, max_sum_ls - 1.0))
        max_ns_neg_viol = max(max_ns_neg_viol, max(0.0, -min_ns))

        # Compare adiabatic QSS + Crank-Nicolson against full Radau ODE
        chi_arr = sol_rad["chi"][None, :]
        phi_qss = eval_qss_phi_vec(chi_arr, ctx["d_act_grid"], ctx["p1"])
        ga = np.array([[sol_rad["g_ASD"]]])
        gs = np.array([[sol_rad["g_SCZ"]]])
        ns_qss = solve_ns_crank_nicolson(phi_qss, ga, gs, ctx)

        liab_ode = compute_liabilities_and_regimes(
            sol_rad["Phi"][None, :], sol_rad["Ns"][None, :], np.array([pa]), np.array([ps]), ga, gs, ctx, use_ode_ctrl=True
        )
        liab_qss = compute_liabilities_and_regimes(
            phi_qss, ns_qss, np.array([pa]), np.array([ps]), ga, gs, ctx, use_ode_ctrl=False
        )
        qss_ns_err = float(np.max(np.abs(ns_qss[0] - sol_rad["Ns"])))
        qss_psi_err = float(abs(liab_qss["Psi"][0] - liab_ode["Psi"][0]))
        max_qss_ns_diff = max(max_qss_ns_diff, qss_ns_err)
        max_qss_psi_diff = max(max_qss_psi_diff, qss_psi_err)

        details.append(
            {
                "scenario": label,
                "max_abs_diff_rk45_vs_radau_state": diff_state,
                "max_abs_diff_rk45_vs_radau_Phi": diff_phi,
                "max_abs_diff_rk45_vs_radau_Ns": diff_ns,
                "max_abs_diff_qss_vs_ode_Ns": qss_ns_err,
                "abs_diff_qss_vs_ode_Psi": qss_psi_err,
                "min_L_or_S": min_ls,
                "max_L_plus_S": max_sum_ls,
                "min_Ns": min_ns,
            }
        )

    return {
        "rtol": 1e-10,
        "atol": 1e-12,
        "time_conversion_days_per_year": DAYS_PER_YEAR,
        "max_abs_diff_rk45_vs_radau_state": max_rk45_radau_state,
        "max_abs_diff_rk45_vs_radau_Phi": max_rk45_radau_phi,
        "max_abs_diff_rk45_vs_radau_Ns": max_rk45_radau_ns,
        "max_simplex_violation": max_simplex_viol,
        "max_Ns_negativity_violation": max_ns_neg_viol,
        "max_qss_vs_ode_Ns_diff": max_qss_ns_diff,
        "max_qss_vs_ode_Psi_diff": max_qss_psi_diff,
        "all_tolerances_passed": bool(
            max_rk45_radau_state < 1e-7
            and max_simplex_viol < 1e-12
            and max_ns_neg_viol == 0.0
            and max_qss_ns_diff < 5e-3
        ),
        "scenario_details": details,
    }


def generate_phase_grids(ctx: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Generate 2D phase grids over (tau_on, delta_chi) and (PRS_bias, chi_delta4)."""
    p1 = ctx["p1"]
    p23 = ctx["p23"]
    t_grid = ctx["t_grid"]
    d_act_grid = ctx["d_act_grid"]

    # Grid 1: (tau_on, delta_chi) for both WT (0, 0) and Dual-PRS (+0.70, +0.55) backgrounds
    tau_vals = np.unique(np.round(np.concatenate([np.linspace(-0.5, 4.0, 15), np.linspace(5.0, 25.0, 17)]), 3))
    dchi_vals = np.linspace(0.00, 0.20, 21)

    rows_tc = []
    for bg_name, pa_bg, ps_bg in [("WT", 0.0, 0.0), ("Sensitized_PRS", 0.70, 0.55)]:
        tau_mesh, dchi_mesh = np.meshgrid(tau_vals, dchi_vals, indexing="ij")
        taus = tau_mesh.ravel()
        dchis = dchi_mesh.ravel()
        n_pts = len(taus)

        chi_mat = np.clip(
            CHI_CTRL + dchis[:, None] * expit(np.clip((t_grid[None, :] - taus[:, None]) / SWITCH_EPS_YEARS, -60.0, 60.0)),
            0.0,
            1.0,
        )
        phi_mat = eval_qss_phi_vec(chi_mat, d_act_grid, p1)
        pa_arr = np.full(n_pts, pa_bg)
        ps_arr = np.full(n_pts, ps_bg)
        ga = eq9_polygenic_amplification(pa_arr, p23["gamma_ASD"], p23["c_P"])[:, None]
        gs = eq9_polygenic_amplification(ps_arr, p23["gamma_SCZ"], p23["c_P"])[:, None]
        ns_mat = solve_ns_crank_nicolson(phi_mat, ga, gs, ctx)
        liab = compute_liabilities_and_regimes(phi_mat, ns_mat, pa_arr, ps_arr, ga, gs, ctx)

        idx_w1 = int(np.argmin(np.abs(t_grid - 1.5)))
        idx_w2 = int(np.argmin(np.abs(t_grid - 18.84)))
        idx_0 = int(np.argmin(np.abs(t_grid - 0.0)))

        for i in range(n_pts):
            la_n = float(liab["L_ASD_norm"][i])
            ls_n = float(liab["L_SCZ_norm"][i])
            rows_tc.append(
                {
                    "background": bg_name,
                    "P_ASD": pa_bg,
                    "P_SCZ": ps_bg,
                    "tau_on_yr": float(taus[i]),
                    "delta_chi": float(dchis[i]),
                    "chi_final": float(CHI_CTRL + dchis[i]),
                    "Phi_W1": float(phi_mat[i, idx_w1]),
                    "Phi_W2": float(phi_mat[i, idx_w2]),
                    "Ns_birth": float(ns_mat[i, idx_0]),
                    "Ns_max": float(np.max(ns_mat[i])),
                    "Ns_30yr": float(ns_mat[i, -1]),
                    "L_ASD": float(liab["L_ASD_final"][i]),
                    "L_SCZ": float(liab["L_SCZ_final"][i]),
                    "L_ASD_norm": la_n,
                    "L_SCZ_norm": ls_n,
                    "Psi": float(liab["Psi"][i]),
                    "regime": eq12_classify_regime(la_n, ls_n),
                }
            )
    df_tau_chi = pd.DataFrame(rows_tc)

    # Grid 2: (P_ASD - P_SCZ, chi_delta4) across antagonistic & concordant PRS slices
    # Primary slice: P_diff in [-4.0, +4.0] with P_ASD = -P_diff/2, P_SCZ = +P_diff/2
    # Wait: define prs_scz_minus_asd = P_SCZ - P_ASD so negative = ASD-PRS biased, positive = SCZ-PRS biased!
    # Plus sensitized slice with shared baseline P_sum/2 = +0.75 so Comorbid wedge is also mapped!
    p_diff_vals = np.linspace(-4.0, 4.0, 33)
    chi_vals = np.linspace(0.30, 0.48, 25)
    rows_pc = []
    for slice_name, p_mean in [("Neutral_Mean0", 0.0), ("SharedRisk_Mean0.75", 0.75)]:
        pd_mesh, ch_mesh = np.meshgrid(p_diff_vals, chi_vals, indexing="ij")
        pdiffs = pd_mesh.ravel()
        chis = ch_mesh.ravel()
        n_pts = len(pdiffs)
        pa_arr = p_mean - 0.5 * pdiffs
        ps_arr = p_mean + 0.5 * pdiffs

        chi_mat = np.repeat(chis[:, None], len(t_grid), axis=1)
        phi_mat = eval_qss_phi_vec(chi_mat, d_act_grid, p1)
        ga = eq9_polygenic_amplification(pa_arr, p23["gamma_ASD"], p23["c_P"])[:, None]
        gs = eq9_polygenic_amplification(ps_arr, p23["gamma_SCZ"], p23["c_P"])[:, None]
        ns_mat = solve_ns_crank_nicolson(phi_mat, ga, gs, ctx)
        liab = compute_liabilities_and_regimes(phi_mat, ns_mat, pa_arr, ps_arr, ga, gs, ctx)

        idx_w1 = int(np.argmin(np.abs(t_grid - 1.5)))
        idx_w2 = int(np.argmin(np.abs(t_grid - 18.84)))
        for i in range(n_pts):
            la_n = float(liab["L_ASD_norm"][i])
            ls_n = float(liab["L_SCZ_norm"][i])
            rows_pc.append(
                {
                    "slice_name": slice_name,
                    "P_SCZ_minus_P_ASD": float(pdiffs[i]),
                    "P_ASD_minus_P_SCZ": float(-pdiffs[i]),
                    "P_ASD": float(pa_arr[i]),
                    "P_SCZ": float(ps_arr[i]),
                    "chi_delta4": float(chis[i]),
                    "Phi_W1": float(phi_mat[i, idx_w1]),
                    "Phi_W2": float(phi_mat[i, idx_w2]),
                    "Ns_max": float(np.max(ns_mat[i])),
                    "Ns_30yr": float(ns_mat[i, -1]),
                    "L_ASD": float(liab["L_ASD_final"][i]),
                    "L_SCZ": float(liab["L_SCZ_final"][i]),
                    "L_ASD_norm": la_n,
                    "L_SCZ_norm": ls_n,
                    "Psi": float(liab["Psi"][i]),
                    "regime": eq12_classify_regime(la_n, ls_n),
                }
            )
    df_prs_chi = pd.DataFrame(rows_pc)
    return df_tau_chi, df_prs_chi


def run_all() -> dict[str, Any]:
    t_start = time.time()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    ctx = build_ctl_context()
    p23 = ctx["p23"]
    print(f"[1/4] Loaded Scale 1 & BrainSpan context in {time.time() - t_start:.2f}s", flush=True)

    # 1. Verify numerical convergence (RK45 vs Radau) & adiabatic QSS
    t0 = time.time()
    num_verif = verify_numerical_convergence_and_qss(ctx)
    print(
        f"[2/4] RK45 vs Radau max state diff = {num_verif['max_abs_diff_rk45_vs_radau_state']:.2e}, "
        f"simplex viol = {num_verif['max_simplex_violation']:.2e}, "
        f"QSS Ns max diff = {num_verif['max_qss_vs_ode_Ns_diff']:.2e} ({time.time() - t0:.2f}s)",
        flush=True,
    )

    # 2. Evaluate benchmark full-ODE trajectories
    t0 = time.time()
    stages = p23["mouse_stage_ages_yr"]
    benchmark_specs = [
        ("Control_0.30", lambda _t: 0.30, 0.0, 0.0),
        ("Constitutional_ASD_0.45_WT", lambda _t: 0.45, 0.0, 0.0),
        ("Adolescent_SCZ_0.38_SCZPRS", lambda t: eq14_chi_induction(t, 12.0, 0.08), 0.0, 1.5),
        ("E14.5_Ind_0.46_WT", lambda t: eq14_chi_induction(t, stages["E14.5"], 0.16), 0.0, 0.0),
        ("P10_Ind_0.46_WT", lambda t: eq14_chi_induction(t, stages["P10"], 0.16), 0.0, 0.0),
        ("P42_Ind_0.38_SCZPRS", lambda t: eq14_chi_induction(t, stages["P42"], 0.08), 0.0, 1.5),
        ("Comorbid_E14.5_0.46_DualPRS", lambda t: eq14_chi_induction(t, stages["E14.5"], 0.16), 1.5, 1.5),
        ("SSO_Rescue_ASD_0.5yr", lambda t: eq15_chi_sso_rescue(t, 0.45, 0.5, 1.0, k_sso=p23["K_SSO"]), 0.5, 0.0),
        ("SSO_Rescue_ASD_6.0yr", lambda t: eq15_chi_sso_rescue(t, 0.45, 6.0, 1.0, k_sso=p23["K_SSO"]), 0.5, 0.0),
        ("SSO_Rescue_SCZ_12.0yr", lambda t: eq15_chi_sso_rescue(t, 0.38, 12.0, 1.0, k_sso=p23["K_SSO"]), 0.0, 1.5),
    ]

    traj_frames = []
    bench_summary = {}
    t_g = ctx["t_grid"]
    for label, chi_fn, pa, ps in benchmark_specs:
        res = evaluate_single_ode_scenario(label, chi_fn, pa, ps, ctx, method="Radau")
        arr = res.pop("_arrays")
        bench_summary[label] = res
        traj_frames.append(
            pd.DataFrame(
                {
                    "scenario": label,
                    "age_years": arr["t"],
                    "D_act_emp": ctx["d_act_grid"],
                    "V_ASD": ctx["V_ASD_grid"],
                    "V_SCZ": ctx["V_SCZ_grid"],
                    "alpha_syn": ctx["alpha_grid"],
                    "beta_prun": ctx["beta_grid"],
                    "chi_delta4": arr["chi"],
                    "L": arr["L"],
                    "S": arr["S"],
                    "Phi": arr["Phi"],
                    "Ns": arr["Ns"],
                    "L_ASD_cum": arr["L_ASD"],
                    "L_SCZ_cum": arr["L_SCZ"],
                }
            )
        )
    df_traj = pd.concat(traj_frames, ignore_index=True)
    df_traj.to_csv(RESULTS_DIR / "ctl_trajectories.csv", index=False)

    # 3. Generate 2D Phase Diagrams
    df_tau_chi, df_prs_chi = generate_phase_grids(ctx)
    df_tau_chi.to_csv(RESULTS_DIR / "phase_grid_tau_chi.csv", index=False)
    df_prs_chi.to_csv(RESULTS_DIR / "phase_grid_prs_chi.csv", index=False)

    # 4. Compute Reversibility curve R_ASD(tau_rx) vs R_SCZ(tau_rx) for d_SSO=1.0
    tau_rx_list = [-0.4, 0.0, 0.5, 1.0, 2.0, 3.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0, 22.0, 25.0]
    rev_rows = []
    # Pathogenic baselines: ASD (chi=0.45, P_ASD=0.5, P_SCZ=0), SCZ (chi=0.38, P_ASD=0, P_SCZ=1.5)
    phi_asd_u = eval_qss_phi_vec(np.full_like(t_g, 0.45), ctx["d_act_grid"], ctx["p1"])[None, :]
    ga_a = eq9_polygenic_amplification(np.array([0.5]), p23["gamma_ASD"], p23["c_P"])[:, None]
    gs_a = eq9_polygenic_amplification(np.array([0.0]), p23["gamma_SCZ"], p23["c_P"])[:, None]
    ns_asd_u = solve_ns_crank_nicolson(phi_asd_u, ga_a, gs_a, ctx)
    l_asd_untreat = float(compute_liabilities_and_regimes(phi_asd_u, ns_asd_u, np.array([0.5]), np.array([0.0]), ga_a, gs_a, ctx)["L_ASD_final"][0])

    phi_asd_b = ctx["Phi_ctrl_qss_grid"][None, :]
    ns_asd_b = solve_ns_crank_nicolson(phi_asd_b, ga_a, gs_a, ctx)
    l_asd_base = float(compute_liabilities_and_regimes(phi_asd_b, ns_asd_b, np.array([0.5]), np.array([0.0]), ga_a, gs_a, ctx)["L_ASD_final"][0])

    phi_scz_u = eval_qss_phi_vec(np.full_like(t_g, 0.38), ctx["d_act_grid"], ctx["p1"])[None, :]
    ga_s = eq9_polygenic_amplification(np.array([0.0]), p23["gamma_ASD"], p23["c_P"])[:, None]
    gs_s = eq9_polygenic_amplification(np.array([1.5]), p23["gamma_SCZ"], p23["c_P"])[:, None]
    ns_scz_u = solve_ns_crank_nicolson(phi_scz_u, ga_s, gs_s, ctx)
    l_scz_untreat = float(compute_liabilities_and_regimes(phi_scz_u, ns_scz_u, np.array([0.0]), np.array([1.5]), ga_s, gs_s, ctx)["L_SCZ_final"][0])

    ns_scz_b = solve_ns_crank_nicolson(phi_asd_b, ga_s, gs_s, ctx)
    l_scz_base = float(compute_liabilities_and_regimes(phi_asd_b, ns_scz_b, np.array([0.0]), np.array([1.5]), ga_s, gs_s, ctx)["L_SCZ_final"][0])

    for trx in tau_rx_list:
        chi_rx_a = eq15_chi_sso_rescue(t_g, 0.45, trx, 1.0, k_sso=p23["K_SSO"])[None, :]
        phi_rx_a = eval_qss_phi_vec(chi_rx_a, ctx["d_act_grid"], ctx["p1"])
        ns_rx_a = solve_ns_crank_nicolson(phi_rx_a, ga_a, gs_a, ctx)
        l_rx_a = float(compute_liabilities_and_regimes(phi_rx_a, ns_rx_a, np.array([0.5]), np.array([0.0]), ga_a, gs_a, ctx)["L_ASD_final"][0])

        chi_rx_s = eq15_chi_sso_rescue(t_g, 0.38, trx, 1.0, k_sso=p23["K_SSO"])[None, :]
        phi_rx_s = eval_qss_phi_vec(chi_rx_s, ctx["d_act_grid"], ctx["p1"])
        ns_rx_s = solve_ns_crank_nicolson(phi_rx_s, ga_s, gs_s, ctx)
        l_rx_s = float(compute_liabilities_and_regimes(phi_rx_s, ns_rx_s, np.array([0.0]), np.array([1.5]), ga_s, gs_s, ctx)["L_SCZ_final"][0])

        rev_rows.append(
            {
                "tau_rx_yr": float(trx),
                "R_ASD_at_chi0.45": eq16_reversibility_index(l_rx_a, l_asd_untreat, l_asd_base),
                "R_SCZ_at_chi0.38": eq16_reversibility_index(l_rx_s, l_scz_untreat, l_scz_base),
            }
        )

    ctrl_bm = bench_summary["Control_0.30"]
    tc_counts = df_tau_chi.groupby(["background", "regime"]).size().unstack(fill_value=0).to_dict(orient="index")
    pc_counts = df_prs_chi.groupby(["slice_name", "regime"]).size().unstack(fill_value=0).to_dict(orient="index")

    payload = {
        "metadata": {
            "framework": "Condensate-Timing-Liability (CTL) Scales 2-3",
            "seed": SEED,
            "equations": [f"Eq. ({i})" for i in range(7, 17)],
            "time_domain_years": [ctx["t0"], ctx["t1"]],
            "days_per_year": DAYS_PER_YEAR,
            "data_sources": [
                "results/biophysical_calibration.json",
                "results/brainspan_empirical_kernels.csv",
            ],
        },
        "parameters": p23,
        "huttenlocher_petanjek_control_landmarks": {
            "Ns_birth_0yr": ctrl_bm["Ns_birth_0yr"],
            "Ns_childhood_peak": ctrl_bm["Ns_peak"],
            "t_peak_yr": ctrl_bm["t_peak_yr"],
            "Ns_adult_30yr": ctrl_bm["Ns_adult_30yr"],
            "adolescent_pruning_decline_pct": ctrl_bm["pruning_decline_pct"],
        },
        "vulnerability_kernel_summary": {
            "V_ASD_peak_yr": float(t_g[int(np.argmax(ctx["V_ASD_grid"]))]),
            "V_ASD_mass_le_6yr": float(np.trapezoid(ctx["V_ASD_grid"][t_g <= 6.0], t_g[t_g <= 6.0])),
            "V_SCZ_peak_yr": float(t_g[int(np.argmax(ctx["V_SCZ_grid"]))]),
            "V_SCZ_mass_12_to_26yr": float(
                np.trapezoid(ctx["V_SCZ_grid"][(t_g >= 12.0) & (t_g <= 26.0)], t_g[(t_g >= 12.0) & (t_g <= 26.0)])
            ),
            "D_act_emp_peak_yr": float(t_g[int(np.argmax(ctx["d_act_grid"]))]),
        },
        "numerical_verification": num_verif,
        "benchmark_scenarios": bench_summary,
        "phase_regime_counts_tau_chi": tc_counts,
        "phase_regime_counts_prs_chi": pc_counts,
        "sso_reversibility_summary": rev_rows,
    }

    (RESULTS_DIR / "ctl_phase_diagrams.json").write_text(
        json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8"
    )
    print(
        f"[3/4] Control landmarks: Ns(0)={ctrl_bm['Ns_birth_0yr']:.4f}, "
        f"Ns_max={ctrl_bm['Ns_peak']:.4f} @ {ctrl_bm['t_peak_yr']:.2f}yr, "
        f"Ns(30)={ctrl_bm['Ns_adult_30yr']:.4f} (decline {ctrl_bm['pruning_decline_pct']:.2f}%)",
        flush=True,
    )
    print(f"[4/4] Saved ctl_phase_diagrams.json & 3 CSVs in {time.time() - t_start:.2f}s", flush=True)
    return payload


if __name__ == "__main__":
    run_all()
