#!/usr/bin/env python3
"""
Step 5 (Part 1 & Part 2): Publication-Grade Figure Generation
==============================================================
Generates Nature / Cell / Science standard figures in `figures/` in three formats:
- 600 DPI PNG (`Figure_X.png`)
- Vector PDF (`Figure_X.pdf`, editable Type 42 fonts)
- Vector SVG (`Figure_X.svg`, editable text)

Every number, confidence interval, curve, data point, and P-value is read
programmatically from `results/` and `data/processed/` (and verified UniProt
JSON for sequence coordinates). Zero hardcoded or invented values.

Usage:
    python src/07_generate_figures.py --figs 1 2 3 s1
    python src/07_generate_figures.py --figs all
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib as mpl
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.lines import Line2D
from scipy import integrate, stats

# ---------------------------------------------------------------------------
# Paths & Global Publication Styling
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PROC = BASE_DIR / "data" / "processed"
DATA_RAW = BASE_DIR / "data" / "raw"
RESULTS_DIR = BASE_DIR / "results"
FIG_DIR = BASE_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# Okabe-Ito color-blind-safe palette
OI = {
    "blue": "#0072B2",
    "vermilion": "#D55E00",
    "green": "#009E73",
    "orange": "#E69F00",
    "purple": "#CC79A7",
    "sky": "#56B4E9",
    "yellow": "#F0E442",
    "black": "#000000",
    "gray": "#7F7F7F",
    "lightgray": "#D9D9D9",
}


def set_pub_style() -> None:
    """Configure clean Nature/Cell/Science matplotlib rcParams."""
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans", "Helvetica"],
            "font.size": 8.5,
            "axes.titlesize": 9.5,
            "axes.titleweight": "bold",
            "axes.labelsize": 8.5,
            "axes.labelweight": "normal",
            "xtick.labelsize": 7.8,
            "ytick.labelsize": 7.8,
            "legend.fontsize": 7.5,
            "legend.frameon": False,
            "axes.linewidth": 0.8,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "xtick.major.size": 3.5,
            "ytick.major.size": 3.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.08,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )


def despine(ax: plt.Axes, keep_right: bool = False) -> None:
    ax.spines["top"].set_visible(False)
    if not keep_right:
        ax.spines["right"].set_visible(False)


def add_panel_label(ax: plt.Axes, label: str, x: float = -0.14, y: float = 1.06) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        fontsize=12,
        fontweight="bold",
        va="bottom",
        ha="left",
        color="black",
    )


def fmt_p(p: float, in_math: bool = False) -> str:
    if p is None or not np.isfinite(p):
        return "NA"
    if p < 1e-4:
        exp = int(math.floor(math.log10(max(p, 1e-300))))
        mant = p / (10.0 ** exp)
        if round(mant, 2) >= 10.0:
            mant = 1.0
            exp += 1
        if in_math:
            return f"{mant:.2f}\\times 10^{{{exp}}}"
        return f"{mant:.2f}×10$^{{{exp}}}$"
    if p < 0.01:
        return f"{p:.4f}"
    return f"{p:.3f}"


def save_figure(fig: plt.Figure, stem: str) -> List[Path]:
    paths: List[Path] = []
    for ext, kw in [
        ("png", {"dpi": 600}),
        ("pdf", {}),
        ("svg", {}),
    ]:
        out = FIG_DIR / f"{stem}.{ext}"
        fig.savefig(out, format=ext, **kw)
        paths.append(out)
        print(f"  Saved {out} ({out.stat().st_size:,} bytes)")
    plt.close(fig)
    return paths


# ---------------------------------------------------------------------------
# Biophysical Helper Equations (matching src/03_biophysical_calibration.py)
# ---------------------------------------------------------------------------
def _eq1_f_hplus(ph: np.ndarray | float, pka: float) -> np.ndarray | float:
    return 1.0 / (1.0 + np.power(10.0, np.asarray(ph) - pka))


def _eq2_chi_c_of_ph(ph: np.ndarray | float, chi_c_ref: float, pka: float, ph_ref: float = 8.0) -> np.ndarray | float:
    f_deprot_ref = 1.0 - _eq1_f_hplus(ph_ref, pka)
    f_deprot = 1.0 - _eq1_f_hplus(ph, pka)
    return chi_c_ref * (f_deprot_ref / f_deprot)


def _hill_norm(chi: np.ndarray | float, chi_c: float, n_h: float) -> np.ndarray | float:
    x = np.maximum(np.asarray(chi, dtype=float), 0.0)
    num = np.power(x, n_h)
    return num / (num + np.power(chi_c, n_h))


def _eq4_to_6_phi_star(
    chi: np.ndarray, d_act: float, params: Dict[str, Any], ph: float = 8.0
) -> np.ndarray:
    chi_c_ph = float(_eq2_chi_c_of_ph(ph, params["chi_c_ref_pH8"], params["pKa_His"], params["pH_ref"]))
    a_norm = _hill_norm(chi, chi_c_ph, params["n_H"])
    b_val = 1.0 + (params["k_diss"] * params["R_rev"] * d_act) / params["k_form"]
    c_val = params["k_lock"] * (1.0 + params["lambda_D"] * d_act) / params["k_clr"]
    beta = 1.0 + params["k_clr"] / params["k_form"]
    denom = b_val + beta * c_val * a_norm
    l_star = 1.0 / denom
    s_star = (c_val * a_norm) / denom
    return 1.0 - params["eta_S"] * s_star - params["eta_L"] * l_star


# ---------------------------------------------------------------------------
# Figure 1: Scale 1 Biophysical Architecture & Cooperative Heterotypic Buffering
# ---------------------------------------------------------------------------
def plot_figure_1() -> List[Path]:
    print("Generating Figure_1...")
    cal = json.loads((RESULTS_DIR / "biophysical_calibration.json").read_text(encoding="utf-8"))
    seq_info = json.loads((DATA_PROC / "cpeb4_sequence_and_literature_verified.json").read_text(encoding="utf-8"))
    uniprot = json.loads((DATA_RAW / "uniprot" / "Q17RY0.json").read_text(encoding="utf-8"))

    msel = pd.read_csv(RESULTS_DIR / "biophysical_model_selection.csv")
    boot = pd.read_csv(RESULTS_DIR / "biophysical_bootstrap_samples.csv")
    f4 = pd.read_csv(DATA_PROC / "gc25_fig4_tc_and_agg.csv")
    ed6 = pd.read_csv(DATA_PROC / "gc25_edfig6_ph_and_agg.csv")
    kin = pd.read_csv(DATA_PROC / "gc25_proteostat_and_kinetics.csv")

    fig = plt.figure(figsize=(14.2, 10.4))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.34, wspace=0.30)

    # --- Panel a: Domain Schematic & Competitive Heterotypic Buffering ---
    ax_a = fig.add_subplot(gs[0, 0])
    ax_a.set_xlim(-25, 765)
    ax_a.set_ylim(-0.05, 1.08)
    ax_a.axis("off")
    add_panel_label(ax_a, "a", x=-0.05, y=1.02)

    L_aa = int(seq_info["canonical_length_aa"])
    acc = seq_info["uniprot_accession"]
    ax_a.set_title(
        f"Human CPEB4 ({acc}, {L_aa} aa) & Heterotypic Buffering",
        loc="left",
        fontsize=9.5,
        pad=6,
    )

    # Extract exact domain coordinates from UniProt + verified sequence JSON
    disordered_regs = []
    rrm_regs = []
    for feat in uniprot.get("features", []):
        ftype = feat.get("type", "")
        desc = feat.get("description", "")
        st = feat.get("location", {}).get("start", {}).get("value")
        en = feat.get("location", {}).get("end", {}).get("value")
        if ftype == "Region" and desc == "Disordered" and st and en:
            disordered_regs.append((int(st), int(en)))
        elif ftype == "Domain" and desc.startswith("RRM") and st and en:
            rrm_regs.append((desc, int(st), int(en)))

    hc = seq_info["histidine_cluster_uniprot"]
    hc_st, hc_en = int(hc["start"]), int(hc["end"])
    ex3_st, ex3_en = 403, 419
    for af in seq_info["isoform_alternative_features"]:
        if af["feature_id"] == "VSP_022041":
            ex3_st, ex3_en = int(af["start"]), int(af["end"])
    me4_st, me4_en = [int(x) for x in seq_info["microexon4_aa_coordinates_1based"]]
    me4_seq = seq_info["microexon4_aa_sequence"]
    nmr_pka = cal["eq1_protonation_and_heterotypic_buffering"]["nmr_his_pka_fig2d"]

    y_bar = 0.72
    h_bar = 0.11
    # Backbone NTD + C-terminal
    ax_a.add_patch(
        mpatches.Rectangle(
            (1, y_bar), L_aa - 1, h_bar,
            facecolor="#F2F2F2", edgecolor="#404040", linewidth=0.9,
        )
    )
    # Disordered regions
    for st, en in disordered_regs:
        ax_a.add_patch(
            mpatches.Rectangle(
                (st, y_bar + 0.01), en - st, h_bar - 0.02,
                facecolor=OI["sky"], alpha=0.35, edgecolor=OI["blue"],
                linewidth=0.6, hatch="///",
            )
        )
    # HClust
    ax_a.add_patch(
        mpatches.Rectangle(
            (hc_st, y_bar - 0.01), hc_en - hc_st + 1, h_bar + 0.02,
            facecolor=OI["vermilion"], edgecolor="black", linewidth=0.8, zorder=4,
        )
    )
    # Exon 3
    ax_a.add_patch(
        mpatches.Rectangle(
            (ex3_st, y_bar), ex3_en - ex3_st + 1, h_bar,
            facecolor=OI["orange"], edgecolor="black", linewidth=0.7, zorder=4,
        )
    )
    # Microexon 4
    ax_a.add_patch(
        mpatches.Rectangle(
            (me4_st, y_bar - 0.015), max(me4_en - me4_st + 1, 10), h_bar + 0.03,
            facecolor=OI["blue"], edgecolor="black", linewidth=0.9, zorder=5,
        )
    )
    # RRM1 & RRM2
    for rname, st, en in rrm_regs:
        ax_a.add_patch(
            mpatches.Rectangle(
                (st, y_bar), en - st, h_bar,
                facecolor=OI["green"], alpha=0.85, edgecolor="black", linewidth=0.8, zorder=4,
            )
        )
        ax_a.text(
            (st + en) / 2, y_bar + h_bar / 2, rname,
            ha="center", va="center", fontsize=7.5, fontweight="bold", color="white", zorder=6,
        )

    # Coordinate ticks & callouts
    ax_a.text(1, y_bar - 0.055, "1", ha="center", va="top", fontsize=7.2, color="#404040")
    ax_a.text(L_aa, y_bar - 0.055, f"{L_aa} aa", ha="center", va="top", fontsize=7.2, color="#404040")
    ax_a.text(225, y_bar + h_bar + 0.03, "NTD (IDR)", ha="center", va="bottom", fontsize=7.5, color="#333333")
    ax_a.text(567, y_bar + h_bar + 0.03, f"RRM1/2 ({rrm_regs[0][1]}–{rrm_regs[-1][2]})", ha="center", va="bottom", fontsize=7.5, color=OI["green"], fontweight="bold")

    ax_a.annotate(
        f"HClust ({hc_st}–{hc_en})\n{hc['histidine_count']} His, p$K_a$={nmr_pka['mean']:.2f}±{nmr_pka['sd']:.2f}",
        xy=((hc_st + hc_en) / 2, y_bar + h_bar + 0.01),
        xytext=(135, 0.94),
        ha="center", va="bottom", fontsize=7.3, color=OI["vermilion"], fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=OI["vermilion"], lw=0.9),
    )
    ax_a.annotate(
        f"Exon 3 ({ex3_st}–{ex3_en})",
        xy=((ex3_st + ex3_en) / 2, y_bar),
        xytext=(330, 0.54),
        ha="center", va="top", fontsize=7.2, color=OI["orange"], fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=OI["orange"], lw=0.8),
    )
    ax_a.annotate(
        f"Me4 ({me4_st}–{me4_en}): {me4_seq} (+4 Arg)",
        xy=((me4_st + me4_en) / 2, y_bar + h_bar + 0.015),
        xytext=(515, 0.94),
        ha="center", va="bottom", fontsize=7.3, color=OI["blue"], fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=OI["blue"], lw=0.9),
    )

    # Bottom schematic boxes: Competitive heterotypic vs homotypic shift
    daic_het = cal["eq1_protonation_and_heterotypic_buffering"]["heterotypic_buffering_limit_test"]["delta_aic_finite_vs_tight"]
    rrev = cal["empirical_kinetics_and_in_vivo_bounds"]["fig2b_2c_kcl_depolarization"]["empirical_reversibility_R_rev"]
    chi_c_val = cal["eq2_cooperative_hill_aggregation"]["pooled_all"]["parameters"]["chi_c"]["point_estimate"]
    nh_val = cal["eq2_cooperative_hill_aggregation"]["pooled_all"]["parameters"]["n_H"]["point_estimate"]

    box_l = mpatches.Rectangle(
        (0, 0.03), 348, 0.36,
        facecolor="#EBF5FB", edgecolor=OI["blue"], linewidth=1.2,
    )
    box_r = mpatches.Rectangle(
        (398, 0.03), 352, 0.36,
        facecolor="#FDF2E9", edgecolor=OI["vermilion"], linewidth=1.2,
    )
    ax_a.add_patch(box_l)
    ax_a.add_patch(box_r)

    ax_a.text(
        174, 0.35,
        "Buffered Regime ($\\chi_{\\Delta 4} = 0.30 < \\chi_c$)",
        ha="center", va="top", fontsize=7.9, fontweight="bold", color=OI["blue"],
    )
    ax_a.text(
        174, 0.26,
        f"Me4 Arg(+) caps HClust ($\\kappa_{{het}}\\to 0^+$, $\\Delta$AIC={daic_het:.2f})\n"
        f"Liquid-like droplets; activity-reversible\n($R_{{rev}}$ = {rrev:.3f})",
        ha="center", va="top", fontsize=7.2, color="#222222", linespacing=1.35,
    )
    ax_a.text(
        574, 0.35,
        f"Cooperative Collapse ($\\chi_{{\\Delta 4}} = 0.45 > \\chi_c={chi_c_val:.3f}$)",
        ha="center", va="top", fontsize=7.9, fontweight="bold", color=OI["vermilion"],
    )
    ax_a.text(
        574, 0.26,
        "Unbuffered HClust: $u = \\chi_{\\Delta 4}(1 - f_{H^+}(\\mathrm{pH}))$\n"
        f"Cooperative His–His locking ($n_H = {nh_val:.2f}$)\n"
        "$\\rightarrow$ Solid-like aggregates & mRNA sequestration",
        ha="center", va="top", fontsize=7.2, color="#222222", linespacing=1.35,
    )
    ax_a.annotate(
        "", xy=(394, 0.21), xytext=(352, 0.21),
        arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.4", color="black", lw=1.4),
    )

    # --- Panel b: Fig 4c Linear Tc vs Fig 4d Cooperative Hill A_eq + M1-M4 Inset ---
    ax_b = fig.add_subplot(gs[0, 1])
    add_panel_label(ax_b, "b", x=-0.13, y=1.06)

    f4d = f4[f4["source_sheet"] == "Fig.4d"].copy()
    f4c = f4[f4["source_sheet"] == "Fig.4c"].copy()
    pooled_res = cal["eq2_cooperative_hill_aggregation"]["pooled_all"]
    a_min = pooled_res["parameters"]["A_min"]["point_estimate"]
    a_max = pooled_res["parameters"]["A_max"]["point_estimate"]
    chi_c = pooled_res["parameters"]["chi_c"]["point_estimate"]
    n_h = pooled_res["parameters"]["n_H"]["point_estimate"]
    r2_hill = pooled_res["fit_metrics"]["r2"]

    chi_grid = np.linspace(0.0, 1.0, 400)
    y_hill = a_min + (a_max - a_min) * _hill_norm(chi_grid, chi_c, n_h)

    # 95% bootstrap ribbon from biophysical_bootstrap_samples.csv
    b_pool = boot[boot["dataset"] == "pooled_all"]
    b_curves = (
        b_pool["A_min"].values[:, None]
        + (b_pool["A_max"].values[:, None] - b_pool["A_min"].values[:, None])
        * _hill_norm(chi_grid[None, :], b_pool["chi_c"].values[:, None], b_pool["n_H"].values[:, None])
    )
    ci_lo = np.percentile(b_curves, 2.5, axis=0)
    ci_hi = np.percentile(b_curves, 97.5, axis=0)

    ax_b.fill_between(chi_grid, ci_lo, ci_hi, color=OI["sky"], alpha=0.28, label="95% bootstrap CI")
    ax_b.plot(chi_grid, y_hill, color=OI["blue"], lw=2.0, linestyle="-", label=f"Hill M4 ($n_H={n_h:.2f}$, $R^2={r2_hill:.3f}$)")

    # Plot raw Fig 4d data with distinct markers per channel
    ch_styles = {
        "nCPEB4_DL488": ("o", OI["blue"], "nCPEB4-DL488"),
        "nCPEB4d4_AF647": ("s", OI["sky"], "nCPEB4$\\Delta 4$-AF647"),
    }
    rng_jit = np.random.default_rng(1)
    for ch, (mk, col, lbl) in ch_styles.items():
        sub = f4d[f4d["channel"] == ch]
        xj = sub["chi_delta4"].values + rng_jit.uniform(-0.008, 0.008, size=len(sub))
        ax_b.scatter(
            xj, sub["value"].values, marker=mk, s=22,
            facecolor=col, edgecolor="white", linewidth=0.4, alpha=0.72, zorder=3, label=lbl,
        )

    # Twin axis for Fig 4c Tc
    ax_b2 = ax_b.twinx()
    ax_b2.patch.set_visible(False)
    ax_b2.spines["top"].set_visible(False)
    tc_fit = cal["eq3_linear_cloud_point_thermodynamics"]["fig4c_linear_fit"]
    tc_0 = tc_fit["T_c0_C"]
    gamma_t = tc_fit["gamma_T_C_per_chi"]
    r2_tc = tc_fit["r2_replicate_level"]
    ax_b2.scatter(
        f4c["chi_delta4"].values, f4c["value"].values,
        marker="D", s=26, facecolor=OI["vermilion"], edgecolor="black", linewidth=0.4, alpha=0.85, zorder=4,
        label="Cloud point $T_c$ (Fig. 4c)",
    )
    ax_b2.plot(
        chi_grid, tc_0 + gamma_t * chi_grid,
        color=OI["vermilion"], lw=1.7, linestyle="--",
        label=f"Linear $T_c$ ($R^2={r2_tc:.3f}$)",
    )

    # Vertical callouts at Ctrl (0.30) and ASD (0.45)
    fold_j = pooled_res["benchmark_predictions_pH8"]["fold_jump_asd_over_ctrl"]
    dtc = cal["eq3_linear_cloud_point_thermodynamics"]["thermodynamic_vs_aggregation_contrast_ctrl_to_asd"]["delta_Tc_C"]
    ax_b.axvline(0.30, color=OI["green"], linestyle=":", lw=1.1, alpha=0.85)
    ax_b.axvline(0.45, color=OI["purple"], linestyle=":", lw=1.1, alpha=0.85)
    ax_b.axvline(chi_c, color="black", linestyle="-.", lw=0.9, alpha=0.6)
    ax_b.text(0.285, 13.5, "Ctrl\n0.30", ha="right", va="top", fontsize=7.0, color=OI["green"], fontweight="bold")
    ax_b.text(0.465, 26.8, "ASD\n0.45", ha="left", va="top", fontsize=7.0, color=OI["purple"], fontweight="bold")

    ax_b.annotate(
        f"$A_{{eq}}$: {fold_j:.2f}$\\times$ jump\n($\\Delta T_c = +{dtc:.2f}\\,^\\circ$C)",
        xy=(0.435, 17.5),
        xytext=(0.56, 25.0),
        fontsize=7.3, fontweight="bold", color="#222222", zorder=10,
        arrowprops=dict(arrowstyle="->", color="black", lw=0.9),
        bbox=dict(boxstyle="round,pad=0.25", fc="#FFFFFF", ec="#999999", lw=0.7, alpha=0.96),
    )

    ax_b.set_xlim(-0.04, 1.04)
    ax_b.set_ylim(-0.8, 29.2)
    ax_b2.set_ylim(20.0, 50.0)
    ax_b.set_xlabel("CPEB4$\\Delta 4$ mole fraction ($\\chi_{\\Delta 4}$)")
    ax_b.set_ylabel("Equilibrium Aggregation $A_{eq}$ (%)", color=OI["blue"])
    ax_b2.set_ylabel("Cloud Point $T_c$ ($^\\circ$C)", color=OI["vermilion"])
    ax_b.tick_params(axis="y", colors=OI["blue"])
    ax_b2.tick_params(axis="y", colors=OI["vermilion"])
    ax_b.grid(True, linestyle=":", alpha=0.25)
    ax_b.set_title("Linear $T_c$ vs. Cooperative Aggregation Switch", loc="left", pad=8)

    # Combined clean legend at top-left
    h1, l1 = ax_b.get_legend_handles_labels()
    h2, l2 = ax_b2.get_legend_handles_labels()
    ax_b.legend(
        [h1[0], h1[2], h1[3], h2[0], h2[1]],
        [l1[0], l1[2], l1[3], l2[0], l2[1]],
        loc="upper left", fontsize=6.8, handlelength=1.8, borderaxespad=0.2,
    )

    # Inset: Model selection M1-M4 Delta AIC
    ms_pool = msel[msel["dataset"] == "pooled_all"].copy()
    order_m = ["M1_Linear", "M2_ExpSaturating", "M3_MichaelisMenten", "M4_CooperativeHill"]
    ms_pool["model_id"] = pd.Categorical(ms_pool["model_id"], categories=order_m, ordered=True)
    ms_pool = ms_pool.sort_values("model_id")
    ax_ins_b = ax_b.inset_axes([0.58, 0.14, 0.37, 0.35])
    bar_cols = [OI["gray"], OI["gray"], OI["gray"], OI["blue"]]
    x_m = np.arange(4)
    ax_ins_b.bar(x_m, ms_pool["delta_aic"].values, color=bar_cols, edgecolor="black", linewidth=0.6, width=0.62)
    ax_ins_b.set_xticks(x_m)
    ax_ins_b.set_xticklabels(["M1", "M2", "M3", "M4"], fontsize=6.8)
    ax_ins_b.set_ylabel("$\\Delta$AIC", fontsize=7.0, labelpad=1)
    ax_ins_b.set_ylim(0, max(ms_pool["delta_aic"].values) * 1.25)
    ax_ins_b.tick_params(axis="y", labelsize=6.5)
    despine(ax_ins_b)
    w_m4 = ms_pool.loc[ms_pool["model_id"] == "M4_CooperativeHill", "akaike_weight"].values[0]
    ax_ins_b.text(3, 8, f"$w_{{M4}}$>\n0.999999", ha="center", va="bottom", fontsize=6.3, fontweight="bold", color=OI["blue"])
    ax_ins_b.set_title(
        "Model Selection", fontsize=7.2, pad=3,
        bbox=dict(boxstyle="round,pad=0.14", fc="white", ec="none", alpha=0.88),
    )

    # --- Panel c: Cross-pH Validation (ED Fig 6e Day 1) + KCl Reversibility Inset ---
    ax_c = fig.add_subplot(gs[1, 0])
    add_panel_label(ax_c, "c", x=-0.13, y=1.06)

    e6e_d1 = ed6[(ed6["source_sheet"] == "ED Fig.6e") & (ed6["day"] == 1.0)].copy()
    chi_map = {"nCPEB4": 0.0, "Ctrl_ratio": 0.30, "ASD_ratio": 0.45, "nCPEB4d4": 1.0}
    e6e_d1["chi"] = e6e_d1["condition"].map(chi_map)
    xval_info = cal["empirical_kinetics_and_in_vivo_bounds"]["edfig6e_ph_and_time"]["zero_free_shape_eq1_eq2_day1_validation"]
    pka_mean = xval_info["pKa_from_fig2d"]
    amp_min = xval_info["fitted_amplitude_A_min_pct"]
    amp_max = xval_info["fitted_amplitude_A_max_pct"]
    r2_xph = xval_info["r2_cross_ph"]
    p_xph = xval_info["p_value"]
    chi_c_ph6 = xval_info["chi_c_predicted_pH6"]

    # Predicted zero-free-shape curves at pH 8.0 and pH 6.0
    y_pred_ph8 = amp_min + (amp_max - amp_min) * _hill_norm(chi_grid, chi_c, n_h)
    y_pred_ph6 = amp_min + (amp_max - amp_min) * _hill_norm(chi_grid, chi_c_ph6, n_h)
    ax_c.plot(chi_grid, y_pred_ph8, color=OI["vermilion"], lw=2.0, linestyle="-", label=f"Eq.(1–2) pred pH 8.0 ($\\chi_c={chi_c:.3f}$)")
    ax_c.plot(chi_grid, y_pred_ph6, color=OI["blue"], lw=1.8, linestyle="--", label=f"Eq.(1–2) pred pH 6.0 ($\\chi_c={chi_c_ph6:.2f}$)")

    for ph_val, mk, col, lbl, dx in [
        (8.0, "o", OI["vermilion"], "Day 1 pH 8.0 (obs FOVs)", 0.012),
        (6.0, "^", OI["blue"], "Day 1 pH 6.0 (obs FOVs)", -0.012),
    ]:
        sub = e6e_d1[e6e_d1["pH"] == ph_val]
        xj = sub["chi"].values + dx + rng_jit.uniform(-0.008, 0.008, size=len(sub))
        ax_c.scatter(
            xj, sub["value_numeric"].values, marker=mk, s=22,
            facecolor=col, edgecolor="white", linewidth=0.4, alpha=0.68, label=lbl, zorder=3,
        )
        # Mean +/- SD error bars
        grp = sub.groupby("chi")["value_numeric"].agg(["mean", "std"]).reset_index()
        ax_c.errorbar(
            grp["chi"].values + dx, grp["mean"].values, yerr=grp["std"].values,
            fmt=mk, color="black", mfc=col, mec="black", ms=5.5, capsize=3, lw=1.0, zorder=5,
        )

    ax_c.text(
        0.53, 0.56,
        f"Zero-free-shape validation\n($n={xval_info['n_fov']}$ FOVs)\n$R^2 = {r2_xph:.3f}$, $P = {fmt_p(p_xph, in_math=True)}$",
        transform=ax_c.transAxes, fontsize=7.0, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="#FFFFFF", ec="#BBBBBB", lw=0.7, alpha=0.96),
    )
    ax_c.set_xlim(-0.06, 1.06)
    ax_c.set_ylim(-1.0, 16.5)
    ax_c.set_xlabel("CPEB4$\\Delta 4$ mole fraction ($\\chi_{\\Delta 4}$)")
    ax_c.set_ylabel("Day 1 Aggregation Area (%)")
    ax_c.grid(True, linestyle=":", alpha=0.25)
    despine(ax_c)
    ax_c.set_title("Cross-pH Prediction & Depolarization Reversibility", loc="left", pad=8)
    ax_c.legend(loc="lower right", fontsize=6.9, handlelength=1.8)

    # Inset: Fig 2b & 2c KCl depolarization kinetics
    f2b = kin[kin["source_sheet"] == "Fig.2b"].groupby("x_val")["y_val"].agg(["mean", "sem"]).reset_index()
    f2c = kin[kin["source_sheet"] == "Fig.2c"].groupby("x_val")["y_val"].agg(["mean", "sem"]).reset_index()
    kcl_info = cal["empirical_kinetics_and_in_vivo_bounds"]["fig2b_2c_kcl_depolarization"]
    ax_ins_c = ax_c.inset_axes([0.11, 0.50, 0.37, 0.38])
    ax_ins_c.errorbar(
        f2b["x_val"], f2b["mean"], yerr=f2b["sem"],
        fmt="-o", color=OI["blue"], ms=2.4, lw=1.2, capsize=1.4, label="Cond. frac",
    )
    ax_ins_c2 = ax_ins_c.twinx()
    ax_ins_c2.patch.set_visible(False)
    ax_ins_c2.spines["top"].set_visible(False)
    ax_ins_c2.errorbar(
        f2c["x_val"], f2c["mean"], yerr=f2c["sem"],
        fmt="--s", color=OI["vermilion"], ms=2.2, lw=1.1, capsize=1.4, label="$\\Delta$pH",
    )
    ax_ins_c.set_xlabel("KCl time (min)", fontsize=6.6, labelpad=1)
    ax_ins_c.set_ylabel("Cond. frac", fontsize=6.6, color=OI["blue"], labelpad=1)
    ax_ins_c2.set_ylabel("$\\Delta$pH", fontsize=6.6, color=OI["vermilion"], labelpad=1)
    ax_ins_c.tick_params(labelsize=6.0)
    ax_ins_c2.tick_params(labelsize=6.0, colors=OI["vermilion"])
    ax_ins_c.spines["top"].set_visible(False)
    ax_ins_c.set_title(
        f"KCl: $R_{{rev}}$={kcl_info['empirical_reversibility_R_rev']:.3f}, $r$={kcl_info['delta_ph_vs_condensed_fraction_common_t']['pearson_r']:.3f}",
        fontsize=6.6, pad=2, fontweight="bold",
    )

    # --- Panel d: Activity-Shifted Locking Threshold Phi*(chi_delta4) (Eqs. 4-6) ---
    ax_d = fig.add_subplot(gs[1, 1])
    add_panel_label(ax_d, "d", x=-0.13, y=1.06)

    ode_p = cal["eq4_to_eq6_ode_parameters_and_provenance"]["parameters"]
    th_info = cal["eq4_to_eq6_analytical_and_numerical_verification"]["threshold_shift_W1_to_W2"]
    qss_info = cal["eq4_to_eq6_analytical_and_numerical_verification"]["benchmark_qss_states"]

    chi_d = np.linspace(0.20, 0.55, 500)
    phi_w1 = _eq4_to_6_phi_star(chi_d, ode_p["D_act_W1_childhood"], ode_p)
    phi_w2 = _eq4_to_6_phi_star(chi_d, ode_p["D_act_W2_adolescent_PFC"], ode_p)

    # Regime shading
    ax_d.axvspan(0.20, 0.33, color=OI["green"], alpha=0.08, label="Protected zone")
    ax_d.axvspan(0.35, 0.415, color=OI["orange"], alpha=0.12, label="Compensation-to-collapse")
    ax_d.axvspan(0.425, 0.55, color=OI["vermilion"], alpha=0.09, label="Overt ASD zone")

    chi_eff_w1 = th_info["W1_childhood"]["chi_c_eff_Phi_half"]
    chi_eff_w2 = th_info["W2_adolescent_PFC"]["chi_c_eff_Phi_half"]

    ax_d.plot(
        chi_d, phi_w1, color=OI["blue"], lw=2.2, linestyle="-",
        label=f"Childhood ($D_{{act}}={ode_p['D_act_W1_childhood']:.2f}$, $\\chi_c^{{eff}}={chi_eff_w1:.4f}$)",
    )
    ax_d.plot(
        chi_d, phi_w2, color=OI["vermilion"], lw=2.2, linestyle="--",
        label=f"Adol. PFC ($D_{{act}}={ode_p['D_act_W2_adolescent_PFC']:.2f}$, $\\chi_c^{{eff}}={chi_eff_w2:.4f}$)",
    )
    ax_d.axhline(0.50, color="black", linestyle=":", lw=1.0, alpha=0.7)
    ax_d.text(0.205, 0.515, "$\\Phi_{crit} = 0.50$", fontsize=7.3, color="#333333")

    # Plot benchmark points (0.30, 0.38, 0.45)
    for chi_b, lbl_b in [(0.30, "0.30\nCtrl"), (0.38, "0.38\nSubthresh."), (0.45, "0.45\nASD")]:
        key = f"chi_{chi_b:.2f}"
        p1 = qss_info[key]["W1_childhood"]["Phi_star"]
        p2 = qss_info[key]["W2_adolescent_PFC"]["Phi_star"]
        ax_d.scatter([chi_b], [p1], marker="o", s=42, color=OI["blue"], edgecolor="black", zorder=5)
        ax_d.scatter([chi_b], [p2], marker="s", s=42, color=OI["vermilion"], edgecolor="black", zorder=5)

    # Vertical collapse arrow at chi=0.38
    p38_1 = qss_info["chi_0.38"]["W1_childhood"]["Phi_star"]
    p38_2 = qss_info["chi_0.38"]["W2_adolescent_PFC"]["Phi_star"]
    ax_d.annotate(
        "", xy=(0.38, p38_2 + 0.015), xytext=(0.38, p38_1 - 0.015),
        arrowprops=dict(arrowstyle="->,head_width=0.3,head_length=0.35", color="black", lw=1.4),
    )
    ax_d.annotate(
        f"$\\chi_{{0.38}}$: {p38_1:.3f}$\\rightarrow${p38_2:.3f}\n($\\Delta\\Phi^*={p38_2 - p38_1:+.3f}$)",
        xy=(0.38, 0.56), xytext=(0.402, 0.65),
        ha="left", va="center", fontsize=7.2, fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="black", lw=0.8),
        bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="#AAAAAA", lw=0.7),
    )

    # Horizontal threshold shift arrow at Phi=0.50
    ax_d.annotate(
        "", xy=(chi_eff_w2, 0.50), xytext=(chi_eff_w1, 0.50),
        arrowprops=dict(arrowstyle="<->,head_width=0.25,head_length=0.3", color="black", lw=1.2),
    )
    ax_d.annotate(
        f"$\\Delta\\chi_c^{{eff}}={th_info['delta_chi_c_eff']:+.4f}$",
        xy=((chi_eff_w1 + chi_eff_w2) / 2, 0.50),
        xytext=(0.345, 0.42),
        ha="right", va="center", fontsize=7.1, fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="black", lw=0.8),
        bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="#CCCCCC", lw=0.6),
    )

    ax_d.text(0.265, 0.10, "Protected\n(Ctrl 0.30)", ha="center", va="bottom", fontsize=7.2, color=OI["green"], fontweight="bold")
    ax_d.text(0.382, 0.06, "Subthreshold\nCollapse", ha="center", va="bottom", fontsize=7.2, color=OI["vermilion"], fontweight="bold")
    ax_d.text(0.49, 0.25, "Overt ASD\n(0.45)", ha="center", va="bottom", fontsize=7.2, color=OI["vermilion"], fontweight="bold")

    ax_d.set_xlim(0.20, 0.55)
    ax_d.set_ylim(0.0, 1.02)
    ax_d.set_xlabel("CPEB4$\\Delta 4$ mole fraction ($\\chi_{\\Delta 4}$)")
    ax_d.set_ylabel("Translational Capacity $\\Phi^*(\\chi_{\\Delta 4}, D_{act})$")
    ax_d.grid(True, linestyle=":", alpha=0.25)
    despine(ax_d)
    ax_d.set_title("Activity-Shifted Locking Threshold (Eqs. 4–6)", loc="left", pad=8)
    ax_d.legend(loc="upper right", fontsize=6.9, handlelength=1.8)

    return save_figure(fig, "Figure_1")


# ---------------------------------------------------------------------------
# Helpers for BrainSpan DefC & Kernel Smoothers
# ---------------------------------------------------------------------------
def _gaussian_kernel_smooth(x_obs: np.ndarray, y_obs: np.ndarray, x_grid: np.ndarray, bw: float = 0.75) -> np.ndarray:
    d = (x_grid[:, None] - x_obs[None, :]) / bw
    w = np.exp(-0.5 * d ** 2)
    w_sum = w.sum(axis=1)
    return (w @ y_obs) / np.where(w_sum > 0, w_sum, 1.0)


def _format_age_ticks(ax: plt.Axes) -> None:
    tick_ages_pcw = [8.0, 16.0, 38.0, 90.14, 298.7, 715.82, 1080.8, 2123.6]
    tick_labels = ["8 pcw", "16 pcw", "Birth", "1 yr", "5 yr", "13 yr", "20 yr", "40 yr"]
    tick_pos = [math.log2(a) for a in tick_ages_pcw]
    ax.set_xticks(tick_pos)
    ax.set_xticklabels(tick_labels, rotation=28, ha="right", fontsize=7.3)


# ---------------------------------------------------------------------------
# Figure 2: Targetome Enrichment & BrainSpan Developmental Temporal Segregation
# ---------------------------------------------------------------------------
def plot_figure_2() -> List[Path]:
    print("Generating Figure_2...")
    enr = pd.read_csv(RESULTS_DIR / "enrichment_table.csv")
    gt = pd.read_csv(RESULTS_DIR / "brainspan_gene_timing.csv")
    meta = pd.read_csv(DATA_PROC / "brainspan_metadata.csv")
    traj = pd.read_csv(DATA_PROC / "brainspan_module_trajectories.csv")
    kern = pd.read_csv(RESULTS_DIR / "brainspan_empirical_kernels.csv")
    bio = json.loads((RESULTS_DIR / "bioinformatics_results.json").read_text(encoding="utf-8"))
    npz = np.load(DATA_PROC / "brainspan_log2rpkm.npz", allow_pickle=True)
    mat = npz["log2_rpkm"]
    ens_to_row = {eid: idx for idx, eid in enumerate(npz["ensembl_gene_id"])}

    fig = plt.figure(figsize=(15.0, 11.2))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.38, wspace=0.32)

    # --- Panel a: Forest Plot of Unadjusted & Covariate-Adjusted ORs ---
    ax_a = fig.add_subplot(gs[0, 0])
    add_panel_label(ax_a, "a", x=-0.26, y=1.05)

    risk_order = [
        ("Fu22_ASD185", "Fu22 ASD185"),
        ("SFARI_Score1", "SFARI Score 1"),
        ("Shared_SFARI12_and_SCZcomb", "Shared ASD∩SCZ"),
        ("SFARI_Score1_2", "SFARI Score 1+2"),
        ("SCHEMA_P_lt_0.01", "SCHEMA P<0.01"),
        ("SynGO_postsynapse", "SynGO postsynapse"),
        ("OT_SCZ_gen_ge_0.20", "OT SCZ ≥ 0.20"),
        ("INT17_SCZ_HC", "INT-17 SCZ (null)"),
    ]
    sub_b = enr[(enr["universe"] == "protein_coding_primary") & (enr["target_set"] == "CPEB4_binder")].set_index("risk_set")
    sub_p = enr[(enr["universe"] == "protein_coding_primary") & (enr["target_set"] == "PolyA_shortened_HD")].set_index("risk_set")

    y_pos = np.arange(len(risk_order))[::-1]
    ax_a.axvline(1.0, color="black", linestyle="--", lw=1.0, alpha=0.7)

    for idx, (rk, lbl) in enumerate(risk_order):
        y = y_pos[idx]
        rb = sub_b.loc[rk]
        rp = sub_p.loc[rk]

        # Unadjusted Fisher OR (open sky-blue circle)
        ax_a.errorbar(
            rb["fisher_or"], y + 0.22,
            xerr=[[rb["fisher_or"] - rb["woolf_ci_low"]], [rb["woolf_ci_high"] - rb["fisher_or"]]],
            fmt="o", color=OI["sky"], mfc="white", mec=OI["sky"], mew=1.3, ms=5.0,
            capsize=2.2, lw=1.1, label="Binder unadj. OR" if idx == 0 else None,
        )
        # Covariate-adjusted OR (filled blue circle)
        ax_a.errorbar(
            rb["logit_adj_or"], y,
            xerr=[[rb["logit_adj_or"] - rb["logit_adj_ci_low"]], [rb["logit_adj_ci_high"] - rb["logit_adj_or"]]],
            fmt="o", color=OI["blue"], mfc=OI["blue"], mec="black", mew=0.6, ms=5.5,
            capsize=2.4, lw=1.4, label="Binder adj. OR (expr+len)" if idx == 0 else None,
        )
        # PolyA_shortened_HD adjusted OR (filled vermilion diamond)
        ax_a.errorbar(
            rp["logit_adj_or"], y - 0.22,
            xerr=[[rp["logit_adj_or"] - rp["logit_adj_ci_low"]], [rp["logit_adj_ci_high"] - rp["logit_adj_or"]]],
            fmt="D", color=OI["vermilion"], mfc=OI["vermilion"], mec="black", mew=0.5, ms=4.5,
            capsize=2.0, lw=1.1, label="PolyA-short. adj. OR" if idx == 0 else None,
        )
        ax_a.text(
            7.2, y,
            f"{rb['logit_adj_or']:.2f} ($P$={fmt_p(rb['logit_p'])})",
            va="center", ha="left", fontsize=7.0, color=OI["blue"], fontweight="bold",
        )

    ax_a.set_xscale("log")
    ax_a.set_xlim(0.40, 19.5)
    ax_a.set_xticks([0.5, 1.0, 2.0, 4.0, 6.0])
    ax_a.get_xaxis().set_major_formatter(mpl.ticker.ScalarFormatter())
    ax_a.set_yticks(y_pos)
    ax_a.set_yticklabels([x[1] for x in risk_order], fontsize=7.8)
    ax_a.set_xlabel("Odds Ratio (log scale, 95% CI)")
    ax_a.text(7.2, y_pos[0] + 0.52, "Adj. OR (Binder)", fontsize=7.2, fontweight="bold", color=OI["blue"])
    ax_a.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("CPEB4 Targetome & Poly(A) Risk Enrichment", loc="left", pad=22)
    ax_a.legend(
        loc="lower center", bbox_to_anchor=(0.48, 1.005),
        ncol=3, fontsize=6.7, handletextpad=0.3, columnspacing=0.8,
    )

    # --- Panel b: BrainSpan PFC Developmental Segregation (DefC: Fu22 ASD185 vs SCHEMA P<0.05) ---
    ax_b = fig.add_subplot(gs[0, 1])
    add_panel_label(ax_b, "b", x=-0.13, y=1.05)

    pfc_mask = meta["is_pfc"].values.astype(bool)
    pfc_meta = meta[pfc_mask].copy().reset_index(drop=True)
    pfc_l2age = pfc_meta["log2_pcw"].values.astype(float)

    # DefC disjoint masks within brain-expressed protein-coding CPEB4 binders
    is_b = gt["parras18_cpeb4_binder"] == True
    fu185 = gt["fu22_ASD185"] == 1.0
    sch05 = gt["schema_P_meta"].notna() & (gt["schema_P_meta"] < 0.05)
    t_asd_c = gt.loc[is_b & fu185 & (~sch05)]
    t_scz_c = gt.loc[is_b & (~fu185) & sch05]

    def get_pfc_sample_z(df_sub: pd.DataFrame) -> np.ndarray:
        rows = [ens_to_row[eid] for eid in df_sub["ensembl_gene_id"]]
        m = mat[rows][:, pfc_mask].astype(np.float64)
        sd = m.std(axis=1, ddof=0, keepdims=True)
        valid = sd[:, 0] > 1e-8
        z = (m[valid] - m[valid].mean(axis=1, keepdims=True)) / sd[valid]
        return z.mean(axis=0)

    z_asd_pfc = get_pfc_sample_z(t_asd_c)
    z_scz_pfc = get_pfc_sample_z(t_scz_c)

    pfc_traj = pd.DataFrame({"age_pcw": pfc_meta["age_pcw"], "log2_pcw": pfc_l2age, "asd": z_asd_pfc, "scz": z_scz_pfc})
    binned_c = pfc_traj.groupby(["age_pcw", "log2_pcw"]).agg(
        asd_m=("asd", "mean"), asd_sem=("asd", "sem"),
        scz_m=("scz", "mean"), scz_sem=("scz", "sem"),
    ).reset_index().sort_values("log2_pcw")

    # Window shading (W1: 12 pcw - 1 yr; W2: 12 - 26 yr)
    ax_b.axvspan(math.log2(12.0), math.log2(142.3), color=OI["sky"], alpha=0.10, label="W1 (12 pcw–1 yr)")
    ax_b.axvspan(math.log2(663.7), math.log2(1341.5), color=OI["orange"], alpha=0.10, label="W2 (12–26 yr)")
    ax_b.axhline(0.0, color="#999999", linestyle=":", lw=0.8)

    l2_grid = np.linspace(pfc_l2age.min(), pfc_l2age.max(), 200)
    sm_asd = _gaussian_kernel_smooth(pfc_l2age, z_asd_pfc, l2_grid, bw=0.75)
    sm_scz = _gaussian_kernel_smooth(pfc_l2age, z_scz_pfc, l2_grid, bw=0.75)

    ax_b.errorbar(
        binned_c["log2_pcw"], binned_c["asd_m"], yerr=binned_c["asd_sem"].fillna(0),
        fmt="o", color=OI["blue"], ms=3.5, alpha=0.55, elinewidth=0.8, capsize=1.5,
    )
    ax_b.errorbar(
        binned_c["log2_pcw"], binned_c["scz_m"], yerr=binned_c["scz_sem"].fillna(0),
        fmt="s", color=OI["vermilion"], ms=3.5, alpha=0.55, elinewidth=0.8, capsize=1.5,
    )
    ax_b.plot(l2_grid, sm_asd, color=OI["blue"], lw=2.2, linestyle="-", label=f"DefC $T_{{ASD}}$ (Fu22, $n={len(t_asd_c)}$)")
    ax_b.plot(l2_grid, sm_scz, color=OI["vermilion"], lw=2.2, linestyle="--", label=f"DefC $T_{{SCZ}}$ (SCHEMA, $n={len(t_scz_c)}$)")

    _format_age_ticks(ax_b)
    ax_b.set_xlabel("Developmental Age (BrainSpan PFC, $N=133$ samples)")
    ax_b.set_ylabel("Mean Standardized Expression ($Z$)")
    ax_b.set_ylim(-1.15, 0.85)
    ax_b.grid(True, linestyle=":", alpha=0.25)
    despine(ax_b)
    ax_b.set_title("PFC Developmental Segregation (DefC: Fu22 vs. SCHEMA)", loc="left", pad=8)
    ax_b.legend(loc="upper right", fontsize=7.0, ncol=1)

    # Inset: Gene-level dZ_pfc_primary shift boxplot
    defc_dz = [t for t in bio["analysis_2_brainspan_timing"]["timing_tests"]
               if t["contrast_family"] == "DefC_Fu185_vs_SCHEMA05__CPEB4_binders" and t["metric"] == "dZ_pfc_primary"][0]
    defc_tau = [t for t in bio["analysis_2_brainspan_timing"]["timing_tests"]
                if t["contrast_family"] == "DefC_Fu185_vs_SCHEMA05__CPEB4_binders" and t["metric"] == "tau_star_pfc"][0]

    ax_ins_b = ax_b.inset_axes([0.08, 0.08, 0.35, 0.35])
    dz_a = t_asd_c["dZ_pfc_primary"].dropna().values
    dz_s = t_scz_c["dZ_pfc_primary"].dropna().values
    bp = ax_ins_b.boxplot(
        [dz_a, dz_s], positions=[0, 1], widths=0.48, patch_artist=True,
        showfliers=False, medianprops=dict(color="black", lw=1.2),
    )
    bp["boxes"][0].set_facecolor(OI["sky"])
    bp["boxes"][1].set_facecolor("#F5B7B1")
    ax_ins_b.scatter(np.zeros_like(dz_a) + np.random.default_rng(7).uniform(-0.11, 0.11, len(dz_a)), dz_a, s=5, color=OI["blue"], alpha=0.45)
    ax_ins_b.scatter(np.ones_like(dz_s) + np.random.default_rng(8).uniform(-0.11, 0.11, len(dz_s)), dz_s, s=5, color=OI["vermilion"], alpha=0.45)
    ax_ins_b.axhline(0, color="gray", linestyle=":", lw=0.7)
    ax_ins_b.set_xticks([0, 1])
    ax_ins_b.set_xticklabels([f"$T_{{ASD}}$\n({defc_dz['mean_b']:+.3f})", f"$T_{{SCZ}}$\n({defc_dz['mean_a']:+.3f})"], fontsize=6.5)
    ax_ins_b.set_ylabel("$\\Delta Z_{PFC}$", fontsize=6.8, labelpad=1)
    ax_ins_b.set_yticks([-2, -1, 0, 1, 2])
    ax_ins_b.tick_params(axis="y", labelsize=6.2)
    ax_ins_b.set_ylim(-2.2, 3.15)
    despine(ax_ins_b)
    ax_ins_b.text(
        0.5, 0.96,
        f"$\\Delta$={defc_dz['mean_diff_a_minus_b']:+.3f}, $P_{{perm}}$={defc_dz['perm_expr_matched_p_two_sided']:.4f}\n"
        f"($\\tau^*_{{PFC}}$ $P_{{perm}}$={defc_tau['perm_expr_matched_p_two_sided']:.4f})",
        transform=ax_ins_b.transAxes, ha="center", va="top",
        fontsize=6.2, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.14", fc="white", ec="none", alpha=0.88),
    )

    # --- Panel c: Developmental Co-Maturation in PFC ---
    ax_c = fig.add_subplot(gs[1, 0])
    add_panel_label(ax_c, "c", x=-0.13, y=1.05)

    # Compute exact gene-wise Z across 524 samples matching 02_bioinformatics_validation.py, then slice PFC
    prun_genes = ["C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "ITGAM", "ITGB2", "TREM2", "TYROBP", "CX3CR1", "P2RY12", "CD68", "CSF1R", "C3AR1", "PROS1", "MERTK"]
    traj_c = traj.copy()
    prun_arr = traj_c[[g for g in prun_genes if g in traj_c.columns]].values.astype(float)
    prun_z = ((prun_arr - prun_arr.mean(axis=0, keepdims=True)) / prun_arr.std(axis=0, ddof=0, keepdims=True)).mean(axis=1)
    traj_c["Complement_Pruning_module_Z"] = prun_z

    pfc_tr = traj_c[traj_c["is_pfc"].astype(bool)].copy()
    tr_regs = {r["feature"]: r["spearman_rho_pfc"] for r in bio["analysis_2_brainspan_timing"]["trajectory_regressions"]}

    curves_c = [
        ("CPEB4", "CPEB4", OI["blue"], "-", 1.9),
        ("SRRM4", "SRRM4", OI["sky"], "--", 1.8),
        ("RBFOX2", "RBFOX2", OI["purple"], ":", 1.8),
        ("HNRNPC", "HNRNPC", OI["gray"], "-.", 1.6),
        ("CAMK2A", "CAMK2A", OI["vermilion"], "-", 2.0),
        ("MAPK3", "MAPK3", OI["orange"], "--", 1.8),
        ("Complement_Pruning_module_Z", "Pruning (C4A/B+)", OI["green"], "-.", 1.9),
    ]
    for col, lbl, color, ls, lw in curves_c:
        vals_all = traj_c[col].values.astype(float)
        z_all = (vals_all - vals_all.mean()) / vals_all.std(ddof=0)
        z_pfc = z_all[traj_c["is_pfc"].astype(bool)]
        sm_c = _gaussian_kernel_smooth(pfc_tr["log2_pcw"].values, z_pfc, l2_grid, bw=0.75)
        rho_val = tr_regs[col]
        ax_c.plot(l2_grid, sm_c, color=color, linestyle=ls, lw=lw, label=f"{lbl} ($\\rho$={rho_val:+.2f})")

    ax_c2 = ax_c.twinx()
    ax_c2.patch.set_visible(False)
    ax_c2.spines["top"].set_visible(False)
    ax_c2.plot(
        kern["log2_pcw"], kern["D_act_emp"],
        color="black", lw=2.3, linestyle="-", alpha=0.85, label="$D_{act,emp}$ kernel",
    )
    peak_d = bio["analysis_4_empirical_kernels"]["kernel_peaks"]["D_act_emp"]
    ax_c2.scatter([peak_d["peak_log2_pcw"]], [1.0], marker="*", s=110, color="black", zorder=6)
    ax_c2.annotate(
        f"$D_{{act,emp}}$ peak\n{peak_d['peak_age_years_postnatal']:.2f} yr",
        xy=(peak_d["peak_log2_pcw"], 1.0),
        xytext=(peak_d["peak_log2_pcw"] - 0.1, 0.72),
        ha="center", va="top", fontsize=7.1, fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="black", lw=0.9),
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#BBBBBB", lw=0.6, alpha=0.92),
    )

    _format_age_ticks(ax_c)
    ax_c.set_xlabel("Developmental Age (BrainSpan PFC)")
    ax_c.set_ylabel("Standardized Expression ($Z$, smoothed)")
    ax_c2.set_ylabel("Normalized Activity Demand $D_{act,emp}$", color="black")
    ax_c.set_ylim(-1.85, 1.45)
    ax_c2.set_ylim(-0.05, 1.15)
    ax_c.grid(True, linestyle=":", alpha=0.25)
    despine(ax_c, keep_right=True)
    ax_c.set_title("Splicing Factors vs. Kinases & Complement Pruning", loc="left", pad=8)
    h1, l1 = ax_c.get_legend_handles_labels()
    h2, l2 = ax_c2.get_legend_handles_labels()
    ax_c.legend(
        h1 + h2, l1 + l2, loc="lower right",
        fontsize=6.6, ncol=2, columnspacing=0.8, handlelength=1.6,
        frameon=True, facecolor="white", framealpha=0.92, edgecolor="none",
    )

    # --- Panel d: Heatmap of Spearman Age Correlations across 16 BrainSpan Regions ---
    ax_d = fig.add_subplot(gs[1, 1])
    add_panel_label(ax_d, "d", x=-0.18, y=1.05)

    reg_order = [
        "DFC", "MFC", "OFC", "VFC",  # 4 PFC regions
        "IPC", "ITC", "STC", "A1C", "M1C", "S1C", "V1C",  # other neocortex
        "HIP", "AMY", "STR", "MD", "CBC",  # subcortical / cerebellar
    ]
    feat_order = [
        ("CPEB4", "CPEB4"),
        ("SRRM4", "SRRM4"),
        ("RBFOX2", "RBFOX2"),
        ("HNRNPC", "HNRNPC"),
        ("RBFOX1", "RBFOX1"),
        ("RBFOX3", "RBFOX3"),
        ("MAPK1", "MAPK1"),
        ("MAPK3", "MAPK3"),
        ("CAMK2B", "CAMK2B"),
        ("CAMK2A", "CAMK2A"),
        ("Synaptogenesis_module_Z", "Synaptogenesis"),
        ("Complement_Pruning_module_Z", "Complement Pruning"),
    ]
    tr_lookup = {r["feature"]: r["major_regions_detail"] for r in bio["analysis_2_brainspan_timing"]["trajectory_regressions"]}
    mat_rho = np.zeros((len(feat_order), len(reg_order)))
    for i, (fk, _) in enumerate(feat_order):
        for j, rk in enumerate(reg_order):
            mat_rho[i, j] = tr_lookup[fk][rk]["rho"]

    im = ax_d.imshow(mat_rho, cmap="RdBu_r", vmin=-1.0, vmax=1.0, aspect="auto")
    for i in range(len(feat_order)):
        for j in range(len(reg_order)):
            val = mat_rho[i, j]
            txt_col = "white" if abs(val) > 0.58 else "black"
            ax_d.text(j, i, f"{val:+.2f}", ha="center", va="center", fontsize=5.8, color=txt_col)

    # Highlight 4 PFC regions & separate neocortex vs subcortical
    ax_d.add_patch(mpatches.Rectangle((-0.5, -0.5), 4.0, len(feat_order), fill=False, edgecolor="black", lw=1.6))
    ax_d.axvline(10.5, color="black", linestyle="--", lw=0.9)
    ax_d.text(1.5, -0.85, "PFC (4)", ha="center", va="bottom", fontsize=7.2, fontweight="bold")
    ax_d.text(7.0, -0.85, "Other Neocortex (7)", ha="center", va="bottom", fontsize=7.0)
    ax_d.text(13.0, -0.85, "Subcort./CBC (5)", ha="center", va="bottom", fontsize=7.0)

    ax_d.set_xticks(np.arange(len(reg_order)))
    ax_d.set_xticklabels(reg_order, rotation=45, ha="right", fontsize=7.3)
    ax_d.set_yticks(np.arange(len(feat_order)))
    ax_d.set_yticklabels([x[1] for x in feat_order], fontsize=7.6)
    ax_d.spines["top"].set_visible(False)
    ax_d.spines["right"].set_visible(False)
    cbar = fig.colorbar(im, ax=ax_d, fraction=0.036, pad=0.03)
    cbar.set_label("Spearman $\\rho$ (expr vs. $\\log_2$ age)", fontsize=7.5)
    cbar.ax.tick_params(labelsize=7.0)
    ax_d.set_title("Regional Age Correlations (16 BrainSpan Regions)", loc="left", pad=22)

    return save_figure(fig, "Figure_2")


# ---------------------------------------------------------------------------
# Figure 3: Human Postmortem Cortical Cross-Disorder Validation
# ---------------------------------------------------------------------------
def plot_figure_3() -> List[Path]:
    print("Generating Figure_3...")
    gt = pd.read_csv(RESULTS_DIR / "brainspan_gene_timing.csv")
    gs = pd.read_csv(DATA_PROC / "gandal2018_continuous_sumstats.csv", low_memory=False)
    gc_corr = pd.read_csv(RESULTS_DIR / "gandal2018_continuous_correlations.csv")
    enr = pd.read_csv(RESULTS_DIR / "enrichment_table.csv")
    pe_tv = pd.read_csv(RESULTS_DIR / "psychencode_timing_validation.csv")
    bio = json.loads((RESULTS_DIR / "bioinformatics_results.json").read_text(encoding="utf-8"))

    merged = gt.merge(gs, on="ensembl_gene_id", suffixes=("", "_g"))
    binders = merged[merged["parras18_cpeb4_binder"] == True].copy()
    binders["dbeta_cmc"] = binders["scz_cmc_logFC"] - binders["asd_all_logFC"]
    binders["dbeta_gvex"] = binders["scz_gvex_logFC"] - binders["asd_all_logFC"]

    fig = plt.figure(figsize=(15.0, 10.6))
    outer = gridspec.GridSpec(2, 1, figure=fig, height_ratios=[1.05, 0.95], hspace=0.35)
    top_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0], wspace=0.28)
    bot_gs = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=outer[1], wspace=0.32)

    # --- Panel a: Continuous Gandal 2018 Correlation ---
    ax_a = fig.add_subplot(top_gs[0, 0])
    add_panel_label(ax_a, "a", x=-0.13, y=1.06)

    valid_cmc = binders["dZ_pfc_primary"].notna() & binders["dbeta_cmc"].notna()
    df_a = binders[valid_cmc].copy()
    ax_a.scatter(
        df_a["dZ_pfc_primary"], df_a["dbeta_cmc"],
        s=9, color=OI["lightgray"], alpha=0.55, edgecolors="none", rasterized=False,
        label=f"CPEB4 binders ($n={len(df_a):,}$)",
    )
    ax_a.axhline(0, color="#888888", linestyle=":", lw=0.8)
    ax_a.axvline(0, color="#888888", linestyle=":", lw=0.8)

    # Binned deciles mean +/- 95% CI for CMC and GVEX
    for col_y, col_c, mk, ls, lbl_prefix in [
        ("dbeta_cmc", OI["blue"], "o", "-", "SCZ(CMC)−ASD(all)"),
        ("dbeta_gvex", OI["vermilion"], "s", "--", "SCZ(GVEX)−ASD(all)"),
    ]:
        sub_y = binders[binders["dZ_pfc_primary"].notna() & binders[col_y].notna()].copy()
        sub_y["dec"] = pd.qcut(sub_y["dZ_pfc_primary"], q=10, labels=False)
        grp = sub_y.groupby("dec").agg(
            xm=("dZ_pfc_primary", "mean"),
            ym=(col_y, "mean"),
            yse=(col_y, "sem"),
        ).reset_index()
        ax_a.errorbar(
            grp["xm"], grp["ym"], yerr=1.96 * grp["yse"],
            fmt=f"{mk}{ls}", color=col_c, mfc=col_c, mec="black", mew=0.5,
            ms=5.0, capsize=2.5, lw=1.7, label=f"{lbl_prefix} deciles ±95% CI", zorder=5,
        )

    c_cmc = gc_corr[(gc_corr["subset"] == "CPEB4_binders") & (gc_corr["timing_metric"] == "dZ_pfc_primary") & (gc_corr["cortical_metric"] == "dbeta_signed_cmc_asd_all")].iloc[0]
    c_gvex = gc_corr[(gc_corr["subset"] == "CPEB4_binders") & (gc_corr["timing_metric"] == "dZ_pfc_primary") & (gc_corr["cortical_metric"] == "dbeta_signed_gvex_asd_all")].iloc[0]

    ax_a.text(
        0.04, 0.96,
        f"CMC: $\\rho={c_cmc['spearman_rho']:+.3f}$, $P={fmt_p(c_cmc['spearman_p'], in_math=True)}$\n"
        f"GVEX: $\\rho={c_gvex['spearman_rho']:+.3f}$, $P={fmt_p(c_gvex['spearman_p'], in_math=True)}$",
        transform=ax_a.transAxes, va="top", ha="left", fontsize=7.6, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.28", fc="#FFFFFF", ec="#BBBBBB", lw=0.7),
    )
    ax_a.set_xlabel("BrainSpan PFC Developmental Timing ($\\Delta Z_{PFC}$)")
    ax_a.set_ylabel("Signed Cortical Divergence $\\Delta\\beta$ ($\\log_2$FC$_{SCZ} - \\log_2$FC$_{ASD}$)")
    ax_a.set_ylim(-0.68, 0.72)
    ax_a.grid(True, linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("Cortical Cross-Disorder Divergence Tracks Timing", loc="left", pad=8)
    ax_a.legend(loc="lower right", fontsize=7.0)

    # --- Panel b: Postmortem Regulator & Complement Profile ---
    ax_b = fig.add_subplot(top_gs[0, 1])
    add_panel_label(ax_b, "b", x=-0.12, y=1.06)

    key_genes_list = ["CPEB4", "SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "HNRNPC", "CAMK2A", "CAMK2B", "C4A", "C4B"]
    kg_map = {g["gene_symbol"]: g for g in bio["analysis_3_psychencode_validation"]["gandal2018_key_genes"]}

    x_g = np.arange(len(key_genes_list))
    w_bar = 0.20
    cohorts = [
        ("asd_frontal", "ASD Frontal", OI["blue"], ""),
        ("asd_all", "ASD All Cortex", OI["sky"], "//"),
        ("scz_cmc", "SCZ CMC", OI["vermilion"], ""),
        ("scz_gvex", "SCZ GVEX", OI["orange"], ".."),
    ]
    ax_b.axhline(0, color="black", lw=0.8)

    for k_idx, (prefix, lbl, col, hatch) in enumerate(cohorts):
        offs = (k_idx - 1.5) * w_bar
        vals = [kg_map[g][f"{prefix}_logFC"] for g in key_genes_list]
        pvals = [kg_map[g][f"{prefix}_P_Value"] for g in key_genes_list]
        fdrs = [kg_map[g][f"{prefix}_adj_P_Val"] for g in key_genes_list]
        ax_b.bar(
            x_g + offs, vals, width=w_bar, color=col, edgecolor="black",
            linewidth=0.5, hatch=hatch, label=lbl, zorder=3,
        )
        for xi, v, pv, fv in zip(x_g + offs, vals, pvals, fdrs):
            star = "**" if fv < 0.05 else ("*" if pv < 0.05 else "")
            if star:
                dy = 0.025 if v >= 0 else -0.035
                va = "bottom" if v >= 0 else "top"
                ax_b.text(xi, v + dy, star, ha="center", va=va, fontsize=7.5, fontweight="bold", color="black")

    ax_b.annotate(
        f"SRRM4 ASD Fr:\n{kg_map['SRRM4']['asd_frontal_logFC']:+.3f}\n($P$={kg_map['SRRM4']['asd_frontal_P_Value']:.4f})",
        xy=(1 - 1.5 * w_bar, kg_map["SRRM4"]["asd_frontal_logFC"] - 0.05),
        xytext=(1.75, -0.63),
        ha="center", va="center", fontsize=6.8, color=OI["blue"], fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=OI["blue"], lw=0.8),
    )
    ax_b.annotate(
        f"C4A SCZ CMC:\n{kg_map['C4A']['scz_cmc_logFC']:+.3f}\n(FDR={kg_map['C4A']['scz_cmc_adj_P_Val']:.4f})",
        xy=(8 + 0.5 * w_bar, kg_map["C4A"]["scz_cmc_logFC"]),
        xytext=(7.1, 0.78),
        ha="center", va="center", fontsize=6.9, color=OI["vermilion"], fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=OI["vermilion"], lw=0.8),
    )

    ax_b.set_xticks(x_g)
    ax_b.set_xticklabels(key_genes_list, rotation=28, ha="right", fontsize=7.6)
    ax_b.set_ylabel("Cortical $\\log_2$ Fold Change (Gandal 2018)")
    ax_b.set_ylim(-0.79, 1.12)
    ax_b.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_b)
    ax_b.set_title("Regulator & Complement Expression (*$P$<0.05, **FDR<0.05)", loc="left", pad=8)
    ax_b.legend(loc="upper left", fontsize=6.9, ncol=2, columnspacing=0.9)

    # --- Panel c (3 clean subpanels): DER-13 DGE, DER-15 DS_leaf, PolyA_shortened_HD ---
    # c1: DER-13 PE_DGE_down vs PE_DGE_up dZ_pfc_primary
    ax_c1 = fig.add_subplot(bot_gs[0, 0])
    add_panel_label(ax_c1, "c", x=-0.18, y=1.07)

    def get_pe_row(cfam: str) -> pd.Series:
        return pe_tv[(pe_tv["contrast_family"] == cfam) & (pe_tv["metric"] == "dZ_pfc_primary")].iloc[0]

    r_down_b = get_pe_row("PE_DGE_down__CPEB4_binders")
    r_up_b = get_pe_row("PE_DGE_up__CPEB4_binders")
    r_up_all = get_pe_row("PE_DGE_up__All_BrainExpr")

    bars_c1 = [
        ("DGE↓\nBinders", r_down_b["mean_b"], r_down_b["sd_b"] / math.sqrt(r_down_b["n_b"]), r_down_b["mean_a"], r_down_b["sd_a"] / math.sqrt(r_down_b["n_a"]), r_down_b["perm_expr_matched_p_two_sided"]),
        ("DGE↑\nBinders", r_up_b["mean_b"], r_up_b["sd_b"] / math.sqrt(r_up_b["n_b"]), r_up_b["mean_a"], r_up_b["sd_a"] / math.sqrt(r_up_b["n_a"]), r_up_b["perm_expr_matched_p_two_sided"]),
        ("DGE↑\nAll Expr", r_up_all["mean_b"], r_up_all["sd_b"] / math.sqrt(r_up_all["n_b"]), r_up_all["mean_a"], r_up_all["sd_a"] / math.sqrt(r_up_all["n_a"]), r_up_all["perm_expr_matched_p_two_sided"]),
    ]
    xc1 = np.arange(len(bars_c1))
    wc1 = 0.34
    ax_c1.axhline(0, color="gray", linestyle=":", lw=0.8)
    for i, (lbl, m_asd, se_asd, m_scz, se_scz, pp) in enumerate(bars_c1):
        ax_c1.bar(i - wc1 / 2, m_asd, yerr=1.96 * se_asd, width=wc1, color=OI["blue"], edgecolor="black", lw=0.6, capsize=2.5, label="ASD" if i == 0 else None)
        ax_c1.bar(i + wc1 / 2, m_scz, yerr=1.96 * se_scz, width=wc1, color=OI["vermilion"], edgecolor="black", lw=0.6, capsize=2.5, label="SCZ" if i == 0 else None)
        y_top = max(m_asd + 1.96 * se_asd, m_scz + 1.96 * se_scz) + 0.06
        ax_c1.text(i, y_top, f"$P_{{perm}}$={fmt_p(pp)}", ha="center", va="bottom", fontsize=6.7, fontweight="bold")

    ax_c1.set_xticks(xc1)
    ax_c1.set_xticklabels([x[0] for x in bars_c1], fontsize=7.6)
    ax_c1.set_ylabel("Mean BrainSpan $\\Delta Z_{PFC}$ (±95% CI)")
    ax_c1.set_ylim(-0.28, 0.88)
    ax_c1.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c1)
    ax_c1.set_title("DER-13 DGE Timing Contrasts", loc="left", fontsize=8.8, pad=6)
    ax_c1.legend(loc="lower right", fontsize=7.0)

    # d: DER-15 DS_leaf Differential Splicing Enrichment
    ax_c2 = fig.add_subplot(bot_gs[0, 1])
    add_panel_label(ax_c2, "d", x=-0.22, y=1.07)
    ds_sets = [
        ("PE_ASD_DS_leaf", "ASD DS leaf", OI["blue"]),
        ("PE_SCZ_DS_leaf", "SCZ DS leaf", OI["vermilion"]),
        ("PE_BD_DS_leaf", "BD DS leaf", OI["green"]),
    ]
    sub_ds = enr[(enr["universe"] == "protein_coding_primary") & (enr["target_set"] == "CPEB4_binder")].set_index("risk_set")
    yc2 = np.arange(len(ds_sets))[::-1]
    ax_c2.axvline(1.0, color="black", linestyle="--", lw=1.0, alpha=0.7)
    for i, (rk, lbl, col) in enumerate(ds_sets):
        r = sub_ds.loc[rk]
        y = yc2[i]
        ax_c2.errorbar(
            r["logit_adj_or"], y,
            xerr=[[r["logit_adj_or"] - r["logit_adj_ci_low"]], [r["logit_adj_ci_high"] - r["logit_adj_or"]]],
            fmt="o", color=col, mfc=col, mec="black", ms=6.0, capsize=3.0, lw=1.6,
        )
        ax_c2.text(
            r["logit_adj_or"], y + 0.18,
            f"Adj OR={r['logit_adj_or']:.2f}, $P$={fmt_p(r['logit_p'])} ($a$={int(r['a_target_and_risk'])})",
            ha="center", va="bottom", fontsize=7.0, fontweight="bold", color=col,
        )
    ax_c2.set_yticks(yc2)
    ax_c2.set_yticklabels([x[1] for x in ds_sets], fontsize=7.8)
    ax_c2.set_xlim(0.7, 3.85)
    ax_c2.set_ylim(-0.5, 2.7)
    ax_c2.set_xlabel("Covariate-Adjusted OR (95% CI)")
    ax_c2.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_c2)
    ax_c2.set_title("DER-15 Splicing (DS) Enrichment", loc="left", fontsize=8.8, pad=6)

    # e: PolyA_shortened_HD vs |Δβ| (dbeta_abs_cmc_asd_frontal)
    ax_c3 = fig.add_subplot(bot_gs[0, 2])
    add_panel_label(ax_c3, "e", x=-0.20, y=1.07)
    polya = merged[merged["parras18_polya_shortened_hd"] == True].copy()
    polya["dbeta_abs"] = polya["scz_cmc_logFC"].abs() - polya["asd_frontal_logFC"].abs()
    vp = polya["dZ_pfc_primary"].notna() & polya["dbeta_abs"].notna()
    pa_v = polya[vp].copy()
    ax_c3.scatter(pa_v["dZ_pfc_primary"], pa_v["dbeta_abs"], s=10, color=OI["lightgray"], alpha=0.65, edgecolors="none")
    ax_c3.axhline(0, color="#888888", linestyle=":", lw=0.8)
    pa_v["dec"] = pd.qcut(pa_v["dZ_pfc_primary"], q=8, labels=False)
    grp_pa = pa_v.groupby("dec").agg(xm=("dZ_pfc_primary", "mean"), ym=("dbeta_abs", "mean"), yse=("dbeta_abs", "sem")).reset_index()
    ax_c3.errorbar(
        grp_pa["xm"], grp_pa["ym"], yerr=1.96 * grp_pa["yse"],
        fmt="-D", color=OI["purple"], mfc=OI["purple"], mec="black", ms=4.5, lw=1.6, capsize=2.5,
        label="Octile mean ±95% CI",
    )
    c_pa = gc_corr[(gc_corr["subset"] == "PolyA_shortened_HD") & (gc_corr["timing_metric"] == "dZ_pfc_primary") & (gc_corr["cortical_metric"] == "dbeta_abs_cmc_asd_frontal")].iloc[0]
    ax_c3.text(
        0.04, 0.96,
        f"PolyA-shortened ($n={int(c_pa['n'])}$)\n$\\rho={c_pa['spearman_rho']:+.3f}$, $P={fmt_p(c_pa['spearman_p'], in_math=True)}$",
        transform=ax_c3.transAxes, va="top", ha="left", fontsize=7.2, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#BBBBBB", lw=0.7),
    )
    ax_c3.set_xlabel("BrainSpan $\\Delta Z_{PFC}$")
    ax_c3.set_ylabel("$|\\log_2\\mathrm{FC}_{SCZ}| - |\\log_2\\mathrm{FC}_{ASD,Fr}|$")
    ax_c3.set_ylim(-0.52, 0.32)
    ax_c3.grid(True, linestyle=":", alpha=0.25)
    despine(ax_c3)
    ax_c3.set_title("Poly(A)-Shortened Divergence Magnitude", loc="left", fontsize=8.8, pad=6)
    ax_c3.legend(loc="lower left", fontsize=6.9)

    return save_figure(fig, "Figure_3")


# ---------------------------------------------------------------------------
# Figure S1: Sensitivity of BrainSpan Temporal Segregation & Permutations
# ---------------------------------------------------------------------------
def _reproduce_defc_perm_distribution(
    vals: np.ndarray,
    expr_deciles: np.ndarray,
    ma: np.ndarray,
    mb: np.ndarray,
    pool_mask: np.ndarray,
    n_perm: int = 10000,
    n_boot: int = 2000,
    seed: int = 42,
) -> Tuple[np.ndarray, float, float]:
    """Reproduce exact B=10,000 permutation null array matching 02_bioinformatics_validation.py."""
    valid = np.isfinite(vals)
    ma = ma & valid
    mb = mb & valid
    mp = pool_mask & valid
    xa, xb = vals[ma], vals[mb]
    na, nb = len(xa), len(xb)
    diff_obs = float(xa.mean() - xb.mean())

    rng = np.random.default_rng(seed)
    _ = rng.integers(0, na, size=(n_boot, na))
    _ = rng.integers(0, nb, size=(n_boot, nb))

    sa_counts = np.bincount(expr_deciles[ma], minlength=100)
    sb_counts = np.bincount(expr_deciles[mb], minlength=100)
    active_strata = np.where((sa_counts + sb_counts) > 0)[0]

    sum_a = np.zeros(n_perm, dtype=np.float64)
    sum_b = np.zeros(n_perm, dtype=np.float64)
    for s in active_strata:
        ka, kb = int(sa_counts[s]), int(sb_counts[s])
        pool_idx = np.where(mp & (expr_deciles == s))[0]
        if len(pool_idx) == 0:
            continue
        pool_vals = vals[pool_idx]
        n_pool = len(pool_vals)
        if n_pool >= ka + kb:
            rand_mat = rng.random((n_perm, n_pool))
            part = np.argpartition(rand_mat, ka + kb - 1, axis=1)
            if ka > 0:
                sum_a += pool_vals[part[:, :ka]].sum(axis=1)
            if kb > 0:
                sum_b += pool_vals[part[:, ka : ka + kb]].sum(axis=1)
        else:
            if ka > 0:
                sum_a += pool_vals[rng.integers(0, n_pool, size=(n_perm, ka))].sum(axis=1)
            if kb > 0:
                sum_b += pool_vals[rng.integers(0, n_pool, size=(n_perm, kb))].sum(axis=1)

    perm_diffs = (sum_a / na) - (sum_b / nb)
    p_two = float((1 + np.sum(np.abs(perm_diffs) >= abs(diff_obs) - 1e-12)) / (n_perm + 1))
    return perm_diffs, diff_obs, p_two


# ---------------------------------------------------------------------------
# Figure S2: Sensitivity of BrainSpan Temporal Segregation & Permutations
# ---------------------------------------------------------------------------
def plot_figure_s2() -> List[Path]:
    print("Generating Figure_S2...")
    bio = json.loads((RESULTS_DIR / "bioinformatics_results.json").read_text(encoding="utf-8"))
    gt = pd.read_csv(RESULTS_DIR / "brainspan_gene_timing.csv")
    meta = pd.read_csv(DATA_PROC / "brainspan_metadata.csv")
    traj = pd.read_csv(DATA_PROC / "brainspan_module_trajectories.csv")
    npz = np.load(DATA_PROC / "brainspan_log2rpkm.npz", allow_pickle=True)
    mat = npz["log2_rpkm"]
    ens_to_row = {eid: idx for idx, eid in enumerate(npz["ensembl_gene_id"])}

    fig = plt.figure(figsize=(15.2, 11.4))
    outer = gridspec.GridSpec(2, 1, figure=fig, height_ratios=[1.1, 0.9], hspace=0.35)
    top_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0], width_ratios=[1.15, 0.95], wspace=0.28)
    bot_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[1], width_ratios=[0.95, 1.05], wspace=0.30)

    # --- Panel a: Alternative Gene-Set Definitions & Window Pairs Forest Plot ---
    ax_a = fig.add_subplot(top_gs[0, 0])
    add_panel_label(ax_a, "a", x=-0.28, y=1.05)

    tt = pd.DataFrame(bio["analysis_2_brainspan_timing"]["timing_tests"])
    tt = tt[tt["group_a"].isin(["T_SCZ_only", "All_SCZ_only"]) & tt["group_b"].isin(["T_ASD_only", "All_ASD_only"])].copy()

    specs = [
        ("DefA_SFARI12_vs_SCZcomb__CPEB4_binders", "dZ_pfc_primary", "DefA: SFARI1+2 vs SCZcomb (PFC, Binders)"),
        ("DefA_SFARI12_vs_SCZcomb__CPEB4_binders", "dZ_all_primary", "DefA: SFARI1+2 vs SCZcomb (All, Binders)"),
        ("DefA_SFARI12_vs_SCZcomb__CPEB4_binders", "dZ_all_sensA_fetal_adoladult", "DefA: Fetal→Adol/Adult (All, Binders)"),
        ("DefA_SFARI12_vs_SCZcomb__CPEB4_binders", "dZ_all_sensB_infchild_adol", "DefA: Infant→Adol (All, Binders)"),
        ("DefA_SFARI12_vs_SCZcomb__CPEB4_binders", "tau_star_pfc", "DefA: $\\tau^*_{PFC}$ (Binders)"),
        ("DefB_SFARI12_vs_SCHEMA05__CPEB4_binders", "dZ_pfc_primary", "DefB: SFARI1+2 vs SCHEMA (PFC, Binders)"),
        ("DefD_SFARI12_vs_OT_SCZ15__CPEB4_binders", "dZ_pfc_primary", "DefD: SFARI1+2 vs OT-SCZ (PFC, Binders)"),
        ("DefG_SFARI12_vs_INT17__CPEB4_binders", "dZ_pfc_primary", "DefG: SFARI1+2 vs INT-17 (PFC, Binders)"),
        ("DefC_Fu185_vs_SCHEMA05__CPEB4_binders", "dZ_all_primary", "DefC: Fu22 vs SCHEMA (All, Binders)"),
        ("DefC_Fu185_vs_SCHEMA05__CPEB4_binders", "dZ_pfc_primary", "DefC: Fu22 vs SCHEMA (PFC, Binders)"),
        ("DefC_Fu185_vs_SCHEMA05__CPEB4_binders", "tau_star_pfc", "DefC: Fu22 vs SCHEMA ($\\tau^*_{PFC}$, Binders)"),
        ("DefC_Fu185_vs_SCHEMA05__All_BrainExpr", "dZ_pfc_primary", "DefC: Fu22 vs SCHEMA (PFC, All Expr)"),
    ]

    ya = np.arange(len(specs))[::-1]
    ax_a.axvline(0.0, color="black", linestyle="--", lw=1.0, alpha=0.7)
    for i, (cfam, met, lbl) in enumerate(specs):
        row = tt[(tt["contrast_family"] == cfam) & (tt["metric"] == met)].iloc[0]
        y = ya[i]
        is_defc = "DefC" in cfam
        col = OI["vermilion"] if is_defc else OI["blue"]
        mk = "s" if "All_BrainExpr" in cfam else "o"
        ax_a.errorbar(
            row["mean_diff_a_minus_b"], y,
            xerr=[[row["mean_diff_a_minus_b"] - row["boot_mean_diff_ci_low"]], [row["boot_mean_diff_ci_high"] - row["mean_diff_a_minus_b"]]],
            fmt=mk, color=col, mfc=col, mec="black", ms=5.0, capsize=2.2, lw=1.3,
        )
        ax_a.text(
            0.60, y,
            f"$P_{{perm}}$={fmt_p(row['perm_expr_matched_p_two_sided'])}",
            va="center", ha="left", fontsize=6.9, color=col, fontweight="bold" if is_defc else "normal",
        )

    ax_a.set_yticks(ya)
    ax_a.set_yticklabels([x[2] for x in specs], fontsize=7.3)
    ax_a.set_xlim(-0.42, 0.90)
    ax_a.set_xlabel("Timing Shift ($\\Delta_{SCZ - ASD}$, 95% Bootstrap CI)")
    ax_a.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("Sensitivity Across Definitions & Developmental Windows", loc="left", pad=8)

    # --- Panel b: B=10,000 Expression-Matched Permutation Null Histograms (DefC) ---
    perm_gs = gridspec.GridSpecFromSubplotSpec(3, 1, subplot_spec=top_gs[0, 1], hspace=0.48)
    expr_dec = pd.qcut(gt["mean_log2_rpkm"], q=10, labels=False, duplicates="drop").values.astype(int)
    is_b = (gt["parras18_cpeb4_binder"] == True).values
    fu185 = (gt["fu22_ASD185"] == 1.0).values
    sch05 = (gt["schema_P_meta"].notna() & (gt["schema_P_meta"] < 0.05)).values
    t_asd_m = is_b & fu185 & (~sch05)
    t_scz_m = is_b & (~fu185) & sch05

    perm_specs = [
        ("dZ_all_primary", "DefC $\\Delta Z_{all}$ (SCZ − ASD)"),
        ("dZ_pfc_primary", "DefC $\\Delta Z_{PFC}$ (SCZ − ASD)"),
        ("tau_star_pfc", "DefC $\\tau^*_{PFC}$ (SCZ − ASD)"),
    ]
    for p_idx, (met, title_p) in enumerate(perm_specs):
        ax_p = fig.add_subplot(perm_gs[p_idx, 0])
        if p_idx == 0:
            add_panel_label(ax_p, "b", x=-0.16, y=1.18)
        p_arr, obs_d, p_two = _reproduce_defc_perm_distribution(
            gt[met].values, expr_dec, t_scz_m, t_asd_m, is_b,
            n_perm=int(bio["metadata"]["n_permutations"]),
            n_boot=int(bio["metadata"]["n_bootstrap"]),
            seed=int(bio["metadata"]["seed"]),
        )
        bins = np.linspace(min(p_arr.min(), -abs(obs_d) * 1.15), max(p_arr.max(), abs(obs_d) * 1.15), 42)
        counts, edges = np.histogram(p_arr, bins=bins, density=True)
        centers = 0.5 * (edges[:-1] + edges[1:])
        widths = edges[1:] - edges[:-1]
        tail = np.abs(centers) >= abs(obs_d)
        ax_p.bar(centers[~tail], counts[~tail], width=widths[~tail], color=OI["sky"], edgecolor="white", lw=0.3, alpha=0.8)
        ax_p.bar(centers[tail], counts[tail], width=widths[tail], color=OI["vermilion"], edgecolor="white", lw=0.3, alpha=0.85)
        ax_p.axvline(obs_d, color=OI["vermilion"], lw=1.8, linestyle="-")
        ax_p.axvline(-obs_d, color=OI["vermilion"], lw=1.1, linestyle=":")
        ax_p.text(
            0.14, 0.90,
            f"Obs={obs_d:+.4f}, $P_{{perm}}$={p_two:.4f}",
            transform=ax_p.transAxes, va="top", ha="left", fontsize=7.1, fontweight="bold", color=OI["vermilion"],
            bbox=dict(boxstyle="round,pad=0.16", fc="white", ec="#DDDDDD", lw=0.5, alpha=0.92),
        )
        ax_p.set_ylabel("Density", fontsize=7.2)
        if p_idx == 2:
            ax_p.set_xlabel("Permuted Mean Difference ($B=10{,}000$)", fontsize=8.0)
        ax_p.set_title(title_p, loc="left", fontsize=8.4, pad=3)
        despine(ax_p)

    # --- Panel c1: Subregion-Level PFC Sensitivity (DFC, MFC, OFC, VFC) ---
    ax_c1 = fig.add_subplot(bot_gs[0, 0])
    add_panel_label(ax_c1, "c", x=-0.16, y=1.06)

    pfc_subs = ["DFC", "MFC", "OFC", "VFC"]
    age_pcw = meta["age_pcw"].values
    w1_prim = (age_pcw >= 12.0) & (age_pcw <= 142.3)
    w2_prim = (age_pcw >= 663.7) & (age_pcw <= 1341.5)
    t_asd_rows = [ens_to_row[eid] for eid in gt.loc[t_asd_m, "ensembl_gene_id"]]
    t_scz_rows = [ens_to_row[eid] for eid in gt.loc[t_scz_m, "ensembl_gene_id"]]

    def compute_region_dz(sub_mask: np.ndarray, rows: List[int]) -> np.ndarray:
        sub_m = mat[rows][:, sub_mask].astype(np.float64)
        mu = sub_m.mean(axis=1, keepdims=True)
        sd = sub_m.std(axis=1, ddof=0, keepdims=True)
        ok = sd[:, 0] > 1e-8
        z = (sub_m[ok] - mu[ok]) / sd[ok]
        return z[:, w2_prim[sub_mask]].mean(axis=1) - z[:, w1_prim[sub_mask]].mean(axis=1)

    x_sub = np.arange(len(pfc_subs))
    w_sub = 0.34
    ax_c1.axhline(0, color="gray", linestyle=":", lw=0.8)
    for i, reg in enumerate(pfc_subs):
        rmask = (meta["structure_acronym"] == reg).values
        dz_a = compute_region_dz(rmask, t_asd_rows)
        dz_s = compute_region_dz(rmask, t_scz_rows)
        _, p_mw = stats.mannwhitneyu(dz_s, dz_a, alternative="two-sided")
        ax_c1.bar(
            i - w_sub / 2, dz_a.mean(), yerr=1.96 * stats.sem(dz_a),
            width=w_sub, color=OI["blue"], edgecolor="black", lw=0.6, capsize=2.5,
            label="DefC $T_{ASD}$" if i == 0 else None,
        )
        ax_c1.bar(
            i + w_sub / 2, dz_s.mean(), yerr=1.96 * stats.sem(dz_s),
            width=w_sub, color=OI["vermilion"], edgecolor="black", lw=0.6, capsize=2.5,
            label="DefC $T_{SCZ}$" if i == 0 else None,
        )
        y_top = max(dz_a.mean() + 1.96 * stats.sem(dz_a), dz_s.mean() + 1.96 * stats.sem(dz_s)) + 0.08
        ax_c1.text(i, y_top, f"$P_{{MW}}$={p_mw:.3f}\n($n_s$={int(rmask.sum())})", ha="center", va="bottom", fontsize=6.8, fontweight="bold")

    ax_c1.set_xticks(x_sub)
    ax_c1.set_xticklabels(pfc_subs, fontsize=8.2)
    ax_c1.set_ylabel("Mean $\\Delta Z_{region}$ (±95% CI)")
    ax_c1.set_ylim(-0.62, 0.48)
    ax_c1.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c1)
    ax_c1.set_title("PFC Subregion Sensitivity (DefC)", loc="left", pad=8)
    ax_c1.legend(loc="lower right", fontsize=7.2)

    # --- Panel c2: CPEB4, SRRM4, CAMK2A PFC vs non-PFC Interaction Slopes ---
    int_gs = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=bot_gs[0, 1], wspace=0.28)
    tr_map = {r["feature"]: r for r in bio["analysis_2_brainspan_timing"]["trajectory_regressions"]}
    pfc_b = traj["is_pfc"].values.astype(bool)
    x_age = traj["log2_pcw"].values.astype(float)
    x_line = np.linspace(x_age.min(), x_age.max(), 100)

    for g_idx, gname in enumerate(["CPEB4", "SRRM4", "CAMK2A"]):
        ax_g = fig.add_subplot(int_gs[0, g_idx])
        if g_idx == 0:
            add_panel_label(ax_g, "d", x=-0.26, y=1.13)
        y_val = traj[gname].values.astype(float)
        # Raw points
        ax_g.scatter(x_age[~pfc_b], y_val[~pfc_b], s=7, color=OI["lightgray"], alpha=0.65, label="Non-PFC" if g_idx == 0 else None)
        ax_g.scatter(x_age[pfc_b], y_val[pfc_b], s=9, color=OI["blue"], alpha=0.65, label="PFC" if g_idx == 0 else None)
        # OLS fits
        b_non = np.polyfit(x_age[~pfc_b], y_val[~pfc_b], 1)
        b_pfc = np.polyfit(x_age[pfc_b], y_val[pfc_b], 1)
        ax_g.plot(x_line, np.polyval(b_non, x_line), color=OI["gray"], lw=1.6, linestyle="--", label="Non-PFC slope" if g_idx == 0 else None)
        ax_g.plot(x_line, np.polyval(b_pfc, x_line), color=OI["vermilion"], lw=1.8, linestyle="-", label="PFC slope" if g_idx == 0 else None)

        info = tr_map[gname]
        ax_g.text(
            0.04, 0.96,
            f"PFC $\\beta$={info['pfc_slope']:+.3f}\nNon $\\beta$={info['nonpfc_slope']:+.3f}\n$P_{{int}}$={fmt_p(info['ols_p_interaction'])}",
            transform=ax_g.transAxes, va="top", ha="left", fontsize=6.5, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#CCCCCC", lw=0.6),
        )
        ax_g.set_xticks([3, 5, 7, 9, 11])
        ax_g.set_xticklabels(["8p", "35p", "2y", "10y", "40y"], fontsize=6.8)
        ax_g.set_xlabel("$\\log_2$ pcw", fontsize=7.5)
        if g_idx == 0:
            ax_g.set_ylabel("$\\log_2$(RPKM + 1)", fontsize=8.0)
            ax_g.legend(
                loc="lower left", bbox_to_anchor=(0.0, 1.13),
                ncol=4, fontsize=6.6, columnspacing=0.9, handletextpad=0.3,
            )
        ax_g.set_title(gname, loc="left", fontsize=8.8, pad=6)
        ax_g.grid(True, linestyle=":", alpha=0.25)
        despine(ax_g)

    return save_figure(fig, "Figure_S2")


# ---------------------------------------------------------------------------
# Helpers to Load 04_ & 05_ Modules Cleanly for Exact Trajectory / Cohort Plots
# ---------------------------------------------------------------------------
def _load_src_module(mod_name: str, filename: str):
    path = BASE_DIR / "src" / filename
    spec = importlib.util.spec_from_file_location(mod_name, str(path))
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


_CACHE_COHORT: Dict[str, Any] = {}


def _get_ctl_and_cohort() -> Dict[str, Any]:
    if _CACHE_COHORT:
        return _CACHE_COHORT
    ctl = _load_src_module("ctl04", "04_multiscale_ctl_model.py")
    sens = _load_src_module("sens05", "05_sensitivity_and_cohort.py")
    ctx = ctl.build_ctl_context()
    latent = sens._draw_cohort_latent_inputs(100000, ctx["t_grid"], seed=sens.SEED)
    cohort = sens.simulate_cohort_variant(ctx, latent, r_g=0.211, compute_onsets=False)
    _CACHE_COHORT.update({"ctl": ctl, "sens": sens, "ctx": ctx, "latent": latent, "cohort": cohort})
    return _CACHE_COHORT


# ---------------------------------------------------------------------------
# Figure 4: Multiscale CTL Dynamical Bifurcation & Phase Diagrams
# ---------------------------------------------------------------------------
def plot_figure_4() -> List[Path]:
    print("Generating Figure_4...")
    traj = pd.read_csv(RESULTS_DIR / "ctl_trajectories.csv")
    pg_tc = pd.read_csv(RESULTS_DIR / "phase_grid_tau_chi.csv")
    pg_pc = pd.read_csv(RESULTS_DIR / "phase_grid_prs_chi.csv")
    pd_json = json.loads((RESULTS_DIR / "ctl_phase_diagrams.json").read_text(encoding="utf-8"))

    fig = plt.figure(figsize=(15.0, 10.8))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.34, wspace=0.28)

    # --- Panel a: Developmental Kernels & Huttenlocher PFC Synaptic Density Ns(t) ---
    a_gs = gridspec.GridSpecFromSubplotSpec(2, 1, subplot_spec=gs[0, 0], height_ratios=[0.85, 1.15], hspace=0.28)
    ax_a1 = fig.add_subplot(a_gs[0, 0])
    add_panel_label(ax_a1, "a", x=-0.13, y=1.10)

    t_ctrl = traj[traj["scenario"] == "Control_0.30"].sort_values("age_years")
    t_ages = t_ctrl["age_years"].values
    v_asd_norm = t_ctrl["V_ASD"].values / max(t_ctrl["V_ASD"].max(), 1e-12)
    v_scz_norm = t_ctrl["V_SCZ"].values / max(t_ctrl["V_SCZ"].max(), 1e-12)
    vk_sum = pd_json["vulnerability_kernel_summary"]

    ax_a1.plot(t_ages, t_ctrl["D_act_emp"].values, color="black", lw=1.9, linestyle="-",
               label=f"$D_{{act,emp}}$ (peak {vk_sum['D_act_emp_peak_yr']:.1f} yr)")
    ax_a1.plot(t_ages, v_asd_norm, color=OI["blue"], lw=1.9, linestyle="-",
               label=f"$V_{{ASD}}(t)$ (peak {vk_sum['V_ASD_peak_yr']:.2f} yr)")
    ax_a1.plot(t_ages, v_scz_norm, color=OI["vermilion"], lw=1.9, linestyle="--",
               label=f"$V_{{SCZ}}(t)$ (peak {vk_sum['V_SCZ_peak_yr']:.2f} yr)")
    ax_a1.axvspan(0.0, 6.0, color=OI["sky"], alpha=0.10)
    ax_a1.axvspan(12.0, 26.0, color=OI["orange"], alpha=0.10)
    ax_a1.set_xlim(-0.6, 30.0)
    ax_a1.set_ylim(-0.04, 1.32)
    ax_a1.set_yticks([0.0, 0.5, 1.0])
    ax_a1.set_ylabel("Norm. Kernel")
    ax_a1.tick_params(labelbottom=False)
    ax_a1.grid(True, linestyle=":", alpha=0.25)
    despine(ax_a1)
    ax_a1.set_title("Developmental Forcing & PFC Synaptic Density", loc="left", pad=6)
    ax_a1.legend(loc="upper center", fontsize=6.7, ncol=3, columnspacing=0.8, handlelength=1.5)

    ax_a2 = fig.add_subplot(a_gs[1, 0], sharex=ax_a1)
    hutt = pd_json["huttenlocher_petanjek_control_landmarks"]
    scen_styles = [
        ("Control_0.30", "Control ($\\chi=0.30$)", "black", "-", 2.0),
        ("Constitutional_ASD_0.45_WT", "Early ASD ($\\chi=0.45$, WT)", OI["blue"], "-", 1.9),
        ("Adolescent_SCZ_0.38_SCZPRS", "Adol. SCZ ($\\chi=0.38$, SCZ-PRS)", OI["vermilion"], "--", 1.9),
        ("Comorbid_E14.5_0.46_DualPRS", "Comorbid ($0.46$, Dual-PRS)", OI["purple"], "-.", 1.9),
    ]
    for sc, lbl, col, ls, lw in scen_styles:
        sub = traj[traj["scenario"] == sc].sort_values("age_years")
        ax_a2.plot(sub["age_years"].values, sub["Ns"].values, color=col, linestyle=ls, lw=lw, label=lbl)

    ax_a2.scatter([hutt["t_peak_yr"], 30.0], [hutt["Ns_childhood_peak"], hutt["Ns_adult_30yr"]],
                  color="black", s=28, zorder=5)
    ax_a2.annotate(
        f"Peak {hutt['Ns_childhood_peak']:.2f} ({hutt['t_peak_yr']:.2f} yr)\n−{hutt['adolescent_pruning_decline_pct']:.1f}% pruning",
        xy=(hutt["t_peak_yr"], hutt["Ns_childhood_peak"]),
        xytext=(6.2, 1.44),
        fontsize=6.9, fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="black", lw=0.8),
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#CCCCCC", lw=0.6),
    )
    ax_a2.set_xlim(-0.6, 30.2)
    ax_a2.set_ylim(0.0, 1.85)
    ax_a2.set_xlabel("Age (years)")
    ax_a2.set_ylabel("PFC Synaptic Density $N_s(t)$")
    ax_a2.grid(True, linestyle=":", alpha=0.25)
    despine(ax_a2)
    ax_a2.legend(loc="upper right", fontsize=6.4, ncol=2, columnspacing=0.8, frameon=True, facecolor="white", framealpha=0.92, edgecolor="none")

    # Regime color map: 0=Resilient, 1=ASD-only, 2=SCZ-only, 3=Comorbid
    reg_order = ["Resilient", "ASD-only", "SCZ-only", "Comorbid"]
    reg_to_idx = {r: i for i, r in enumerate(reg_order)}
    reg_cmap = ListedColormap(["#EAECEE", OI["sky"], OI["orange"], OI["purple"]])
    reg_norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5], reg_cmap.N)

    # --- Panel b: 2D (tau_on, delta_chi) Phase Diagram (Sensitized_PRS) ---
    ax_b = fig.add_subplot(gs[0, 1])
    add_panel_label(ax_b, "b", x=-0.13, y=1.06)

    sub_tc = pg_tc[pg_tc["background"] == "Sensitized_PRS"].copy()
    taus = np.sort(sub_tc["tau_on_yr"].unique())
    dchis = np.sort(sub_tc["delta_chi"].unique())
    piv_reg = sub_tc.pivot(index="delta_chi", columns="tau_on_yr", values="regime").loc[dchis, taus]
    piv_psi = sub_tc.pivot(index="delta_chi", columns="tau_on_yr", values="Psi").loc[dchis, taus].values
    reg_grid = np.vectorize(reg_to_idx.get)(piv_reg.values)

    T_mesh, D_mesh = np.meshgrid(taus, dchis)
    ax_b.pcolormesh(T_mesh, D_mesh, reg_grid, cmap=reg_cmap, norm=reg_norm, shading="nearest")
    cs_b = ax_b.contour(T_mesh, D_mesh, piv_psi, levels=[0.0], colors=["black"], linestyles=["--"], linewidths=2.0)
    ax_b.clabel(cs_b, fmt={0.0: "$\\Psi=0$"}, fontsize=7.5, inline=True)

    # Overlay mouse induction stage markers cleanly without label overlap
    stage_pts = [
        (-0.44, 0.16, "E14.5", (1.6, 0.178)),
        (0.15, 0.16, "P10", (2.2, 0.143)),
        (14.0, 0.08, "P42 (0.38)", (14.6, 0.084)),
    ]
    for sx, sy, slbl, (tx, ty) in stage_pts:
        ax_b.scatter([sx], [sy], marker="D", s=38, color="white", edgecolor="black", lw=1.0, zorder=5)
        ax_b.annotate(
            slbl, xy=(sx, sy), xytext=(tx, ty),
            fontsize=6.9, fontweight="bold", color="black", va="center",
            arrowprops=dict(arrowstyle="-", color="black", lw=0.7) if abs(tx - sx) > 0.8 else None,
        )

    # Also mark WT ASD-only threshold line contour
    sub_wt = pg_tc[pg_tc["background"] == "WT"].copy()
    piv_wt_asd = sub_wt.pivot(index="delta_chi", columns="tau_on_yr", values="L_ASD_norm").loc[dchis, taus].values
    ax_b.contour(T_mesh, D_mesh, piv_wt_asd, levels=[1.0], colors=["white"], linestyles=[":"], linewidths=1.5)

    handles_reg = [mpatches.Patch(facecolor=c, edgecolor="black", lw=0.6, label=l)
                   for c, l in zip(["#EAECEE", OI["sky"], OI["orange"], OI["purple"]], reg_order)]
    handles_reg.append(Line2D([0], [0], color="black", lw=1.8, ls="--", label="$\\Psi=0$ separatrix"))
    ax_b.legend(handles=handles_reg, loc="lower right", fontsize=6.8, frameon=True, facecolor="white", framealpha=0.92)
    ax_b.set_xlabel("Perturbation Onset Age $\\tau_{on}$ (years)")
    ax_b.set_ylabel("Splicing Perturbation $\\Delta\\chi_{\\Delta 4}$ (above $0.30$)")
    ax_b.set_title("Timing × Dosing Diagnostic Phase Diagram (Sensitized PRS)", loc="left", pad=8)

    # --- Panel c: (Delta P_{SCZ-ASD}, chi_delta4) Gene x Dosing Phase Diagram ---
    ax_c = fig.add_subplot(gs[1, 0])
    add_panel_label(ax_c, "c", x=-0.13, y=1.06)

    sub_pc = pg_pc[pg_pc["slice_name"] == "SharedRisk_Mean0.75"].copy()
    pdiffs = np.sort(sub_pc["P_SCZ_minus_P_ASD"].unique())
    chis = np.sort(sub_pc["chi_delta4"].unique())
    piv_pc_reg = sub_pc.pivot(index="chi_delta4", columns="P_SCZ_minus_P_ASD", values="regime").loc[chis, pdiffs]
    piv_pc_psi = sub_pc.pivot(index="chi_delta4", columns="P_SCZ_minus_P_ASD", values="Psi").loc[chis, pdiffs].values
    pc_grid = np.vectorize(reg_to_idx.get)(piv_pc_reg.values)

    P_mesh, C_mesh = np.meshgrid(pdiffs, chis)
    ax_c.pcolormesh(P_mesh, C_mesh, pc_grid, cmap=reg_cmap, norm=reg_norm, shading="nearest")
    cs_c = ax_c.contour(P_mesh, C_mesh, piv_pc_psi, levels=[0.0], colors=["black"], linestyles=["--"], linewidths=2.0)
    ax_c.clabel(cs_c, fmt={0.0: "$\\Psi=0$"}, fontsize=7.5, inline=True)

    for chi_ref, rlbl in [(0.30, "Ctrl 0.30"), (0.38, "Subthresh 0.38"), (0.45, "ASD 0.45")]:
        ax_c.axhline(chi_ref, color="black", linestyle=":", lw=0.9, alpha=0.65)
        ax_c.text(-3.85, chi_ref + 0.003, rlbl, fontsize=6.7, fontweight="bold", color="#222222")
    ax_c.axvline(0.0, color="#444444", linestyle="-.", lw=0.8, alpha=0.7)

    ax_c.set_xlabel("Polygenic Balance $\\Delta P_{SCZ - ASD}$ (SD)")
    ax_c.set_ylabel("CPEB4$\\Delta 4$ Mole Fraction ($\\chi_{\\Delta 4}$)")
    ax_c.set_title("Polygenic Balance × Dosing Bifurcation (Shared-Risk Slice)", loc="left", pad=8)

    # --- Panel d: Continuous Phenotypic Bias Index Psi Heatmap ---
    ax_d = fig.add_subplot(gs[1, 1])
    add_panel_label(ax_d, "d", x=-0.13, y=1.06)

    im_d = ax_d.pcolormesh(T_mesh, D_mesh, piv_psi, cmap="RdBu_r", vmin=-1.0, vmax=1.0, shading="gouraud")
    cs_d0 = ax_d.contour(T_mesh, D_mesh, piv_psi, levels=[0.0], colors=["black"], linestyles=["-"], linewidths=2.0)
    ax_d.clabel(cs_d0, fmt={0.0: "$\\Psi=0$"}, fontsize=7.8, inline=True)

    # Overlay diagnostic thresholds L_ASD=1 and L_SCZ=1
    piv_la = sub_tc.pivot(index="delta_chi", columns="tau_on_yr", values="L_ASD_norm").loc[dchis, taus].values
    piv_ls = sub_tc.pivot(index="delta_chi", columns="tau_on_yr", values="L_SCZ_norm").loc[dchis, taus].values
    ax_d.contour(T_mesh, D_mesh, piv_la, levels=[1.0], colors=[OI["blue"]], linestyles=["--"], linewidths=1.5)
    ax_d.contour(T_mesh, D_mesh, piv_ls, levels=[1.0], colors=[OI["vermilion"]], linestyles=["-."], linewidths=1.5)

    ax_d.text(
        0.1, 0.165, "ASD\n($\\Psi<0$)", color=OI["blue"], fontsize=6.9, fontweight="bold", ha="center",
        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.82),
    )
    ax_d.text(12.2, 0.165, "SCZ-skewed\n($\\Psi \\rightarrow +1$)", color="white", fontsize=7.6, fontweight="bold", ha="center")
    cbar_d = fig.colorbar(im_d, ax=ax_d, fraction=0.044, pad=0.03)
    cbar_d.set_label("Phenotypic Bias Index $\\Psi$", fontsize=7.8)
    cbar_d.ax.tick_params(labelsize=7.2)

    handles_d = [
        Line2D([0], [0], color="black", lw=2.0, ls="-", label="$\\Psi=0$ separatrix"),
        Line2D([0], [0], color=OI["blue"], lw=1.5, ls="--", label="$L_{ASD} = \\theta_{ASD}$"),
        Line2D([0], [0], color=OI["vermilion"], lw=1.5, ls="-.", label="$L_{SCZ} = \\theta_{SCZ}$"),
    ]
    ax_d.legend(handles=handles_d, loc="lower right", fontsize=6.7, frameon=True, facecolor="white", framealpha=0.9)
    ax_d.set_xlabel("Perturbation Onset Age $\\tau_{on}$ (years)")
    ax_d.set_ylabel("Splicing Perturbation $\\Delta\\chi_{\\Delta 4}$")
    ax_d.set_title("Continuous Phenotypic Bias Landscape $\\Psi(\\tau_{on}, \\Delta\\chi)$", loc="left", pad=8)

    return save_figure(fig, "Figure_4")


# ---------------------------------------------------------------------------
# Figure 5: Nested Model Selection, Global Sensitivity, Cohort & Convergence
# ---------------------------------------------------------------------------
def plot_figure_5() -> List[Path]:
    print("Generating Figure_5...")
    mc = pd.read_csv(RESULTS_DIR / "model_comparison.csv")
    sobol = pd.read_csv(RESULTS_DIR / "sensitivity_sobol.csv")
    prcc = pd.read_csv(RESULTS_DIR / "sensitivity_prcc.csv")
    cv = pd.read_csv(RESULTS_DIR / "cohort_validation.csv")
    mm = json.loads((RESULTS_DIR / "master_metrics.json").read_text(encoding="utf-8"))
    pd_json = json.loads((RESULTS_DIR / "ctl_phase_diagrams.json").read_text(encoding="utf-8"))

    # Reproduce exact cohort onsets & solver residual curves cleanly
    bundle = _get_ctl_and_cohort()
    ctl, sens, ctx, latent, cohort = bundle["ctl"], bundle["sens"], bundle["ctx"], bundle["latent"], bundle["cohort"]

    fig = plt.figure(figsize=(15.4, 11.2))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.38, wspace=0.30)

    # --- Panel a: Nested Model Selection + Benchmark Pass Matrix ---
    ax_a = fig.add_subplot(gs[0, 0])
    add_panel_label(ax_a, "a", x=-0.22, y=1.06)

    m_order = [
        ("H0_Null_Linear_WindowBlind", "$H_0$: Linear, Window-blind"),
        ("H1_Cooperative_WindowBlind", "$H_1$: Coop., Window-blind"),
        ("H2_Timing_Dact_NoPRS_Coupling", "$H_2$: +Timing/$D_{act}$, No PRS"),
        ("H3_Timing_AdditivePRS_NoMult", "$H_3$: +Additive PRS"),
        ("H_full_Multiscale_CTL", "$H_{full}$: Full Multiscale CTL"),
    ]
    mc_idx = mc.set_index("model_id")
    ym = np.arange(len(m_order))[::-1]
    daics = [float(mc_idx.loc[mid, "delta_aic"]) for mid, _ in m_order]
    weights = [float(mc_idx.loc[mid, "akaike_weight"]) for mid, _ in m_order]

    # Plot on log1p scale so H0=204 and H3=2.11 are both visually readable
    bar_cols = [OI["gray"], OI["gray"], OI["sky"], OI["sky"], OI["blue"]]
    ax_a.barh(ym, np.log10(np.array(daics) + 1.0), color=bar_cols, edgecolor="black", lw=0.7, height=0.58)
    for y, da, w in zip(ym, daics, weights):
        xp = math.log10(da + 1.0)
        w_str = f"$w$={w:.3f}" if w >= 0.001 else f"$w$={w:.1e}"
        ax_a.text(xp + 0.05, y, f"$\\Delta$AIC={da:.2f} ({w_str})", va="center", ha="left", fontsize=7.0,
                  fontweight="bold" if da == 0 else "normal", color=OI["blue"] if da == 0 else "#222222")

    # Benchmark pass matrix inset on right side of panel a (vector check/cross glyphs for zero font warnings)
    bench_cols = ["pass_fig4d", "pass_brainspan_timing", "pass_solmi_onset", "pass_zheng_comorb_ci", "pass_parras_olla_chi"]
    bench_lbls = ["Fig4d", "Brain\nSpan", "Solmi\nOnset", "Zheng\nOR", "Cort.\n$\\chi$"]
    x_bench_start = 4.02
    dx_b = 0.34
    for j, bl in enumerate(bench_lbls):
        ax_a.text(x_bench_start + j * dx_b, ym[0] + 0.52, bl, ha="center", va="bottom", fontsize=6.4, fontweight="bold")
    for i, (mid, _) in enumerate(m_order):
        y = ym[i]
        for j, bc in enumerate(bench_cols):
            ok = bool(mc_idx.loc[mid, bc])
            xc = x_bench_start + j * dx_b
            ax_a.scatter(
                [xc], [y],
                marker="s", s=80,
                facecolor=OI["green"] if ok else "#F2D7D5",
                edgecolor="black", lw=0.6, zorder=4,
            )
            if ok:
                ax_a.plot([xc - 0.055, xc - 0.01, xc + 0.065], [y - 0.01, y - 0.09, y + 0.09],
                          color="white", lw=1.6, solid_capstyle="round", zorder=5)
            else:
                ax_a.plot([xc - 0.05, xc + 0.05], [y - 0.08, y + 0.08], color=OI["vermilion"], lw=1.4, zorder=5)
                ax_a.plot([xc - 0.05, xc + 0.05], [y + 0.08, y - 0.08], color=OI["vermilion"], lw=1.4, zorder=5)

    ax_a.set_yticks(ym)
    ax_a.set_yticklabels([lbl for _, lbl in m_order], fontsize=7.7)
    ax_a.set_xlim(0.0, 5.75)
    ax_a.set_xticks([0, math.log10(4), math.log10(11), math.log10(101), math.log10(205)])
    ax_a.set_xticklabels(["0", "3", "10", "100", "204"], fontsize=7.5)
    ax_a.set_xlabel("$\\Delta$AIC (log$_{10}$($\\Delta$AIC + 1) scale)")
    ax_a.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("Nested Model Comparison & 5-Benchmark Pass Matrix", loc="left", pad=22)

    # --- Panel b: Global Sobol Sensitivity (Psi & chi_c_eff) + PRCC ---
    b_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[0, 1], width_ratios=[1.15, 0.85], wspace=0.35)
    ax_b1 = fig.add_subplot(b_gs[0, 0])
    add_panel_label(ax_b1, "b", x=-0.22, y=1.06)

    # Top Sobol parameters for Psi & chi_c_eff(W2)
    sob_psi = sobol[sobol["output_metric"] == "Psi"].sort_values("S_Ti", ascending=False).head(5)
    sob_chi = sobol[sobol["output_metric"] == "chi_c_eff_W2"].sort_values("S_Ti", ascending=False).head(3)
    sob_comb = pd.concat([sob_psi, sob_chi], ignore_index=True)

    param_labels = {
        "P_SCZ": "$P_{SCZ}$ ($\\Psi$)",
        "P_ASD": "$P_{ASD}$ ($\\Psi$)",
        "tau_on_yr": "$\\tau_{on}$ ($\\Psi$)",
        "delta_chi": "$\\Delta\\chi_{\\Delta 4}$ ($\\Psi$)",
        "gamma_SCZ": "$\\gamma_{SCZ}$ ($\\Psi$)",
        "chi_c_ref_pH8": "$\\chi_c^{ref}$ ($\\chi_c^{eff}$)",
        "n_H": "$n_H$ ($\\chi_c^{eff}$)",
        "k_clr": "$k_{clr}$ ($\\chi_c^{eff}$)",
    }
    yb = np.arange(len(sob_comb))[::-1]
    si_vals = np.maximum(0.0, sob_comb["S_i"].values)
    st_vals = sob_comb["S_Ti"].values
    inter_vals = np.maximum(0.0, st_vals - si_vals)
    st_err_lo = st_vals - sob_comb["S_Ti_ci95_low"].values
    st_err_hi = sob_comb["S_Ti_ci95_high"].values - st_vals

    ax_b1.barh(yb, si_vals, color=OI["blue"], edgecolor="black", lw=0.6, height=0.6, label="First-order $S_i$")
    ax_b1.barh(yb, inter_vals, left=si_vals, color=OI["sky"], edgecolor="black", lw=0.6, hatch="///", height=0.6, label="Interaction ($S_{Ti}-S_i$)")
    ax_b1.errorbar(st_vals, yb, xerr=[st_err_lo, st_err_hi], fmt="none", ecolor="black", elinewidth=1.0, capsize=2.0)
    ax_b1.axhline(2.5, color="gray", linestyle="--", lw=0.8)
    for y, st in zip(yb, st_vals):
        ax_b1.text(st + 0.03, y, f"{st:.3f}", va="center", ha="left", fontsize=6.7)

    ax_b1.set_yticks(yb)
    ax_b1.set_yticklabels([param_labels.get(p, p) for p in sob_comb["parameter"]], fontsize=7.3)
    ax_b1.set_xlim(0.0, 1.02)
    ax_b1.set_xlabel("Sobol Index ($S_i$ + Interaction, 95% CI)")
    ax_b1.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_b1)
    ax_b1.set_title("Global Sobol Sensitivity", loc="left", fontsize=8.8, pad=8)
    ax_b1.legend(loc="center right", fontsize=6.6)

    ax_b2 = fig.add_subplot(b_gs[0, 1])
    pr_psi = prcc[prcc["output_metric"] == "Psi"].sort_values("abs_prcc", ascending=False).head(6)
    yp = np.arange(len(pr_psi))[::-1]
    p_cols = [OI["vermilion"] if v > 0 else OI["blue"] for v in pr_psi["prcc"]]
    ax_b2.axvline(0.0, color="black", lw=0.8)
    ax_b2.barh(yp, pr_psi["prcc"].values, color=p_cols, edgecolor="black", lw=0.6, height=0.58)
    ax_b2.set_yticks(yp)
    ax_b2.set_yticklabels(pr_psi["parameter"].tolist(), fontsize=7.2)
    ax_b2.set_xlim(-0.88, 0.85)
    ax_b2.set_xlabel("LHS-PRCC ($\\Psi$)")
    ax_b2.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_b2)
    ax_b2.set_title("Top PRCC ($N=5{,}000$)", loc="left", fontsize=8.8, pad=8)

    # --- Panel c: N=100,000 Birth Cohort Validation (Onsets + Cortical chi_delta4) ---
    c_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[1, 0], width_ratios=[1.15, 0.85], wspace=0.32)
    ax_c1 = fig.add_subplot(c_gs[0, 0])
    add_panel_label(ax_c1, "c", x=-0.18, y=1.06)

    # Reproduce exact onset age arrays on the 1,800 ASD and 850 SCZ cases
    t_g = ctx["t_grid"]
    dt = ctx["dt"]
    p23 = ctx["p23"]
    p1 = ctx["p1"]
    p_asd = cohort["arrays"]["P_ASD"]
    p_scz = cohort["arrays"]["P_SCZ"]
    g_asd = ctl.eq9_polygenic_amplification(p_asd, p23["gamma_ASD"], p23["c_P"])[:, None]
    g_scz = ctl.eq9_polygenic_amplification(p_scz, p23["gamma_SCZ"], p23["c_P"])[:, None]
    phi_ctrl = ctl.eval_qss_phi_vec(np.full((1, len(t_g)), ctl.CHI_CTRL), ctx["d_act_grid"], p1)
    ns_ctrl = ctl.solve_ns_crank_nicolson(phi_ctrl, np.ones((1, 1)), np.ones((1, 1)), ctx)[0]
    defic_ctrl = (1.0 - phi_ctrl)[0]

    def _subset_onsets(mask: np.ndarray, is_asd: bool, theta: float) -> np.ndarray:
        idx = np.where(mask)[0]
        phi_s = ctl.eval_qss_phi_vec(latent["chi_mat"][idx], ctx["d_act_grid"], p1)
        ns_s = ctl.solve_ns_crank_nicolson(phi_s, g_asd[idx], g_scz[idx], ctx)
        syn_l = np.maximum(0.0, ns_ctrl[None, :] - ns_s)
        if is_asd:
            integ = ctx["V_ASD_grid"][None, :] * (
                p23["w_P_ASD"] * p_asd[idx, None] + latent["eps_asd"][idx, None]
                + p23["w_Phi_ASD"] * ((1.0 - phi_s) * g_asd[idx] - defic_ctrl[None, :])
                + p23["w_N_ASD"] * syn_l
            )
        else:
            integ = ctx["V_SCZ_grid"][None, :] * (
                p23["w_P_SCZ"] * p_scz[idx, None] + latent["eps_scz"][idx, None]
                + p23["w_Phi_SCZ"] * ((1.0 - phi_s) * g_scz[idx] - defic_ctrl[None, :])
                + p23["w_N_SCZ"] * syn_l
            )
        traj_l = np.zeros((len(idx), len(t_g)))
        traj_l[:, 1:] = np.cumsum(0.5 * (integ[:, :-1] + integ[:, 1:]) * dt, axis=1)
        return ctl.first_crossing_ages(traj_l, theta, np.ones(len(idx), dtype=bool), t_g)

    on_asd = _subset_onsets(cohort["masks"]["ASD_all"], True, cohort["theta_ASD"])
    on_scz = _subset_onsets(cohort["masks"]["SCZ_all"], False, cohort["theta_SCZ"])

    bins_on = np.linspace(0.0, 30.0, 36)
    ax_c1.hist(on_asd, bins=bins_on, density=True, color=OI["blue"], alpha=0.65, edgecolor="white",
               label=f"ASD ($n={len(on_asd):,}$, med {np.median(on_asd):.2f} yr)")
    ax_c1.hist(on_scz, bins=bins_on, density=True, color=OI["vermilion"], alpha=0.65, edgecolor="white",
               label=f"SCZ ($n={len(on_scz):,}$, med {np.median(on_scz):.2f} yr)")
    ax_c1.axvline(np.median(on_asd), color=OI["blue"], ls="--", lw=1.6)
    ax_c1.axvline(np.median(on_scz), color=OI["vermilion"], ls="--", lw=1.6)
    # Solmi 2022 / CDC benchmarks
    ax_c1.axvspan(2.5, 5.5, color=OI["sky"], alpha=0.14, label="CDC/Solmi ASD peak")
    ax_c1.axvspan(20.5, 25.0, color=OI["orange"], alpha=0.14, label="Solmi SCZ peak (20.5–25)")

    bc_val = mm["step3b_scale2_3_multiscale_ctl"]["birth_cohort_validation_N100k"]["base_rG_0.211"]
    ax_c1.text(
        0.50, 0.68,
        f"Comorbid OR = {bc_val['comorbid_or']:.2f}\n[{bc_val['comorbid_or_ci95_low']:.2f}–{bc_val['comorbid_or_ci95_high']:.2f}]\n"
        f"(Zheng '18: 3.55 [2.08–6.05])",
        transform=ax_c1.transAxes, ha="center", va="center", fontsize=6.8, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#AAAAAA", lw=0.7),
    )
    ax_c1.set_xlim(0.0, 30.0)
    ax_c1.set_ylim(0.0, 0.32)
    ax_c1.set_xlabel("Emergent Clinical Onset Age (years)")
    ax_c1.set_ylabel("Density")
    ax_c1.grid(True, linestyle=":", alpha=0.25)
    despine(ax_c1)
    ax_c1.set_title("Out-of-Calibration Onsets ($N=100{,}000$)", loc="left", fontsize=8.8, pad=8)
    ax_c1.legend(loc="upper center", fontsize=6.4, ncol=1)

    ax_c2 = fig.add_subplot(c_gs[0, 1])
    cv_idx = cv.set_index("group")
    chi_groups = [
        ("Resilient", "chi_W1_mean", "chi_W1_sd", "Ctrl", OI["gray"]),
        ("SCZ_all", "chi_W2_mean", "chi_W2_sd", "SCZ\n(W2)", OI["vermilion"]),
        ("ASD_all", "chi_W1_mean", "chi_W1_sd", "ASD\n(W1)", OI["blue"]),
    ]
    xc2 = np.arange(len(chi_groups))
    for i, (gk, mk_c, sk_c, glbl, col) in enumerate(chi_groups):
        mu_c = float(cv_idx.loc[gk, mk_c])
        sd_c = float(cv_idx.loc[gk, sk_c])
        ax_c2.bar(i, mu_c, yerr=sd_c, width=0.56, color=col, edgecolor="black", lw=0.7, capsize=3.0, alpha=0.88)
        ax_c2.text(i, mu_c + sd_c + 0.008, f"{mu_c:.3f}", ha="center", va="bottom", fontsize=7.2, fontweight="bold")
    ax_c2.axhline(0.30, color="gray", linestyle=":", lw=0.8)
    ax_c2.set_xticks(xc2)
    ax_c2.set_xticklabels([x[3] for x in chi_groups], fontsize=7.6)
    ax_c2.set_ylim(0.20, 0.49)
    ax_c2.set_ylabel("Cortical $\\chi_{\\Delta 4}$ (Mean ± SD)")
    ax_c2.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c2)
    ax_c2.set_title("Emergent $\\chi_{\\Delta 4}$ Gradient", loc="left", fontsize=8.8, pad=8)

    # --- Panel d: Numerical Convergence (RK45 vs Radau & Adiabatic QSS Accuracy) ---
    d_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[1, 1], width_ratios=[1.10, 0.90], wspace=0.54)
    ax_d1 = fig.add_subplot(d_gs[0, 0])
    add_panel_label(ax_d1, "d", x=-0.20, y=1.06)

    num_scenarios = [
        ("Control_0.30", lambda _t: 0.30, 0.0, 0.0, OI["gray"], "-"),
        ("Early_ASD_0.45", lambda _t: 0.45, 0.0, 0.0, OI["blue"], "--"),
        ("Adolescent_SCZ_0.38", lambda t: ctl.eq14_chi_induction(t, 12.0, 0.08), 0.0, 1.5, OI["vermilion"], "-."),
        ("Comorbid_DualPRS", lambda t: ctl.eq14_chi_induction(t, -0.44, 0.16), 1.5, 1.5, OI["purple"], ":"),
    ]
    for lbl, chi_fn, pa, ps, col, ls in num_scenarios:
        sol_rad = ctl.solve_coupled_ode(chi_fn, pa, ps, ctx, t_eval=t_g, method="Radau", rtol=1e-10, atol=1e-12)
        sol_rk = ctl.solve_coupled_ode(chi_fn, pa, ps, ctx, t_eval=t_g, method="RK45", rtol=1e-10, atol=1e-12)
        err_t = np.maximum(np.maximum(np.abs(sol_rk["L"] - sol_rad["L"]), np.abs(sol_rk["S"] - sol_rad["S"])),
                           np.abs(sol_rk["Ns"] - sol_rad["Ns"]))
        ax_d1.semilogy(t_g, np.maximum(err_t, 1e-14), color=col, ls=ls, lw=1.5, label=lbl.replace("_", " "))

    max_rk = pd_json["numerical_verification"]["max_abs_diff_rk45_vs_radau_state"]
    ax_d1.axhline(1e-10, color="black", ls="--", lw=0.9, label=f"tol ($10^{{-10}}$), max={max_rk:.2e}")
    ax_d1.set_xlim(-0.6, 30.0)
    ax_d1.set_ylim(1e-14, 1e-8)
    ax_d1.set_xlabel("Age (years)")
    ax_d1.set_ylabel("$|\\mathrm{RK45} - \\mathrm{Radau}|_\\infty$ State Diff")
    ax_d1.grid(True, linestyle=":", alpha=0.25)
    despine(ax_d1)
    ax_d1.set_title("ODE Solver Convergence", loc="left", fontsize=8.8, pad=8)
    ax_d1.legend(loc="lower right", fontsize=6.3)

    ax_d2 = fig.add_subplot(d_gs[0, 1])
    sc_det = pd_json["numerical_verification"]["scenario_details"]
    yd2 = np.arange(len(sc_det))[::-1]
    ns_errs = [d["max_abs_diff_qss_vs_ode_Ns"] for d in sc_det]
    psi_errs = [max(d["abs_diff_qss_vs_ode_Psi"], 1e-7) for d in sc_det]
    ax_d2.barh(yd2 + 0.17, ns_errs, height=0.32, color=OI["blue"], edgecolor="black", lw=0.6, label="$\\max|\\Delta N_s|$")
    ax_d2.barh(yd2 - 0.17, psi_errs, height=0.32, color=OI["orange"], edgecolor="black", lw=0.6, label="$|\\Delta\\Psi|$")
    ax_d2.set_xscale("log")
    ax_d2.set_xlim(1e-7, 3e-2)
    ax_d2.set_ylim(-1.1, 4.6)
    short_sc = {
        "Control_0.30": "Ctrl 0.30",
        "Early_ASD_0.45": "Early ASD 0.45",
        "Adolescent_SCZ_0.38": "Adol. SCZ 0.38",
        "Comorbid_DualPRS": "Comorbid",
        "SSO_Rescue_2yr": "SSO Rescue 2y",
    }
    ax_d2.set_yticks(yd2)
    ax_d2.set_yticklabels([short_sc.get(d["scenario"], d["scenario"].replace("_", " ")) for d in sc_det], fontsize=6.9)
    ax_d2.set_xlabel("Coupled ODE vs. QSS Error")
    ax_d2.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_d2)
    ax_d2.set_title("Adiabatic QSS Accuracy", loc="left", fontsize=8.8, pad=8)
    ax_d2.legend(loc="lower right", fontsize=6.5, ncol=2)

    return save_figure(fig, "Figure_5")


# ---------------------------------------------------------------------------
# Figure 6: In Silico Conditional Murine Trial & SSO Reversibility Windows
# ---------------------------------------------------------------------------
def plot_figure_6() -> List[Path]:
    print("Generating Figure_6...")
    mouse = pd.read_csv(RESULTS_DIR / "insilico_mouse_predictions.csv")
    sso = pd.read_csv(RESULTS_DIR / "sso_rescue_curves.csv")

    fig = plt.figure(figsize=(15.4, 10.2))
    gs = gridspec.GridSpec(2, 2, figure=fig, height_ratios=[1.05, 0.95], hspace=0.36, wspace=0.28)

    # --- Panel a: 3x3 Stage x Background Effect Sizes (Cohen's d) ---
    ax_a = fig.add_subplot(gs[0, 0])
    add_panel_label(ax_a, "a", x=-0.16, y=1.06)

    m16 = mouse[np.isclose(mouse["delta_chi"], 0.16)].copy()
    stages = ["E14.5", "P10", "P42"]
    bgs = ["WT", "ASD-PRS", "SCZ-PRS"]
    combo_labels = []
    d_asd_vals, d_scz_vals, d_ns_vals = [], [], []
    for st in stages:
        for bg in bgs:
            r = m16[(m16["mouse_stage"] == st) & (m16["background"] == bg)].iloc[0]
            combo_labels.append(f"{st} | {bg}")
            d_asd_vals.append(r["cohens_d_ASD_liability"])
            d_scz_vals.append(r["cohens_d_SCZ_liability"])
            d_ns_vals.append(abs(r["cohens_d_Ns_adult"]))

    ya = np.arange(len(combo_labels))[::-1]
    ax_a.barh(ya + 0.24, d_asd_vals, height=0.22, color=OI["blue"], edgecolor="black", lw=0.5, label="ASD liability ($d$)")
    ax_a.barh(ya, d_scz_vals, height=0.22, color=OI["vermilion"], edgecolor="black", lw=0.5, label="SCZ liability ($d$)")
    ax_a.barh(ya - 0.24, d_ns_vals, height=0.22, color=OI["green"], edgecolor="black", lw=0.5, label="$|N_s(30\\,\\mathrm{yr})|$ loss ($|d|$)")
    ax_a.axhline(5.5, color="gray", ls=":", lw=0.8)
    ax_a.axhline(2.5, color="gray", ls=":", lw=0.8)
    ax_a.set_yticks(ya)
    ax_a.set_yticklabels(combo_labels, fontsize=7.5)
    ax_a.set_xlabel("Standardized Effect Size vs. Control (Cohen's $d$, $\\Delta\\chi=+0.16$)")
    ax_a.set_xlim(0.0, 9.6)
    ax_a.grid(True, axis="x", linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("Conditional Murine Stage × Polygenic Background Trial", loc="left", pad=8)
    ax_a.legend(loc="lower right", fontsize=7.0)

    # --- Panel b: SSO Therapeutic Reversibility Windows & Dose-Response ---
    b_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[0, 1], width_ratios=[1.15, 0.85], wspace=0.30)
    ax_b1 = fig.add_subplot(b_gs[0, 0])
    add_panel_label(ax_b1, "b", x=-0.18, y=1.06)

    sso_d1 = sso[np.isclose(sso["d_SSO"], 1.0)].copy()
    prof_specs = [
        ("ASD_Severe_0.45_WT", "R_ASD", "ASD Severe ($\\chi=0.45$, WT)", OI["blue"], "-"),
        ("ASD_Severe_0.45_ASDPRS", "R_ASD", "ASD Severe ($\\chi=0.45$, ASD-PRS)", OI["sky"], "--"),
        ("SCZ_Subthreshold_0.38_SCZPRS", "R_SCZ", "SCZ Subthresh ($\\chi=0.38$, SCZ-PRS)", OI["vermilion"], "-"),
        ("Comorbid_0.42_DualPRS", "R_SCZ", "Comorbid ($\\chi=0.42$, Dual-PRS)", OI["purple"], "-."),
    ]
    for pname, rcol, lbl, col, ls in prof_specs:
        sub = sso_d1[sso_d1["profile"] == pname].sort_values("tau_rx_yr")
        ax_b1.plot(sub["tau_rx_yr"].values, sub[rcol].values, color=col, ls=ls, lw=2.0, marker="o", ms=3.2, label=lbl)

    ax_b1.axvspan(0.0, 2.5, color=OI["sky"], alpha=0.12)
    ax_b1.axvspan(12.0, 18.0, color=OI["orange"], alpha=0.12)
    ax_b1.axhline(0.50, color="gray", ls=":", lw=0.9)
    ax_b1.set_xlim(-0.5, 25.2)
    ax_b1.set_ylim(-0.03, 1.06)
    ax_b1.set_xlabel("SSO Intervention Age $\\tau_{rx}$ (years)")
    ax_b1.set_ylabel("Therapeutic Reversibility $\\mathcal{R}_{1.0}(\\tau_{rx})$")
    ax_b1.grid(True, linestyle=":", alpha=0.25)
    despine(ax_b1)
    ax_b1.set_title("SSO Intervention Timing Windows", loc="left", fontsize=8.8, pad=8)
    ax_b1.legend(loc="upper right", fontsize=6.3, frameon=True, facecolor="white", framealpha=0.92, edgecolor="none")

    ax_b2 = fig.add_subplot(b_gs[0, 1])
    dose_specs = [
        ("ASD_Severe_0.45_WT", 0.5, "R_ASD", "ASD ($0.5$ yr)", OI["blue"], "-o"),
        ("ASD_Severe_0.45_WT", 2.0, "R_ASD", "ASD ($2.0$ yr)", OI["sky"], "--s"),
        ("ASD_Severe_0.45_WT", 6.0, "R_ASD", "ASD ($6.0$ yr)", OI["gray"], ":^"),
        ("SCZ_Subthreshold_0.38_SCZPRS", 12.0, "R_SCZ", "SCZ ($12.0$ yr)", OI["vermilion"], "-D"),
        ("SCZ_Subthreshold_0.38_SCZPRS", 18.0, "R_SCZ", "SCZ ($18.0$ yr)", OI["orange"], "-.v"),
    ]
    for pname, tau_rx, rcol, lbl, col, fmt in dose_specs:
        sub = sso[(sso["profile"] == pname) & (np.isclose(sso["tau_rx_yr"], tau_rx))].sort_values("d_SSO")
        ax_b2.plot(sub["d_SSO"].values, sub[rcol].values, fmt, color=col, lw=1.7, ms=4.2, label=lbl)
    ax_b2.set_xlim(-0.04, 1.04)
    ax_b2.set_ylim(-0.03, 1.06)
    ax_b2.set_xlabel("Normalized SSO Dose $d_{SSO}$")
    ax_b2.set_ylabel("Reversibility $\\mathcal{R}_d$")
    ax_b2.grid(True, linestyle=":", alpha=0.25)
    despine(ax_b2)
    ax_b2.set_title("Dose-Response by Stage", loc="left", fontsize=8.8, pad=8)
    ax_b2.legend(loc="upper left", fontsize=6.4)

    # --- Panel c: Experimental Power & Required Sample Sizes n per Arm ---
    ax_c = fig.add_subplot(gs[1, :])
    add_panel_label(ax_c, "c", x=-0.07, y=1.06)

    # Compare +0.08 and +0.16 across stages & backgrounds for ASD, SCZ, and Ns power (80% & 90%)
    x_c = np.arange(len(combo_labels))
    w_c = 0.24
    # Cap n at 1e5 for log-axis readability with explicit >10^4 label
    n_asd_80 = np.minimum(m16["n_per_group_ASD_80pct"].values, 20000)
    n_scz_80 = m16["n_per_group_SCZ_80pct"].values
    n_ns_80 = m16["n_per_group_Ns_80pct"].values

    # Reorder identically to combo_labels
    m16_ord = pd.concat([m16[(m16["mouse_stage"] == st) & (m16["background"] == bg)] for st in stages for bg in bgs])
    n_asd_80 = np.minimum(m16_ord["n_per_group_ASD_80pct"].values, 15000)
    n_scz_80 = m16_ord["n_per_group_SCZ_80pct"].values
    n_ns_80 = m16_ord["n_per_group_Ns_80pct"].values
    n_asd_90 = np.minimum(m16_ord["n_per_group_ASD_90pct"].values, 15000)

    ax_c.bar(x_c - w_c, n_asd_80, width=w_c, color=OI["blue"], edgecolor="black", lw=0.6, label="ASD liability (80% power)")
    ax_c.bar(x_c, n_scz_80, width=w_c, color=OI["vermilion"], edgecolor="black", lw=0.6, label="SCZ liability (80% power)")
    ax_c.bar(x_c + w_c, n_ns_80, width=w_c, color=OI["green"], edgecolor="black", lw=0.6, label="Adult $N_s$ (80% power)")
    ax_c.axhline(10, color="gray", ls="--", lw=0.9, label="Practical wet-lab cohort ($n=10$/arm)")

    for i, (na, ns_c, nn) in enumerate(zip(m16_ord["n_per_group_ASD_80pct"].values, n_scz_80, n_ns_80)):
        lbl_a = ">10$^4$" if na > 10000 else f"{int(na)}"
        ax_c.text(i - w_c, min(na, 15000) * 1.15, lbl_a, ha="center", va="bottom", fontsize=6.7, fontweight="bold", color=OI["blue"])
        ax_c.text(i, ns_c * 1.15, f"{int(ns_c)}", ha="center", va="bottom", fontsize=6.7, fontweight="bold", color=OI["vermilion"])
        ax_c.text(i + w_c, nn * 1.15, f"{int(nn)}", ha="center", va="bottom", fontsize=6.7, fontweight="bold", color=OI["green"])

    ax_c.set_yscale("log")
    ax_c.set_ylim(1, 60000)
    ax_c.set_xticks(x_c)
    ax_c.set_xticklabels(combo_labels, fontsize=7.8)
    ax_c.set_ylabel("Required Mice per Arm ($n$, $\\alpha=0.05$, log scale)")
    ax_c.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c)
    ax_c.set_title("Required Experimental Group Sizes Across Induction Stage & Background ($\\Delta\\chi=+0.16$)", loc="left", pad=8)
    ax_c.legend(loc="upper left", fontsize=7.2, ncol=4)

    return save_figure(fig, "Figure_6")


# ---------------------------------------------------------------------------
# Figure S1: Scale-1 Biophysical Diagnostics, Bootstrap Posteriors & Phase Portraits
# ---------------------------------------------------------------------------
def plot_figure_s1() -> List[Path]:
    print("Generating Figure_S1...")
    cal = json.loads((RESULTS_DIR / "biophysical_calibration.json").read_text(encoding="utf-8"))
    boot = pd.read_csv(RESULTS_DIR / "biophysical_bootstrap_samples.csv")
    f4 = pd.read_csv(DATA_PROC / "gc25_fig4_tc_and_agg.csv")

    f4d = f4[f4["source_sheet"] == "Fig.4d"].copy()
    p_hill = cal["eq2_cooperative_hill_aggregation"]["pooled_all"]["parameters"]
    a_min = p_hill["A_min"]["point_estimate"]
    a_max = p_hill["A_max"]["point_estimate"]
    chi_c = p_hill["chi_c"]["point_estimate"]
    n_h = p_hill["n_H"]["point_estimate"]

    yhat = a_min + (a_max - a_min) * _hill_norm(f4d["chi_delta4"].values, chi_c, n_h)
    resid = f4d["value"].values - yhat

    fig = plt.figure(figsize=(15.0, 10.4))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.35, wspace=0.28)

    # --- Panel a1 & a2: Residuals vs Fitted & Normal Q-Q Plot ---
    a_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[0, 0], wspace=0.32)
    ax_a1 = fig.add_subplot(a_gs[0, 0])
    add_panel_label(ax_a1, "a", x=-0.20, y=1.06)

    for ch, mk, col, lbl in [("nCPEB4_DL488", "o", OI["blue"], "DL488"), ("nCPEB4d4_AF647", "s", OI["vermilion"], "AF647")]:
        m = (f4d["channel"] == ch).values
        ax_a1.scatter(yhat[m], resid[m], marker=mk, s=22, color=col, alpha=0.72, edgecolor="white", lw=0.4, label=lbl)
    ax_a1.axhline(0.0, color="black", ls="--", lw=1.0)
    rmse = cal["eq2_cooperative_hill_aggregation"]["pooled_all"]["fit_metrics"]["rmse"]
    ax_a1.axhline(2 * rmse, color="gray", ls=":", lw=0.8)
    ax_a1.axhline(-2 * rmse, color="gray", ls=":", lw=0.8)
    ax_a1.set_xlabel("Fitted $A_{eq}$ (%)")
    ax_a1.set_ylabel("Residual ($y - \\hat{y}$, %)")
    ax_a1.set_title(f"M4 Residuals (RMSE={rmse:.2f}%)", loc="left", fontsize=8.6, pad=8)
    ax_a1.grid(True, linestyle=":", alpha=0.25)
    despine(ax_a1)
    ax_a1.legend(loc="upper left", fontsize=6.6)

    ax_a2 = fig.add_subplot(a_gs[0, 1])
    (osm, osr), (slope, intercept, r_qq) = stats.probplot(resid, dist="norm")
    ax_a2.scatter(osm, osr, s=18, color=OI["blue"], alpha=0.72, edgecolor="white", lw=0.4)
    ax_a2.plot(osm, slope * osm + intercept, color=OI["vermilion"], lw=1.6, ls="--")
    ax_a2.text(0.05, 0.92, f"Q–Q $r = {r_qq:.3f}$", transform=ax_a2.transAxes, fontsize=7.4, fontweight="bold")
    ax_a2.set_xlabel("Theoretical Quantiles")
    ax_a2.set_ylabel("Ordered Residuals (%)")
    ax_a2.set_title("Normal Q–Q Plot ($n=140$)", loc="left", fontsize=8.6, pad=8)
    ax_a2.grid(True, linestyle=":", alpha=0.25)
    despine(ax_a2)

    # --- Panel b: Joint 5,000-Bootstrap Posterior Density of (chi_c, n_H) ---
    ax_b = fig.add_subplot(gs[0, 1])
    add_panel_label(ax_b, "b", x=-0.13, y=1.06)

    bp = boot[boot["dataset"] == "pooled_all"].copy()
    hb = ax_b.hexbin(bp["chi_c"].values, np.minimum(bp["n_H"].values, 60.0), gridsize=35, cmap="Blues", mincnt=1)
    ax_b.axvline(0.30, color=OI["green"], ls=":", lw=1.4, label="Control $\\chi=0.30$")
    ax_b.axvline(0.45, color=OI["vermilion"], ls=":", lw=1.4, label="ASD $\\chi=0.45$")
    ax_b.axvline(chi_c, color="black", ls="--", lw=1.2)
    ax_b.axhline(n_h, color="black", ls="--", lw=1.2)
    ax_b.scatter([chi_c], [n_h], marker="*", s=130, color=OI["vermilion"], edgecolor="black", zorder=6,
                 label=f"MLE ($\\chi_c={chi_c:.4f}$, $n_H={n_h:.2f}$)")
    ci_chi = p_hill["chi_c"]["ci95"]
    ci_nh = p_hill["n_H"]["ci95"]
    ax_b.text(
        0.55, 0.88,
        f"$B=5{{,}}000$ bootstrap:\n$\\chi_c={chi_c:.4f}$ [{ci_chi[0]:.4f}, {ci_chi[1]:.4f}]\n"
        f"$n_H={n_h:.2f}$ [{ci_nh[0]:.2f}, {ci_nh[1]:.2f}]",
        transform=ax_b.transAxes, va="top", ha="left", fontsize=7.2, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#AAAAAA", lw=0.7),
    )
    cbar_b = fig.colorbar(hb, ax=ax_b, fraction=0.042, pad=0.03)
    cbar_b.set_label("Bootstrap sample count", fontsize=7.5)
    ax_b.set_xlim(0.28, 0.47)
    ax_b.set_ylim(8.0, 58.0)
    ax_b.set_xlabel("Critical Threshold $\\chi_c$")
    ax_b.set_ylabel("Hill Cooperativity $n_H$")
    ax_b.grid(True, linestyle=":", alpha=0.25)
    despine(ax_b)
    ax_b.set_title("Joint Bootstrap Posterior ($\\chi_c, n_H$)", loc="left", pad=8)
    ax_b.legend(loc="lower left", fontsize=6.9)

    # --- Panel c: (L, S) Simplex Phase Portraits (Childhood vs Adolescent PFC) ---
    ode_p = cal["eq4_to_eq6_ode_parameters_and_provenance"]["parameters"]
    qss_bm = cal["eq4_to_eq6_analytical_and_numerical_verification"]["benchmark_qss_states"]
    c_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[1, :], wspace=0.24)

    def _solve_ls_portrait(chi_val: float, d_act: float, l0: float, s0: float) -> Tuple[np.ndarray, np.ndarray]:
        a_norm = float(_hill_norm(chi_val, ode_p["chi_c_ref_pH8"], ode_p["n_H"]))
        kf, kd, rr, kl, kc, ld = ode_p["k_form"], ode_p["k_diss"], ode_p["R_rev"], ode_p["k_lock"], ode_p["k_clr"], ode_p["lambda_D"]
        k_d_eff = kd * rr * d_act
        k_l_eff = kl * a_norm * (1.0 + ld * d_act)
        def rhs(_t: float, y: List[float]) -> List[float]:
            l_v, s_v = y
            return [kf * (1.0 - l_v - s_v) - (k_d_eff + k_l_eff) * l_v, k_l_eff * l_v - kc * s_v]
        sol = integrate.solve_ivp(rhs, (0.0, 60.0), [l0, s0], t_eval=np.linspace(0.0, 60.0, 300), method="Radau", rtol=1e-9, atol=1e-11)
        return sol.y[0], sol.y[1]

    inits = [(0.95, 0.02), (0.05, 0.05), (0.15, 0.80), (0.50, 0.45)]
    chi_cols = [(0.30, OI["green"], "W1/W2 $\\chi=0.30$"), (0.38, OI["orange"], "$\\chi=0.38$"), (0.45, OI["vermilion"], "$\\chi=0.45$")]

    for p_idx, (wkey, d_act_val, wtitle) in enumerate([
        ("W1_childhood", ode_p["D_act_W1_childhood"], f"Childhood ($D_{{act}}={ode_p['D_act_W1_childhood']:.2f}$)"),
        ("W2_adolescent_PFC", ode_p["D_act_W2_adolescent_PFC"], f"Adolescent PFC ($D_{{act}}={ode_p['D_act_W2_adolescent_PFC']:.2f}$)"),
    ]):
        ax_p = fig.add_subplot(c_gs[0, p_idx])
        if p_idx == 0:
            add_panel_label(ax_p, "c", x=-0.12, y=1.06)
        # Simplex boundary L+S <= 1
        ax_p.plot([0, 1], [1, 0], color="black", lw=1.3, ls="-")
        ax_p.fill_between([0, 1], [1, 0], [1.05, 1.05], color="#F2F2F2", alpha=0.8)
        for chi_v, col, lbl in chi_cols:
            for j, (l0, s0) in enumerate(inits):
                lv, sv = _solve_ls_portrait(chi_v, d_act_val, l0, s0)
                ax_p.plot(lv, sv, color=col, lw=1.2, alpha=0.75, label=lbl if j == 0 else None)
            q = qss_bm[f"chi_{chi_v:.2f}"][wkey]
            ax_p.scatter([q["L_star"]], [q["S_star"]], s=75, color=col, edgecolor="black", lw=1.0, zorder=6)
            tx = 0.62 if chi_v == 0.30 else min(q["L_star"] + 0.08, 0.80)
            ty = 0.14 if chi_v == 0.30 else min(q["S_star"] + 0.08, 0.82)
            ax_p.annotate(
                f"$\\chi={chi_v:.2f}$\n$\\Phi^*={q['Phi_star']:.2f}$",
                xy=(q["L_star"], q["S_star"]),
                xytext=(tx, ty),
                fontsize=6.8, fontweight="bold", color=col,
                arrowprops=dict(arrowstyle="->", color=col, lw=0.8),
                bbox=dict(boxstyle="round,pad=0.14", fc="white", ec="none", alpha=0.85),
            )
        ax_p.set_xlim(-0.02, 1.02)
        ax_p.set_ylim(-0.02, 1.02)
        ax_p.set_xlabel("Liquid Condensate Fraction $L$")
        ax_p.set_ylabel("Locked Solid Fraction $S$")
        ax_p.grid(True, linestyle=":", alpha=0.25)
        despine(ax_p)
        ax_p.set_title(f"$(L, S)$ Simplex Phase Portrait — {wtitle}", loc="left", pad=8)
        ax_p.legend(loc="upper right", fontsize=7.0)

    return save_figure(fig, "Figure_S1")


# ---------------------------------------------------------------------------
# Figure S3: Extended Global Sensitivity & Cohort r_G Sweep
# ---------------------------------------------------------------------------
def plot_figure_s3() -> List[Path]:
    print("Generating Figure_S3...")
    prcc = pd.read_csv(RESULTS_DIR / "sensitivity_prcc.csv")
    rg_df = pd.read_csv(RESULTS_DIR / "cohort_rg_sweep.csv")
    cv = pd.read_csv(RESULTS_DIR / "cohort_validation.csv")

    bundle = _get_ctl_and_cohort()
    cohort = bundle["cohort"]

    fig = plt.figure(figsize=(15.4, 10.6))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.38, wspace=0.28)

    # --- Panel a: Full 15-Parameter LHS-PRCC across chi_c_eff, Psi, Ns(30) ---
    ax_a = fig.add_subplot(gs[0, :])
    add_panel_label(ax_a, "a", x=-0.06, y=1.06)

    p_order = prcc[prcc["output_metric"] == "chi_c_eff_W2"].sort_values("abs_prcc", ascending=False)["parameter"].tolist()
    xa = np.arange(len(p_order))
    wa = 0.26
    for idx, (met, lbl, col) in enumerate([
        ("chi_c_eff_W2", "$\\chi_c^{eff}(W_2)$", OI["blue"]),
        ("Psi", "Phenotypic Bias $\\Psi$", OI["vermilion"]),
        ("Ns_30yr", "Adult Synaptic Density $N_s(30)$", OI["green"]),
    ]):
        sub = prcc[prcc["output_metric"] == met].set_index("parameter").loc[p_order]
        ax_a.bar(xa + (idx - 1) * wa, sub["prcc"].values, width=wa, color=col, edgecolor="black", lw=0.5, label=lbl)

    ax_a.axhline(0.0, color="black", lw=0.8)
    ax_a.set_xticks(xa)
    ax_a.set_xticklabels(p_order, rotation=28, ha="right", fontsize=7.8)
    ax_a.set_ylabel("Partial Rank Correlation (PRCC, $N=5{,}000$)")
    ax_a.set_ylim(-1.05, 1.08)
    ax_a.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_a)
    ax_a.set_title("Full Global LHS-PRCC Sensitivity Rankings Across 15 Model Parameters", loc="left", pad=8)
    ax_a.legend(loc="upper right", fontsize=7.5, ncol=3)

    # --- Panel b: Cohort r_G Sweep vs Zheng et al. (2018) Meta-Analytic CI ---
    ax_b = fig.add_subplot(gs[1, 0])
    add_panel_label(ax_b, "b", x=-0.14, y=1.06)

    ax_b.axhspan(2.08, 6.05, color=OI["sky"], alpha=0.18, label="Zheng et al. (2018) 95% CI [2.08–6.05]")
    ax_b.axhline(3.55, color=OI["blue"], ls="--", lw=1.4, label="Zheng et al. (2018) pooled OR = 3.55")
    ax_b.axhline(1.0, color="gray", ls=":", lw=0.9)

    ax_b.errorbar(
        rg_df["r_G"].values, rg_df["comorbid_OR"].values,
        yerr=[rg_df["comorbid_OR"].values - rg_df["comorbid_OR_ci95_low"].values,
              rg_df["comorbid_OR_ci95_high"].values - rg_df["comorbid_OR"].values],
        fmt="-o", color=OI["vermilion"], mfc=OI["vermilion"], mec="black", ms=6.2, lw=1.8, capsize=3.5,
        label="CTL cohort emergent OR (95% CI)", zorder=5,
    )
    # Highlight baseline Grove 2019 r_G = 0.211
    base_rg = rg_df[np.isclose(rg_df["r_G"], 0.211)].iloc[0]
    ax_b.scatter([0.211], [base_rg["comorbid_OR"]], s=130, facecolor="none", edgecolor="black", lw=1.8, zorder=6)
    ax_b.annotate(
        f"Grove '19 $r_G=0.211$\nOR={base_rg['comorbid_OR']:.2f} [{base_rg['comorbid_OR_ci95_low']:.2f}–{base_rg['comorbid_OR_ci95_high']:.2f}]",
        xy=(0.211, base_rg["comorbid_OR"]),
        xytext=(0.18, 2.35),
        fontsize=7.2, fontweight="bold",
        arrowprops=dict(arrowstyle="->", color="black", lw=0.9),
        bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="#AAAAAA", lw=0.7),
    )

    ax_b.set_xlim(0.07, 0.38)
    ax_b.set_ylim(0.8, 6.8)
    ax_b.set_xlabel("ASD–SCZ Genetic Correlation ($r_G$)")
    ax_b.set_ylabel("Emergent Comorbidity Odds Ratio")
    ax_b.grid(True, linestyle=":", alpha=0.25)
    despine(ax_b)
    ax_b.set_title("Comorbidity Robustness Across $r_G$ Sweep ($N=100{,}000$)", loc="left", pad=8)
    ax_b.legend(loc="upper left", fontsize=6.9)

    # --- Panel c: Diagnostic Regime Prevalence & Delta PSI_me4 Distributions ---
    c_gs = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[1, 1], width_ratios=[0.85, 1.15], wspace=0.30)
    ax_c1 = fig.add_subplot(c_gs[0, 0])
    add_panel_label(ax_c1, "c", x=-0.20, y=1.06)

    cv_idx = cv.set_index("group")
    reg_cols = [
        ("Resilient", OI["gray"]),
        ("ASD_only", OI["blue"]),
        ("SCZ_only", OI["vermilion"]),
        ("Comorbid", OI["purple"]),
    ]
    xc1 = np.arange(len(reg_cols))
    prevs = [float(cv_idx.loc[g, "prevalence_pct"]) for g, _ in reg_cols]
    ax_c1.bar(xc1, prevs, color=[c for _, c in reg_cols], edgecolor="black", lw=0.7, width=0.58)
    for i, pv in enumerate(prevs):
        ax_c1.text(i, pv * 1.18, f"{pv:.3g}%", ha="center", va="bottom", fontsize=7.0, fontweight="bold")
    ax_c1.set_yscale("log")
    ax_c1.set_ylim(0.01, 300.0)
    ax_c1.set_xticks(xc1)
    ax_c1.set_xticklabels(["Resil.", "ASD", "SCZ", "Comorb."], fontsize=7.5)
    ax_c1.set_ylabel("Cohort Prevalence (%, log scale)")
    ax_c1.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c1)
    ax_c1.set_title("Regime Prevalence", loc="left", fontsize=8.8, pad=8)

    ax_c2 = fig.add_subplot(c_gs[0, 1])
    # Plot Delta PSI_me4 (= -(chi - 0.30) * 100 in PSI units) across diagnostic strata
    dpsi_w1_data, dpsi_w2_data = [], []
    for g, _ in reg_cols:
        msk = cohort["masks"][g]
        dpsi_w1_data.append(-(cohort["arrays"]["chi_W1"][msk] - 0.30) * 100.0)
        dpsi_w2_data.append(-(cohort["arrays"]["chi_W2"][msk] - 0.30) * 100.0)

    pos = np.arange(len(reg_cols))
    bp1 = ax_c2.boxplot(dpsi_w1_data, positions=pos - 0.17, widths=0.28, patch_artist=True, showfliers=False,
                        medianprops=dict(color="black", lw=1.2))
    bp2 = ax_c2.boxplot(dpsi_w2_data, positions=pos + 0.17, widths=0.28, patch_artist=True, showfliers=False,
                        medianprops=dict(color="black", lw=1.2))
    for b in bp1["boxes"]:
        b.set_facecolor(OI["sky"])
    for b in bp2["boxes"]:
        b.set_facecolor(OI["orange"])
    ax_c2.axhline(0.0, color="gray", ls=":", lw=0.8)
    ax_c2.axhline(-8.8, color=OI["blue"], ls="--", lw=0.9, label="Parras '18 ASD <35y (−8.8%)")
    ax_c2.set_xticks(pos)
    ax_c2.set_xticklabels(["Resil.", "ASD", "SCZ", "Comorb."], fontsize=7.5)
    ax_c2.set_ylabel("$\\Delta\\mathrm{PSI}_{me4}$ vs. Ctrl (%)")
    ax_c2.set_ylim(-25.0, 10.0)
    ax_c2.grid(True, axis="y", linestyle=":", alpha=0.25)
    despine(ax_c2)
    ax_c2.set_title("Cortical $\\Delta\\mathrm{PSI}_{me4}$ by Regime", loc="left", fontsize=8.8, pad=8)
    h_bp = [
        mpatches.Patch(facecolor=OI["sky"], edgecolor="black", lw=0.6, label="Childhood $W_1$"),
        mpatches.Patch(facecolor=OI["orange"], edgecolor="black", lw=0.6, label="Adol. PFC $W_2$"),
        Line2D([0], [0], color=OI["blue"], ls="--", lw=0.9, label="Parras '18 ASD <35y (−8.8%)"),
    ]
    ax_c2.legend(handles=h_bp, loc="upper right", fontsize=6.4, frameon=True, facecolor="white", framealpha=0.9, edgecolor="none")

    return save_figure(fig, "Figure_S3")


DISPATCH = {
    "1": plot_figure_1,
    "2": plot_figure_2,
    "3": plot_figure_3,
    "4": plot_figure_4,
    "5": plot_figure_5,
    "6": plot_figure_6,
    "s1": plot_figure_s1,
    "s2": plot_figure_s2,
    "s3": plot_figure_s3,
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate publication-grade figures.")
    parser.add_argument(
        "--figs",
        nargs="+",
        default=["1", "2", "3", "s1"],
        help="Figure IDs to generate (e.g. 1 2 3 s1, or all).",
    )
    args = parser.parse_args()
    set_pub_style()

    targets = list(DISPATCH.keys()) if "all" in [x.lower() for x in args.figs] else [x.lower() for x in args.figs]
    generated: List[Path] = []
    for t in targets:
        if t not in DISPATCH:
            raise ValueError(f"Unknown figure key: {t}. Valid: {list(DISPATCH.keys())} or 'all'")
        generated.extend(DISPATCH[t]())

    print(f"\nCompleted {len(generated)} figure files in {FIG_DIR}.")


if __name__ == "__main__":
    main()
