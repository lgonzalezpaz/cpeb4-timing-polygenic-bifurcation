# -*- coding: utf-8 -*-
"""
08_build_manuscript_and_package.py
==================================
Assembles the final manuscript deliverables from `manuscript_content.py`
(text, tables, captions, references) and `omml_equations.py` (native Word
OMML equations), and packages the GitHub/Zenodo reproducibility bundle.

Outputs (manuscript/):
  Manuscript_Complete_with_Figures.docx, Manuscript_Text_Only.docx, Manuscript.md,
  Supplementary_Material.docx, Supplementary_Material.md, Title_Page.docx,
  Cover_Letter.docx, FILE_LIST_GitHub_Zenodo.txt
Root: README.md, LICENSE, CITATION.cff, environment.yml, requirements.txt, run_all.py
Archive: ../cpeb4-timing-polygenic-bifurcation-v1.0.0.zip

Usage:
  python src/08_build_manuscript_and_package.py [--no-zip]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

WORKSPACE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE / "src"))

from manuscript_content import build_manuscript_bundle  # noqa: E402
from omml_equations import add_equation_paragraph  # noqa: E402
from richtext import parse, plain, to_markdown  # noqa: E402

MS_DIR = WORKSPACE / "manuscript"
FIG_DIR = WORKSPACE / "figures"
RESULTS_DIR = WORKSPACE / "results"
VERSION = "v1.0.0"
REPO_NAME = "cpeb4-timing-polygenic-bifurcation"
ZIP_PATH = WORKSPACE.parent / f"{REPO_NAME}-{VERSION}.zip"
FONT = "Times New Roman"
BLACK = RGBColor(0, 0, 0)
FIG_WIDTH_CM = 15.9

# ---------------------------------------------------------------------------
# LaTeX forms of all equations (identical structure to omml_equations.py)
# ---------------------------------------------------------------------------
LATEX_EQ: dict[str, str] = {
    "1": r"\begin{aligned} f_{\mathrm{H}^{+}}(\mathrm{pH}) &= \left[1+10^{\,\mathrm{pH}-\mathrm{p}K_a}\right]^{-1},\\ u(\chi_{\Delta4},\mathrm{pH}) &= \chi_{\Delta4}\left[1-f_{\mathrm{H}^{+}}(\mathrm{pH})\right] \end{aligned}",
    "2": r"\begin{aligned} A_{\mathrm{eq}}(\chi_{\Delta4},\mathrm{pH}) &= A_{\min}+\frac{A_{\max}-A_{\min}}{1+\left(\dfrac{\chi_c(\mathrm{pH})}{\chi_{\Delta4}}\right)^{n_H}},\\ \chi_c(\mathrm{pH}) &= \chi_c(\mathrm{pH}_{\mathrm{ref}})\,\frac{1-f_{\mathrm{H}^{+}}(\mathrm{pH}_{\mathrm{ref}})}{1-f_{\mathrm{H}^{+}}(\mathrm{pH})} \end{aligned}",
    "3": r"T_c(\chi_{\Delta4}) = T_{c,0}+\gamma_T\,\chi_{\Delta4}",
    "4": r"\frac{\mathrm{d}L}{\mathrm{d}t} = k_{\mathrm{form}}(1-L-S)-k_{\mathrm{diss}}D_{\mathrm{act}}(t)R_{\mathrm{rev}}L-k_{\mathrm{lock}}\tilde{A}_{\mathrm{eq}}(\chi_{\Delta4},\mathrm{pH})\left[1+\lambda_D D_{\mathrm{act}}(t)\right]L",
    "5": r"\frac{\mathrm{d}S}{\mathrm{d}t} = k_{\mathrm{lock}}\tilde{A}_{\mathrm{eq}}(\chi_{\Delta4},\mathrm{pH})\left[1+\lambda_D D_{\mathrm{act}}(t)\right]L-k_{\mathrm{clr}}S",
    "6": r"\Phi(t) = 1-\eta_S S(t)-\eta_L L(t),\qquad 0\le\eta_L<\eta_S\le 1",
    "7": r"\frac{\mathrm{d}N_s}{\mathrm{d}t} = \alpha_{\mathrm{syn}}(t)\max\!\left\{0,\,1-\kappa_1\left[1-\Phi(t)\right]g_{\mathrm{ASD}}(P_{\mathrm{ASD}})\right\}-\Big[\delta_0+\beta_{\mathrm{prun}}(t)\left(1+\kappa_2\left[1-\Phi(t)\right]g_{\mathrm{SCZ}}(P_{\mathrm{SCZ}})\right)\Big]N_s(t)",
    "8": r"(P_{\mathrm{ASD}},P_{\mathrm{SCZ}})^{\top}\sim\mathcal{N}(\mathbf{0},\Sigma),\qquad \Sigma=\begin{pmatrix}1 & r_G\\ r_G & 1\end{pmatrix}",
    "9": r"g_d(P_d) = \exp\!\left[\gamma_d\,c_P\tanh\!\left(\frac{P_d}{c_P}\right)\right],\qquad d\in\{\mathrm{ASD},\mathrm{SCZ}\}",
    "10": r"\mathcal{L}_{\mathrm{ASD}}(t) = \int_{t_0}^{t}V_{\mathrm{ASD}}(s)\Big[w_{P,1}P_{\mathrm{ASD}}+\varepsilon_{\mathrm{ASD}}+w_{\Phi,1}\Big(\left[1-\Phi(s)\right]g_{\mathrm{ASD}}(P_{\mathrm{ASD}})-\left[1-\Phi_{\mathrm{ctrl}}(s)\right]\Big)+w_{N,1}\left[N_s^{\mathrm{ctrl}}(s)-N_s(s)\right]_{+}\Big]\,\mathrm{d}s",
    "11": r"\mathcal{L}_{\mathrm{SCZ}}(t) = \int_{t_0}^{t}V_{\mathrm{SCZ}}(s)\Big[w_{P,2}P_{\mathrm{SCZ}}+\varepsilon_{\mathrm{SCZ}}+w_{\Phi,2}\Big(\left[1-\Phi(s)\right]g_{\mathrm{SCZ}}(P_{\mathrm{SCZ}})-\left[1-\Phi_{\mathrm{ctrl}}(s)\right]\Big)+w_{N,2}\left[N_s^{\mathrm{ctrl}}(s)-N_s(s)\right]_{+}\Big]\,\mathrm{d}s",
    "12": r"\tilde{\mathcal{L}}_d = \frac{\max\{0,\mathcal{L}_d(T_{\max})\}}{\theta_d},\qquad \mathcal{C}=\begin{cases}\text{Comorbid}, & \tilde{\mathcal{L}}_{\mathrm{ASD}}\ge 1\wedge\tilde{\mathcal{L}}_{\mathrm{SCZ}}\ge 1\\ \text{ASD-only}, & \tilde{\mathcal{L}}_{\mathrm{ASD}}\ge 1>\tilde{\mathcal{L}}_{\mathrm{SCZ}}\\ \text{SCZ-only}, & \tilde{\mathcal{L}}_{\mathrm{SCZ}}\ge 1>\tilde{\mathcal{L}}_{\mathrm{ASD}}\\ \text{Resilient}, & \text{otherwise}\end{cases}",
    "13": r"\Psi = \frac{\tilde{\mathcal{L}}_{\mathrm{SCZ}}-\tilde{\mathcal{L}}_{\mathrm{ASD}}}{\tilde{\mathcal{L}}_{\mathrm{SCZ}}+\tilde{\mathcal{L}}_{\mathrm{ASD}}}\in[-1,+1]",
    "14": r"\chi_{\Delta4}(t;\tau_{\mathrm{on}},\Delta\chi) = \chi_{\mathrm{ctrl}}+\Delta\chi\,\sigma\!\left(\frac{t-\tau_{\mathrm{on}}}{\epsilon}\right)",
    "15": r"\begin{aligned} \chi_{\Delta4}^{\mathrm{SSO}}(t;\tau_{\mathrm{rx}},d_{\mathrm{SSO}}) &= \chi_{\mathrm{ctrl}}+\left[\chi_{\mathrm{path}}(t)-\chi_{\mathrm{ctrl}}\right]\left[1-f_{\mathrm{SSO}}(d_{\mathrm{SSO}})\,\sigma\!\left(\frac{t-\tau_{\mathrm{rx}}}{\epsilon}\right)\right],\\ f_{\mathrm{SSO}}(d_{\mathrm{SSO}}) &= \frac{(1+K_{\mathrm{SSO}})\,d_{\mathrm{SSO}}}{d_{\mathrm{SSO}}+K_{\mathrm{SSO}}} \end{aligned}",
    "16": r"\mathcal{R}_d(\tau_{\mathrm{rx}},d_{\mathrm{SSO}}) = 1-\frac{\mathcal{L}_d^{\mathrm{SSO}}(\tau_{\mathrm{rx}},d_{\mathrm{SSO}})-\mathcal{L}_d^{\mathrm{ctrl}}}{\mathcal{L}_d^{\mathrm{untreated}}-\mathcal{L}_d^{\mathrm{ctrl}}}\in[0,1]",
    "S1": r"\begin{aligned} L^{*} &= \frac{1}{B+\beta C\tilde{A}_{\mathrm{eq}}},\quad S^{*}=\frac{C\tilde{A}_{\mathrm{eq}}}{B+\beta C\tilde{A}_{\mathrm{eq}}},\quad \Phi^{*}=1-\frac{\eta_L+\eta_S C\tilde{A}_{\mathrm{eq}}}{B+\beta C\tilde{A}_{\mathrm{eq}}},\\ B &= 1+\frac{k_{\mathrm{diss}}R_{\mathrm{rev}}D_{\mathrm{act}}}{k_{\mathrm{form}}},\quad C=\frac{k_{\mathrm{lock}}\left(1+\lambda_D D_{\mathrm{act}}\right)}{k_{\mathrm{clr}}},\quad \beta=1+\frac{k_{\mathrm{clr}}}{k_{\mathrm{form}}} \end{aligned}",
    "S2": r"\begin{aligned} \chi_{1/2}^{\mathrm{lock}}(D_{\mathrm{act}}) &= \chi_c(\mathrm{pH})\left[\frac{B}{B+\beta C}\right]^{1/n_H},\quad \chi_c^{\mathrm{eff}}(D_{\mathrm{act}})=\chi_c(\mathrm{pH})\left[\frac{A_{\mathrm{crit}}}{1-A_{\mathrm{crit}}}\right]^{1/n_H},\\ A_{\mathrm{crit}}(D_{\mathrm{act}}) &= \frac{B\left(1-\Phi_{\mathrm{crit}}\right)-\eta_L}{C\left[\eta_S-\beta\left(1-\Phi_{\mathrm{crit}}\right)\right]} \end{aligned}",
    "S3": r"\begin{aligned} \alpha_{\mathrm{syn}}(t) &= \alpha_{\mathrm{base}}+a_{\mathrm{peri}}\,e^{-\frac{(t-t_{\mathrm{peri}})^2}{2s_{\mathrm{peri}}^2}}\,\sigma\!\left(\frac{t+0.34}{0.05}\right)+a_{\mathrm{inf}}\,e^{-\frac{(t-t_{\mathrm{inf}})^2}{2s_{\mathrm{inf}}^2}}\,\sigma\!\left(\frac{t-0.10}{0.25}\right),\\ \beta_{\mathrm{prun}}(t) &= b_{\mathrm{prun}}\,D_{\mathrm{act}}(t)\,\sigma\!\left(\frac{t-t_{\mathrm{prun,on}}}{1.0}\right)e^{-\frac{(t-t_{\mathrm{prun,pk}})^2}{2s_{\mathrm{prun}}^2}} \end{aligned}",
    "S4": r"\begin{aligned} \chi_{\Delta4,i}(t) &= \operatorname{clip}\!\left(\chi_{\mathrm{ctrl}}+\delta_{\mathrm{const},i}+\delta_{W_1,i}\,\sigma\!\left(\frac{6.5-t}{1.0}\right)+\delta_{W_2,i}\,\sigma\!\left(\frac{t-10.0}{1.5}\right),\,0.05,\,0.95\right),\\ \delta_{\mathrm{const},i} &\sim\mathcal{N}(0,\sigma_\chi^2),\quad \delta_{W_1,i}=I_{W_1,i}U_{W_1,i},\quad \delta_{W_2,i}=I_{W_2,i}U_{W_2,i} \end{aligned}",
}


# ---------------------------------------------------------------------------
# DOCX helpers
# ---------------------------------------------------------------------------
def _set_run_font(run, size: float = 12, bold: bool | None = None, italic: bool | None = None) -> None:
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.color.rgb = BLACK
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for att in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(att), FONT)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def add_rich(paragraph, text: str, size: float = 12, base_bold: bool = False, base_italic: bool = False) -> None:
    for r in parse(text):
        run = paragraph.add_run(r.text)
        _set_run_font(run, size=size, bold=(r.style.bold or base_bold), italic=(r.style.italic != base_italic))
        if r.style.sup:
            run.font.superscript = True
        elif r.style.sub:
            run.font.subscript = True


def _fmt_para(p, spacing: float = 2.0, after: float = 12, before: float = 0, align=WD_ALIGN_PARAGRAPH.LEFT, keep_next: bool = False) -> None:
    pf = p.paragraph_format
    pf.line_spacing = spacing
    pf.space_after = Pt(after)
    pf.space_before = Pt(before)
    pf.first_line_indent = Cm(0)
    pf.alignment = align
    if keep_next:
        pf.keep_with_next = True


def para(doc, text: str, size: float = 12, spacing: float = 2.0, after: float = 12, before: float = 0,
         align=WD_ALIGN_PARAGRAPH.LEFT, bold: bool = False, italic: bool = False, keep_next: bool = False):
    p = doc.add_paragraph()
    _fmt_para(p, spacing, after, before, align, keep_next)
    add_rich(p, text, size=size, base_bold=bold, base_italic=italic)
    return p


def heading(doc, text: str, level: int):
    p = doc.add_heading(level=level)
    size = 14 if level == 1 else 12
    _fmt_para(p, spacing=2.0, after=6, before=12 if level == 1 else 6, keep_next=True)
    add_rich(p, text, size=size, base_bold=True)
    return p


def _style_defaults(doc) -> None:
    for name in ("Normal", "Heading 1", "Heading 2", "Heading 3", "Title"):
        try:
            st = doc.styles[name]
        except KeyError:
            continue
        st.font.name = FONT
        st.font.color.rgb = BLACK
        st.font.size = Pt(12)
        rpr = st.element.get_or_add_rPr()
        rfonts = rpr.find(qn("w:rFonts"))
        if rfonts is None:
            rfonts = OxmlElement("w:rFonts")
            rpr.insert(0, rfonts)
        for att in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rfonts.set(qn(att), FONT)
        for att in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
            if rfonts.get(qn(att)) is not None:
                del rfonts.attrib[qn(att)]
        color = rpr.find(qn("w:color"))
        if color is not None:
            for att in ("w:themeColor", "w:themeShade", "w:themeTint"):
                if color.get(qn(att)) is not None:
                    del color.attrib[qn(att)]
            color.set(qn("w:val"), "000000")


def _add_page_field(section) -> None:
    header = section.header
    p = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run()
    _set_run_font(run, 12)
    for kind, txt in (("begin", None), (None, " PAGE "), ("separate", None), (None, "1"), ("end", None)):
        if kind:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), kind)
            run._r.append(el)
        elif txt == " PAGE ":
            it = OxmlElement("w:instrText")
            it.set(qn("xml:space"), "preserve")
            it.text = txt
            run._r.append(it)
        else:
            t = OxmlElement("w:t")
            t.text = txt
            run._r.append(t)


def _add_line_numbers(section) -> None:
    sect_pr = section._sectPr
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:start"), "1")
    ln.set(qn("w:distance"), "360")
    ln.set(qn("w:restart"), "continuous")
    # schema order: lnNumType must precede pgNumType/cols/docGrid
    anchor = None
    for tag in ("w:pgNumType", "w:cols", "w:formProt", "w:vAlign", "w:noEndnote", "w:titlePg", "w:textDirection", "w:bidi", "w:rtlGutter", "w:docGrid"):
        anchor = sect_pr.find(qn(tag))
        if anchor is not None:
            break
    if anchor is not None:
        anchor.addprevious(ln)
    else:
        sect_pr.append(ln)


def new_document(line_numbers: bool = True, page_numbers: bool = True):
    doc = Document()
    _style_defaults(doc)
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Cm(2.54))
    if page_numbers:
        _add_page_field(sec)
    if line_numbers:
        _add_line_numbers(sec)
    return doc


def _set_cell_borders(cell, top=None, bottom=None) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, sz in (("top", top), ("bottom", bottom)):
        el = OxmlElement(f"w:{edge}")
        if sz:
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), str(sz))
            el.set(qn("w:color"), "000000")
        else:
            el.set(qn("w:val"), "nil")
        borders.append(el)
    for edge in ("left", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "nil")
        borders.append(el)
    tc_pr.append(borders)


def add_table(doc, tbl: dict[str, Any], label_prefix: str = "Table") -> None:
    num = tbl["number"]
    para(doc, f"**{label_prefix} {num}.** {tbl['title']}", spacing=1.15, after=4, before=6, keep_next=True)
    headers, rows = tbl["headers"], tbl["rows"]
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = True
    size = 9
    for ci, h in enumerate(headers):
        cell = t.rows[0].cells[ci]
        p = cell.paragraphs[0]
        _fmt_para(p, spacing=1.0, after=0)
        add_rich(p, h, size=size, base_bold=True)
        _set_cell_borders(cell, top=12, bottom=6)
    tr_pr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    tr_pr.append(th)
    for ri, row in enumerate(rows, start=1):
        last = ri == len(rows)
        tr_pr = t.rows[ri]._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit")
        cs.set(qn("w:val"), "true")
        tr_pr.append(cs)
        for ci, val in enumerate(row):
            cell = t.rows[ri].cells[ci]
            p = cell.paragraphs[0]
            _fmt_para(p, spacing=1.0, after=0)
            add_rich(p, str(val), size=size)
            _set_cell_borders(cell, top=None, bottom=12 if last else None)
    if tbl.get("footnote"):
        para(doc, tbl["footnote"], size=9, spacing=1.0, after=12, before=2)
    else:
        spacer = doc.add_paragraph()
        _fmt_para(spacer, spacing=1.0, after=6)


def add_figure(doc, fig: dict[str, Any], embed: bool) -> None:
    if embed:
        p = doc.add_paragraph()
        _fmt_para(p, spacing=1.0, after=4, align=WD_ALIGN_PARAGRAPH.CENTER, keep_next=True)
        p.add_run().add_picture(str(FIG_DIR / fig["file"]), width=Cm(FIG_WIDTH_CM))
    para(doc, fig["caption"], spacing=2.0, after=12)


def render_blocks(doc, blocks, tables: dict, figures: dict, embed: bool, label_prefix: str = "Table") -> None:
    for btype, val in blocks:
        if btype == "p":
            para(doc, val)
        elif btype == "eq":
            p = add_equation_paragraph(doc, f"({val})", str(val))
            _fmt_para(p, spacing=1.5, after=12, before=6)
        elif btype == "callout":
            para(doc, val, after=12, keep_next=True)
        elif btype == "table":
            add_table(doc, tables[val], label_prefix)
        elif btype == "figure":
            add_figure(doc, figures[val], embed)
        else:
            raise ValueError(f"Unknown block type {btype}")


# ---------------------------------------------------------------------------
# Markdown helpers
# ---------------------------------------------------------------------------
def md_table(tbl: dict[str, Any], label_prefix: str = "Table") -> str:
    out = [f"**{label_prefix} {tbl['number']}.** {to_markdown(tbl['title'])}", ""]
    esc = lambda s: to_markdown(str(s)).replace("|", "\\|")  # noqa: E731
    out.append("| " + " | ".join(esc(h) for h in tbl["headers"]) + " |")
    out.append("|" + "|".join([" --- "] * len(tbl["headers"])) + "|")
    for row in tbl["rows"]:
        out.append("| " + " | ".join(esc(c) for c in row) + " |")
    if tbl.get("footnote"):
        out += ["", to_markdown(tbl["footnote"])]
    return "\n".join(out) + "\n"


def md_blocks(blocks, tables: dict, figures: dict, label_prefix: str = "Table", fig_rel: str = "../figures") -> list[str]:
    out: list[str] = []
    for btype, val in blocks:
        if btype == "p":
            out.append(to_markdown(val) + "\n")
        elif btype == "eq":
            out.append(f"$$\n{LATEX_EQ[str(val)]} \\tag{{{val}}}\n$$\n")
        elif btype == "callout":
            out.append(f"*{val}*\n")
        elif btype == "table":
            out.append(md_table(tables[val], label_prefix))
        elif btype == "figure":
            fig = figures[val]
            out.append(f"![Figure {fig['number']}]({fig_rel}/{fig['file']})\n")
            out.append(to_markdown(fig["caption"]) + "\n")
    return out


# ---------------------------------------------------------------------------
# Main manuscript
# ---------------------------------------------------------------------------
def build_main_docx(b: dict[str, Any], embed: bool, path: Path) -> None:
    doc = new_document()
    para(doc, b["title"], size=16, bold=True, spacing=1.5, after=12)
    para(doc, b["authors_line"], size=12, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.5, after=6)
    for a in b["affiliations"]:
        para(doc, a, size=10, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.15, after=4)
    para(doc, b["correspondence"], size=10, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.15, after=12)

    heading(doc, "Abstract", 1)
    para(doc, b["abstract"], size=11)
    para(doc, f"**Keywords:** {b['keywords']}", size=10)

    heading(doc, "Introduction", 1)
    for p in b["introduction"]:
        para(doc, p)

    heading(doc, "Methods", 1)
    for sec in b["methods"]:
        heading(doc, sec["heading"], 2)
        render_blocks(doc, sec["blocks"], b["tables"], b["figures"], embed)

    heading(doc, "Results", 1)
    for sec in b["results"]:
        heading(doc, sec["heading"], 2)
        render_blocks(doc, sec["blocks"], b["tables"], b["figures"], embed)

    heading(doc, "Discussion", 1)
    for p in b["discussion"]:
        para(doc, p)

    heading(doc, "Conclusions", 1)
    para(doc, b["conclusions"])

    for bm in b["back_matter"]:
        heading(doc, bm["heading"], 1)
        para(doc, bm["text"])

    heading(doc, "References", 1)
    for r in b["references"]:
        para(doc, f"{r['num']}. {r['vancouver']}", size=10, spacing=1.15, after=4)
    doc.save(str(path))


def build_main_md(b: dict[str, Any], path: Path) -> None:
    L: list[str] = [f"# {b['title']}\n", to_markdown(b["authors_line"]) + "\n"]
    L += [to_markdown(a) + "\n" for a in b["affiliations"]]
    L.append(to_markdown(b["correspondence"]) + "\n")
    L += ["## Abstract\n", to_markdown(b["abstract"]) + "\n", f"**Keywords:** {to_markdown(b['keywords'])}\n"]
    L.append("## Introduction\n")
    L += [to_markdown(p) + "\n" for p in b["introduction"]]
    L.append("## Methods\n")
    for sec in b["methods"]:
        L.append(f"### {to_markdown(sec['heading'])}\n")
        L += md_blocks(sec["blocks"], b["tables"], b["figures"])
    L.append("## Results\n")
    for sec in b["results"]:
        L.append(f"### {to_markdown(sec['heading'])}\n")
        L += md_blocks(sec["blocks"], b["tables"], b["figures"])
    L.append("## Discussion\n")
    L += [to_markdown(p) + "\n" for p in b["discussion"]]
    L += ["## Conclusions\n", to_markdown(b["conclusions"]) + "\n"]
    for bm in b["back_matter"]:
        L += [f"## {bm['heading']}\n", to_markdown(bm["text"]) + "\n"]
    L.append("## References\n")
    L += [f"{r['num']}. {r['vancouver']}" for r in b["references"]]
    path.write_text("\n".join(L) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Supplementary material
# ---------------------------------------------------------------------------
SUPP_TITLE_PREFIX = "Supplementary Material for: "


def build_supp_docx(b: dict[str, Any], path: Path) -> None:
    doc = new_document()
    para(doc, SUPP_TITLE_PREFIX + b["title"], size=16, bold=True, spacing=1.5, after=12)
    para(doc, b["authors_line"], align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.5, after=6)
    para(doc, "This file contains Supplementary Notes 1–3, Supplementary Equations (S1)–(S4), "
              "Supplementary Tables S1–S3, and Supplementary Figures S1–S3.", after=12)
    for sec in b["supp_sections"]:
        heading(doc, sec["heading"], 1)
        render_blocks(doc, sec["blocks"], b["supp_tables"], b["supp_figures"], embed=True, label_prefix="Table")
    doc.save(str(path))


def build_supp_md(b: dict[str, Any], path: Path) -> None:
    L = [f"# {SUPP_TITLE_PREFIX}{b['title']}\n", to_markdown(b["authors_line"]) + "\n",
         "This file contains Supplementary Notes 1–3, Supplementary Equations (S1)–(S4), "
         "Supplementary Tables S1–S3, and Supplementary Figures S1–S3.\n"]
    for sec in b["supp_sections"]:
        L.append(f"## {to_markdown(sec['heading'])}\n")
        L += md_blocks(sec["blocks"], b["supp_tables"], b["supp_figures"])
    path.write_text("\n".join(L) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Title page and cover letter
# ---------------------------------------------------------------------------
def _wc(s: str) -> int:
    return len(re.findall(r"[A-Za-z0-9α-ωΑ-Ω][\w\-–.′/%α-ωΑ-Ω]*", plain(s)))


def main_text_word_count(b: dict[str, Any]) -> int:
    n = sum(_wc(p) for p in b["introduction"]) + sum(_wc(p) for p in b["discussion"]) + _wc(b["conclusions"])
    for sec in b["methods"] + b["results"]:
        n += _wc(sec["heading"]) + sum(_wc(v) for t, v in sec["blocks"] if t == "p")
    return n


def build_title_page(b: dict[str, Any], path: Path) -> None:
    doc = new_document(line_numbers=False)
    para(doc, b["title"], size=16, bold=True, spacing=1.5, after=12)
    para(doc, "**Running title:** CPEB4 microexon timing bifurcates autism and schizophrenia", after=12)
    para(doc, b["authors_line"], align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.5, after=6)
    for a in b["affiliations"]:
        para(doc, a, size=10, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.15, after=4)
    para(doc, b["correspondence"], size=10, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.15, after=18)
    stats = [
        f"Abstract: {b['abstract_word_count']} words",
        f"Main text (Introduction to Conclusions, excluding equations, tables, captions and references): {main_text_word_count(b)} words",
        f"Conclusions: {b['conclusions_word_count']} words",
        f"Display items: {len(b['figures'])} figures, {len(b['tables'])} tables, 16 numbered equations",
        f"Supplementary items: {len(b['supp_figures'])} figures, {len(b['supp_tables'])} tables, 4 equations (S1–S4)",
        f"References: {len(b['references'])}",
        f"Keywords: {b['keywords']}",
    ]
    heading(doc, "Manuscript statistics", 1)
    for s in stats:
        para(doc, s, spacing=1.5, after=4)
    heading(doc, "Declarations", 1)
    para(doc, "Ethics, funding, competing-interest, data-availability and generative-AI declarations are provided "
              "in the back matter of the main manuscript file.", spacing=1.5)
    doc.save(str(path))


def build_cover_letter(b: dict[str, Any], path: Path) -> None:
    mm = json.loads((RESULTS_DIR / "master_metrics.json").read_text(encoding="utf-8"))
    bc = json.loads((RESULTS_DIR / "biophysical_calibration.json").read_text(encoding="utf-8"))
    coh = mm["step3b_scale2_3_multiscale_ctl"]["birth_cohort_validation_N100k"]["base_rG_0.211"]
    hill = bc["eq2_cooperative_hill_aggregation"]["pooled_all"]["parameters"]
    chi_c, n_h = hill["chi_c"]["point_estimate"], hill["n_H"]["point_estimate"]
    doc = new_document(line_numbers=False)
    paras = [
        "[Date]",
        "The Editors",
        "[Journal name]",
        "Dear Editors,",
        f"We are pleased to submit our Research Article entitled “{b['title']}” for consideration.",
        "Reduced inclusion of microexon 4 in the translational regulator *CPEB4* is shared by idiopathic autism "
        "spectrum disorder (ASD) and schizophrenia (SCZ), yet it has remained unexplained how one post-transcriptional "
        "lesion can give rise to two clinically and temporally distinct disorders. Our study addresses this gap by "
        "combining a quantitative reanalysis of published phase-separation source data with human developmental "
        "transcriptomes, postmortem cortical datasets, public genetic-risk resources and a four-scale "
        "Condensate–Timing–Liability dynamical model.",
        f"Three findings stand out. First, *CPEB4* aggregation follows a steep cooperative switch (critical Δ4 "
        f"mole fraction {chi_c:.4f}; Hill exponent {n_h:.2f}) whose effective threshold is lowered by adolescent "
        f"prefrontal activity demand. Second, in human prefrontal cortex, CPEB4 targets that carry *de novo* ASD risk "
        f"show earlier developmental expression than targets carrying SCZ risk. Third, the integrated model, calibrated "
        f"only to disorder prevalences, reproduces out-of-calibration ASD–SCZ comorbidity (odds ratio "
        f"{coh['comorbid_or']:.2f}, 95% CI {coh['comorbid_or_ci95_low']:.2f}–{coh['comorbid_or_ci95_high']:.2f}) and "
        f"separated onset ages (median {coh['onset_asd_median']:.2f} versus {coh['onset_scz_median']:.2f} years) in "
        f"100,000 simulated births, and it outperforms timing-blind and additive alternatives by Akaike criterion.",
        "The work yields falsifiable predictions, including stage-specific outcomes of conditional *Cpeb4*Δ4 induction "
        "in mice with adequately powered cohort sizes and an age-dependent window for splice-switching oligonucleotide "
        "rescue. We clearly distinguish empirical observations from model-based inference and report null results, "
        "including the absence of temporal segregation for broad SFARI gene lists.",
        "All data are from public repositories, and all code, processed data, tests and figure scripts are provided "
        "for GitHub and Zenodo deposition to ensure full reproducibility. This manuscript has not been published and "
        "is not under consideration elsewhere. All authors have approved the submission and declare no competing interests.",
        "Thank you for your consideration.",
        "Sincerely,",
        "[Corresponding author name], on behalf of all authors",
    ]
    for p in paras:
        para(doc, p, spacing=1.15, after=10)
    doc.save(str(path))


# ---------------------------------------------------------------------------
# Repository files
# ---------------------------------------------------------------------------
README = """# Developmental timing and polygenic background bifurcate CPEB4 microexon 4 mis-splicing between autism and schizophrenia

Code, processed data, results and manuscript files for the study of how neurodevelopmental timing
(early synaptogenesis versus adolescent synaptic pruning) and baseline polygenic risk determine whether
*CPEB4* microexon 4 (me4) mis-splicing leads to autism spectrum disorder (ASD) or schizophrenia (SCZ).

## Overview

The Condensate–Timing–Liability (CTL) framework has four scales:

1. **Scale 1** – heterotypic-buffering biophysics and condensate-locking kinetics, calibrated to published
   CPEB4 phase-separation source data (Eqs. 1–6).
2. **Scale 2** – human prefrontal synaptic density driven by synaptogenesis and activity-coupled pruning (Eq. 7).
3. **Scale 3** – correlated ASD/SCZ polygenic liabilities and developmental vulnerability kernels (Eqs. 8–13).
4. **Scale 4** – conditional induction and splice-switching oligonucleotide (SSO) rescue protocols (Eqs. 14–16).

Empirical validation uses UniProt, Garcia-Cabau et al. (2025) source data, Parras et al. (2018) CPEB4 targets,
BrainSpan, PsychENCODE, Gandal et al. (2018), SFARI Gene, Fu et al. (2022), SCHEMA, Open Targets, SynGO and
Ensembl BioMart.

## Repository layout

```
src/        analysis pipeline (01–08), manuscript content, OMML equations, inline-markup parser
tests/      data-integrity, mathematical-reproducibility and manuscript audits
data/raw/   download provenance (SHA-256); large raw files are re-downloaded by src/01
data/processed/  harmonized inputs used by all analyses
results/    numerical outputs (JSON/CSV)
figures/    600-dpi PNG plus vector PDF/SVG figures
manuscript/ DOCX/Markdown manuscript, supplementary material, title page, cover letter, file list
```

## Reproduction

```bash
conda env create -f environment.yml      # or: pip install -r requirements.txt
conda activate cpeb4-ctl
python run_all.py                        # full pipeline (downloads raw data, ~network required)
python run_all.py --skip-fetch           # reuse data/processed, re-run analyses, figures and manuscript
python run_all.py --verify-only          # run the test suites only
```

All stochastic steps use fixed seeds (`SEED = 42` for bioinformatics; `SEED = 20261119` for modelling).

## Tests

```bash
python tests/test_step1_data_integrity.py
python -m unittest tests.test_math_reproducibility -v
python src/06_verify_references.py --verify-only
python tests/audit_manuscript.py
```

## Licence and citation

Code is released under the MIT License (see `LICENSE`). Please cite the article and this archive
(see `CITATION.cff`). Third-party datasets remain subject to their original terms of use.
"""

LICENSE_TXT = """MIT License

Copyright (c) 2026 The authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

CITATION_CFF = f"""cff-version: 1.2.0
message: "If you use this software or data, please cite it as below."
title: "{REPO_NAME}: Condensate–Timing–Liability model of CPEB4 microexon 4 mis-splicing in autism and schizophrenia"
version: "{VERSION}"
date-released: "2026-11-19"
license: MIT
authors:
  - family-names: "[Author 1 surname]"
    given-names: "[Author 1 given names]"
  - family-names: "[Author 2 surname]"
    given-names: "[Author 2 given names]"
keywords:
  - CPEB4
  - microexon
  - autism spectrum disorder
  - schizophrenia
  - biomolecular condensates
  - polygenic risk
"""

ENV_YML = """name: cpeb4-ctl
channels:
  - conda-forge
dependencies:
  - python=3.12
  - numpy>=2.0
  - scipy>=1.13
  - pandas>=2.2
  - matplotlib>=3.9
  - seaborn>=0.13
  - statsmodels>=0.14
  - scikit-learn>=1.5
  - networkx>=3.3
  - openpyxl>=3.1
  - lxml>=5.0
  - pip
  - pip:
      - python-docx>=1.1
"""

REQUIREMENTS = """numpy>=2.0
scipy>=1.13
pandas>=2.2
matplotlib>=3.9
seaborn>=0.13
statsmodels>=0.14
scikit-learn>=1.5
networkx>=3.3
openpyxl>=3.1
lxml>=5.0
python-docx>=1.1
"""

RUN_ALL = '''#!/usr/bin/env python3
"""Deterministic end-to-end runner for the CPEB4 CTL pipeline.

python run_all.py                 # full pipeline including data download
python run_all.py --skip-fetch    # reuse data/processed
python run_all.py --verify-only   # tests only
"""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PIPELINE = [
    ["src/01_fetch_and_harmonize_data.py"],
    ["src/02_bioinformatics_validation.py"],
    ["src/03_biophysical_calibration.py"],
    ["src/04_multiscale_ctl_model.py"],
    ["src/05_sensitivity_and_cohort.py"],
    ["src/06_verify_references.py", "--verify-only"],
    ["src/07_generate_figures.py", "--figs", "all"],
    ["src/08_build_manuscript_and_package.py", "--no-zip"],
]
TESTS = [
    ["tests/test_step1_data_integrity.py"],
    ["-m", "unittest", "tests.test_math_reproducibility", "-v"],
    ["tests/audit_manuscript.py"],
]


def run(args):
    print("\\n>>> python " + " ".join(args), flush=True)
    subprocess.run([sys.executable, *args], cwd=ROOT, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-fetch", action="store_true")
    ap.add_argument("--verify-only", action="store_true")
    a = ap.parse_args()
    if not a.verify_only:
        for step in PIPELINE:
            if a.skip_fetch and step[0].startswith("src/01_"):
                continue
            run(step)
    for t in TESTS:
        run(t)
    print("\\nAll steps completed successfully.")


if __name__ == "__main__":
    main()
'''

EXCLUDE_DIRS = {"__pycache__", ".git", ".ipynb_checkpoints"}
MAX_RAW_FILE_MB = 10.0


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_archive_files() -> tuple[list[Path], list[Path]]:
    included, excluded = [], []
    for p in sorted(WORKSPACE.rglob("*")):
        if not p.is_file() or any(part in EXCLUDE_DIRS for part in p.parts) or p.suffix in {".pyc", ".tmp"}:
            continue
        rel = p.relative_to(WORKSPACE)
        if rel.parts[0] == "data" and rel.parts[1] == "raw" and p.stat().st_size > MAX_RAW_FILE_MB * 1e6:
            excluded.append(p)
            continue
        included.append(p)
    return included, excluded


def write_root_files() -> None:
    (WORKSPACE / "README.md").write_text(README, encoding="utf-8")
    (WORKSPACE / "LICENSE").write_text(LICENSE_TXT, encoding="utf-8")
    (WORKSPACE / "CITATION.cff").write_text(CITATION_CFF, encoding="utf-8")
    (WORKSPACE / "environment.yml").write_text(ENV_YML, encoding="utf-8")
    (WORKSPACE / "requirements.txt").write_text(REQUIREMENTS, encoding="utf-8")
    (WORKSPACE / "run_all.py").write_text(RUN_ALL, encoding="utf-8")


def write_file_list() -> Path:
    included, excluded = collect_archive_files()
    out = MS_DIR / "FILE_LIST_GitHub_Zenodo.txt"
    lines = [f"{REPO_NAME} {VERSION} — file list for GitHub/Zenodo deposition", "",
             "SHA-256  BYTES  PATH (files included in the archive)"]
    for p in included:
        if p == out:
            continue
        lines.append(f"{_sha256(p)}  {p.stat().st_size}  {p.relative_to(WORKSPACE).as_posix()}")
    lines += ["", f"Large raw downloads (> {MAX_RAW_FILE_MB:.0f} MB) not bundled; re-downloaded by src/01_fetch_and_harmonize_data.py "
              "and checked against data/raw/provenance.json:"]
    for p in excluded:
        lines.append(f"{_sha256(p)}  {p.stat().st_size}  {p.relative_to(WORKSPACE).as_posix()}")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def write_zip() -> tuple[int, int]:
    included, _ = collect_archive_files()
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for p in included:
            zf.write(p, f"{REPO_NAME}-{VERSION}/{p.relative_to(WORKSPACE).as_posix()}")
    return len(included), ZIP_PATH.stat().st_size


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-zip", action="store_true")
    args = ap.parse_args()
    MS_DIR.mkdir(exist_ok=True)
    b = build_manuscript_bundle()
    build_main_docx(b, embed=True, path=MS_DIR / "Manuscript_Complete_with_Figures.docx")
    build_main_docx(b, embed=False, path=MS_DIR / "Manuscript_Text_Only.docx")
    build_main_md(b, MS_DIR / "Manuscript.md")
    build_supp_docx(b, MS_DIR / "Supplementary_Material.docx")
    build_supp_md(b, MS_DIR / "Supplementary_Material.md")
    build_title_page(b, MS_DIR / "Title_Page.docx")
    build_cover_letter(b, MS_DIR / "Cover_Letter.docx")
    write_root_files()
    write_file_list()
    for p in sorted(MS_DIR.iterdir()):
        print(f"  {p.name:45s} {p.stat().st_size:>12,d} bytes")
    if not args.no_zip:
        n, size = write_zip()
        print(f"  ZIP {ZIP_PATH} : {n} files, {size:,d} bytes")


if __name__ == "__main__":
    main()
