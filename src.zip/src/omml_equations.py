#!/usr/bin/env python3
"""
Step 6a: Native Word OMML (<m:oMath>) Equation Builder
======================================================
Builds editable native Microsoft Word Office Math Markup Language (<m:oMath>)
equations for all 16 main equations (1)-(16) and 4 supplementary equations
(S1)-(S4) matching `src/03_biophysical_calibration.py`,
`src/04_multiscale_ctl_model.py`, and `src/05_sensitivity_and_cohort.py`.

Zero raster equation images are used. All equations use Cambria Math,
centered on A4 2.54 cm margin text width (4513 twips), with right-aligned
Times New Roman 12 pt equation numbers at 9026 twips.
"""

from __future__ import annotations

from typing import Iterable, List, Optional, Union

from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from lxml import etree

M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NSMAP = {"m": M_NS, "w": W_NS}

MathNode = Union[etree._Element, List[etree._Element]]


def _m(tag: str, **kwargs: str) -> etree._Element:
    el = etree.Element(f"{{{M_NS}}}{tag}", nsmap=NSMAP)
    for k, v in kwargs.items():
        el.set(f"{{{M_NS}}}{k}", v)
    return el


def _w(tag: str, **kwargs: str) -> etree._Element:
    el = etree.Element(f"{{{W_NS}}}{tag}", nsmap=NSMAP)
    for k, v in kwargs.items():
        el.set(f"{{{W_NS}}}{k}", v)
    return el


def _append_items(container: etree._Element, items: MathNode) -> None:
    if isinstance(items, (list, tuple)):
        for it in items:
            container.append(it)
    else:
        container.append(items)


def m_run(
    text: str,
    upright: bool = False,
    bold: bool = False,
    size_half_pt: int = 24,
) -> etree._Element:
    """Create an OMML math run (<m:r>) with Cambria Math formatting."""
    r = _m("r")
    mrPr = _m("rPr")
    if upright and bold:
        mrPr.append(_m("sty", val="b"))
    elif upright:
        mrPr.append(_m("nor"))
        mrPr.append(_m("sty", val="p"))
    elif bold:
        mrPr.append(_m("sty", val="bi"))
    r.append(mrPr)

    wrPr = _w("rPr")
    rFonts = _w("rFonts")
    rFonts.set(f"{{{W_NS}}}ascii", "Cambria Math")
    rFonts.set(f"{{{W_NS}}}hAnsi", "Cambria Math")
    rFonts.set(f"{{{W_NS}}}cs", "Cambria Math")
    wrPr.append(rFonts)
    sz = _w("sz")
    sz.set(f"{{{W_NS}}}val", str(size_half_pt))
    szCs = _w("szCs")
    szCs.set(f"{{{W_NS}}}val", str(size_half_pt))
    wrPr.append(sz)
    wrPr.append(szCs)
    if bold:
        wrPr.append(_w("b"))
    r.append(wrPr)

    t = _m("t")
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text
    r.append(t)
    return r


def m_sub(base: MathNode, sub: MathNode) -> etree._Element:
    sSub = _m("sSub")
    e = _m("e")
    _append_items(e, base)
    s = _m("sub")
    _append_items(s, sub)
    sSub.append(e)
    sSub.append(s)
    return sSub


def m_sup(base: MathNode, sup: MathNode) -> etree._Element:
    sSup = _m("sSup")
    e = _m("e")
    _append_items(e, base)
    s = _m("sup")
    _append_items(s, sup)
    sSup.append(e)
    sSup.append(s)
    return sSup


def m_subsup(base: MathNode, sub: MathNode, sup: MathNode) -> etree._Element:
    sSubSup = _m("sSubSup")
    e = _m("e")
    _append_items(e, base)
    sb = _m("sub")
    _append_items(sb, sub)
    sp = _m("sup")
    _append_items(sp, sup)
    sSubSup.append(e)
    sSubSup.append(sb)
    sSubSup.append(sp)
    return sSubSup


def m_frac(num: MathNode, den: MathNode, bar_type: str = "bar") -> etree._Element:
    f = _m("f")
    fPr = _m("fPr")
    fPr.append(_m("type", val=bar_type))
    f.append(fPr)
    n = _m("num")
    _append_items(n, num)
    d = _m("den")
    _append_items(d, den)
    f.append(n)
    f.append(d)
    return f


def m_delim(inner: MathNode, beg: str = "(", end: str = ")") -> etree._Element:
    d = _m("d")
    dPr = _m("dPr")
    dPr.append(_m("begChr", val=beg))
    dPr.append(_m("endChr", val=end))
    d.append(dPr)
    e = _m("e")
    _append_items(e, inner)
    d.append(e)
    return d


def m_sqrt(body: MathNode) -> etree._Element:
    rad = _m("rad")
    radPr = _m("radPr")
    radPr.append(_m("degHide", val="1"))
    rad.append(radPr)
    deg = _m("deg")
    rad.append(deg)
    e = _m("e")
    _append_items(e, body)
    rad.append(e)
    return rad


def m_acc(base: MathNode, chr_val: str = "\u0303") -> etree._Element:
    """Accent wrapper (default tilde \u0303)."""
    acc = _m("acc")
    accPr = _m("accPr")
    accPr.append(_m("chr", val=chr_val))
    acc.append(accPr)
    e = _m("e")
    _append_items(e, base)
    acc.append(e)
    return acc


def m_nary(
    symbol: str,
    sub: Optional[MathNode],
    sup: Optional[MathNode],
    body: MathNode,
    lim_loc: str = "subSup",
) -> etree._Element:
    nary = _m("nary")
    naryPr = _m("naryPr")
    naryPr.append(_m("chr", val=symbol))
    naryPr.append(_m("limLoc", val=lim_loc))
    if sub is None:
        naryPr.append(_m("subHide", val="1"))
    if sup is None:
        naryPr.append(_m("supHide", val="1"))
    nary.append(naryPr)
    sb = _m("sub")
    if sub is not None:
        _append_items(sb, sub)
    sp = _m("sup")
    if sup is not None:
        _append_items(sp, sup)
    e = _m("e")
    _append_items(e, body)
    nary.append(sb)
    nary.append(sp)
    nary.append(e)
    return nary


def m_eqArr(rows: Iterable[MathNode]) -> etree._Element:
    """Vertical equation array (<m:eqArr>) for multi-line/piecewise display."""
    arr = _m("eqArr")
    for row in rows:
        e = _m("e")
        _append_items(e, row)
        arr.append(e)
    return arr


def m_matrix(rows: Iterable[Iterable[MathNode]]) -> etree._Element:
    """Native OMML matrix (<m:m>) for vector/covariance blocks."""
    mat = _m("m")
    for row in rows:
        mr = _m("mr")
        for cell in row:
            e = _m("e")
            _append_items(e, cell)
            mr.append(e)
        mat.append(mr)
    return mat


def _normalize_key(eq_key: Union[int, str]) -> str:
    k = str(eq_key).strip().lstrip("(").rstrip(")")
    if k.lower().startswith("eq"):
        k = k[2:].strip("_- ")
    return k.upper() if k.upper().startswith("S") else k


def build_omml_eq(eq_key: Union[int, str]) -> List[etree._Element]:
    """Return list of OMML nodes for equations 1..16 and S1..S4."""
    key = _normalize_key(eq_key)

    def mr(txt: str, upright: bool = False, bold: bool = False, sz: int = 24) -> etree._Element:
        return m_run(txt, upright=upright, bold=bold, size_half_pt=sz)

    # ------------------------------------------------------------------
    # Eq. (1): Henderson-Hasselbalch protonation & unbuffered HClust u
    # ------------------------------------------------------------------
    if key == "1":
        sz = 24
        row1 = [
            m_sub(mr("f", sz=sz), [mr("H", upright=True, sz=sz), mr("+", upright=True, sz=sz)]),
            m_delim(mr("pH", upright=True, sz=sz)),
            mr(" = ", sz=sz),
            m_sup(
                m_delim([
                    mr("1 + ", sz=sz),
                    m_sup(mr("10", upright=True, sz=sz), [mr("pH", upright=True, sz=sz), mr(" − ", sz=sz), mr("p", upright=True, sz=sz), m_sub(mr("K", sz=sz), mr("a", sz=sz))]),
                ], beg="[", end="]"),
                mr("−1", sz=sz),
            ),
        ]
        row2 = [
            mr("u", sz=sz),
            m_delim([m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)), mr(", ", sz=sz), mr("pH", upright=True, sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)),
            m_delim([
                mr("1 − ", sz=sz),
                m_sub(mr("f", sz=sz), [mr("H", upright=True, sz=sz), mr("+", upright=True, sz=sz)]),
                m_delim(mr("pH", upright=True, sz=sz)),
            ], beg="[", end="]"),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (2): Cooperative Hill aggregation & cross-pH threshold scaling
    # ------------------------------------------------------------------
    if key == "2":
        sz = 22
        row1 = [
            m_sub(mr("A", sz=sz), mr("eq", upright=True, sz=sz)),
            m_delim([m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)), mr(", ", sz=sz), mr("pH", upright=True, sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("A", sz=sz), mr("min", upright=True, sz=sz)),
            mr(" + ", sz=sz),
            m_frac(
                [m_sub(mr("A", sz=sz), mr("max", upright=True, sz=sz)), mr(" − ", sz=sz), m_sub(mr("A", sz=sz), mr("min", upright=True, sz=sz))],
                [
                    mr("1 + ", sz=sz),
                    m_sup(
                        m_delim(
                            m_frac(
                                [m_sub(mr("χ", sz=sz), mr("c", sz=sz)), m_delim(mr("pH", upright=True, sz=sz))],
                                m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)),
                            )
                        ),
                        m_sub(mr("n", sz=sz), mr("H", sz=sz)),
                    ),
                ],
            ),
        ]
        row2 = [
            m_sub(mr("χ", sz=sz), mr("c", sz=sz)),
            m_delim(mr("pH", upright=True, sz=sz)),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("c", sz=sz)),
            m_delim(m_sub(mr("pH", upright=True, sz=sz), mr("ref", upright=True, sz=sz))),
            mr(" ", sz=sz),
            m_frac(
                [
                    mr("1 − ", sz=sz),
                    m_sub(mr("f", sz=sz), [mr("H", upright=True, sz=sz), mr("+", upright=True, sz=sz)]),
                    m_delim(m_sub(mr("pH", upright=True, sz=sz), mr("ref", upright=True, sz=sz))),
                ],
                [
                    mr("1 − ", sz=sz),
                    m_sub(mr("f", sz=sz), [mr("H", upright=True, sz=sz), mr("+", upright=True, sz=sz)]),
                    m_delim(mr("pH", upright=True, sz=sz)),
                ],
            ),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (3): Linear cloud-point thermodynamics
    # ------------------------------------------------------------------
    if key == "3":
        sz = 24
        return [
            m_sub(mr("T", sz=sz), mr("c", sz=sz)),
            m_delim(m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz))),
            mr(" = ", sz=sz),
            m_sub(mr("T", sz=sz), mr("c,0", sz=sz)),
            mr(" + ", sz=sz),
            m_sub(mr("γ", sz=sz), mr("T", sz=sz)),
            mr(" ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)),
        ]

    # ------------------------------------------------------------------
    # Eq. (4): Liquid condensate pool dL/dt
    # ------------------------------------------------------------------
    if key == "4":
        sz = 20
        return [
            m_frac([mr("d", upright=True, sz=sz), mr("L", sz=sz)], [mr("d", upright=True, sz=sz), mr("t", sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("k", sz=sz), mr("form", upright=True, sz=sz)),
            m_delim(mr("1 − L − S", sz=sz)),
            mr(" − ", sz=sz),
            m_sub(mr("k", sz=sz), mr("diss", upright=True, sz=sz)),
            m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            m_sub(mr("R", sz=sz), mr("rev", upright=True, sz=sz)),
            mr("L − ", sz=sz),
            m_sub(mr("k", sz=sz), mr("lock", upright=True, sz=sz)),
            m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz)),
            m_delim([m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)), mr(", ", sz=sz), mr("pH", upright=True, sz=sz)]),
            m_delim([mr("1 + ", sz=sz), m_sub(mr("λ", sz=sz), mr("D", sz=sz)), m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz)), m_delim(mr("t", sz=sz))]),
            mr("L", sz=sz),
        ]

    # ------------------------------------------------------------------
    # Eq. (5): Solid locked aggregate pool dS/dt
    # ------------------------------------------------------------------
    if key == "5":
        sz = 22
        return [
            m_frac([mr("d", upright=True, sz=sz), mr("S", sz=sz)], [mr("d", upright=True, sz=sz), mr("t", sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("k", sz=sz), mr("lock", upright=True, sz=sz)),
            m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz)),
            m_delim([m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)), mr(", ", sz=sz), mr("pH", upright=True, sz=sz)]),
            m_delim([mr("1 + ", sz=sz), m_sub(mr("λ", sz=sz), mr("D", sz=sz)), m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz)), m_delim(mr("t", sz=sz))]),
            mr("L − ", sz=sz),
            m_sub(mr("k", sz=sz), mr("clr", upright=True, sz=sz)),
            mr("S", sz=sz),
        ]

    # ------------------------------------------------------------------
    # Eq. (6): Functional translational buffering capacity Phi(t)
    # ------------------------------------------------------------------
    if key == "6":
        sz = 24
        return [
            mr("Φ", sz=sz),
            m_delim(mr("t", sz=sz)),
            mr(" = 1 − ", sz=sz),
            m_sub(mr("η", sz=sz), mr("S", sz=sz)),
            mr("S", sz=sz),
            m_delim(mr("t", sz=sz)),
            mr(" − ", sz=sz),
            m_sub(mr("η", sz=sz), mr("L", sz=sz)),
            mr("L", sz=sz),
            m_delim(mr("t", sz=sz)),
            mr(",   0 ≤ ", sz=sz),
            m_sub(mr("η", sz=sz), mr("L", sz=sz)),
            mr(" < ", sz=sz),
            m_sub(mr("η", sz=sz), mr("S", sz=sz)),
            mr(" ≤ 1", sz=sz),
        ]

    # ------------------------------------------------------------------
    # Eq. (7): Prefrontal synaptic density ODE dN_s/dt
    # ------------------------------------------------------------------
    if key == "7":
        sz = 20
        term1 = [
            m_sub(mr("α", sz=sz), mr("syn", upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr(" max", upright=True, sz=sz),
            m_delim([
                mr("0, 1 − ", sz=sz),
                m_sub(mr("κ", sz=sz), mr("1", sz=sz)),
                m_delim([mr("1 − Φ", sz=sz), m_delim(mr("t", sz=sz))]),
                m_sub(mr("g", sz=sz), mr("ASD", upright=True, sz=sz)),
                m_delim(m_sub(mr("P", sz=sz), mr("ASD", upright=True, sz=sz))),
            ]),
        ]
        term2 = [
            m_delim([
                m_sub(mr("δ", sz=sz), mr("0", sz=sz)),
                mr(" + ", sz=sz),
                m_sub(mr("β", sz=sz), mr("prun", upright=True, sz=sz)),
                m_delim(mr("t", sz=sz)),
                m_delim([
                    mr("1 + ", sz=sz),
                    m_sub(mr("κ", sz=sz), mr("2", sz=sz)),
                    m_delim([mr("1 − Φ", sz=sz), m_delim(mr("t", sz=sz))]),
                    m_sub(mr("g", sz=sz), mr("SCZ", upright=True, sz=sz)),
                    m_delim(m_sub(mr("P", sz=sz), mr("SCZ", upright=True, sz=sz))),
                ]),
            ], beg="[", end="]"),
            m_sub(mr("N", sz=sz), mr("s", sz=sz)),
            m_delim(mr("t", sz=sz)),
        ]
        return [
            m_frac([mr("d", upright=True, sz=sz), m_sub(mr("N", sz=sz), mr("s", sz=sz))], [mr("d", upright=True, sz=sz), mr("t", sz=sz)]),
            mr(" = ", sz=sz),
            *term1,
            mr(" − ", sz=sz),
            *term2,
        ]

    # ------------------------------------------------------------------
    # Eq. (8): Bivariate correlated polygenic risk scores
    # ------------------------------------------------------------------
    if key == "8":
        sz = 24
        sigma_mat = m_delim(
            m_matrix([
                [mr("1", sz=sz), m_sub(mr("r", sz=sz), mr("G", sz=sz))],
                [m_sub(mr("r", sz=sz), mr("G", sz=sz)), mr("1", sz=sz)],
            ])
        )
        return [
            m_sup(m_delim([m_sub(mr("P", sz=sz), mr("ASD", upright=True, sz=sz)), mr(", ", sz=sz), m_sub(mr("P", sz=sz), mr("SCZ", upright=True, sz=sz))]), mr("⊤", sz=sz)),
            mr(" ~ ", sz=sz),
            mr("𝒩", upright=True, sz=sz),
            m_delim([mr("0", bold=True, upright=True, sz=sz), mr(", ", sz=sz), mr("Σ", upright=True, sz=sz)]),
            mr(",   ", sz=sz),
            mr("Σ", upright=True, sz=sz),
            mr(" = ", sz=sz),
            sigma_mat,
        ]

    # ------------------------------------------------------------------
    # Eq. (9): Bounded polygenic amplification g_d(P_d)
    # ------------------------------------------------------------------
    if key == "9":
        sz = 24
        return [
            m_sub(mr("g", sz=sz), mr("d", sz=sz)),
            m_delim(m_sub(mr("P", sz=sz), mr("d", sz=sz))),
            mr(" = ", sz=sz),
            mr("exp", upright=True, sz=sz),
            m_delim([
                m_sub(mr("γ", sz=sz), mr("d", sz=sz)),
                m_sub(mr("c", sz=sz), mr("P", sz=sz)),
                mr(" tanh", upright=True, sz=sz),
                m_delim(m_frac(m_sub(mr("P", sz=sz), mr("d", sz=sz)), m_sub(mr("c", sz=sz), mr("P", sz=sz)))),
            ], beg="[", end="]"),
            mr(",   d ∈ ", sz=sz),
            m_delim([mr("ASD, SCZ", upright=True, sz=sz)], beg="{", end="}"),
        ]

    # ------------------------------------------------------------------
    # Eq. (10) & Eq. (11): Cumulative disorder liabilities L_ASD(t), L_SCZ(t)
    # ------------------------------------------------------------------
    if key in ("10", "11"):
        sz = 20
        dis = "ASD" if key == "10" else "SCZ"
        idx_num = "1" if key == "10" else "2"
        integrand = [
            m_sub(mr("V", sz=sz), mr(dis, upright=True, sz=sz)),
            m_delim(mr("s", sz=sz)),
            m_delim([
                m_sub(mr("w", sz=sz), mr(f"P,{idx_num}", sz=sz)),
                m_sub(mr("P", sz=sz), mr(dis, upright=True, sz=sz)),
                mr(" + ", sz=sz),
                m_sub(mr("ε", sz=sz), mr(dis, upright=True, sz=sz)),
                mr(" + ", sz=sz),
                m_sub(mr("w", sz=sz), mr(f"Φ,{idx_num}", sz=sz)),
                m_delim([
                    m_delim([mr("1 − Φ", sz=sz), m_delim(mr("s", sz=sz))]),
                    m_sub(mr("g", sz=sz), mr(dis, upright=True, sz=sz)),
                    m_delim(m_sub(mr("P", sz=sz), mr(dis, upright=True, sz=sz))),
                    mr(" − ", sz=sz),
                    m_delim([mr("1 − ", sz=sz), m_sub(mr("Φ", sz=sz), mr("ctrl", upright=True, sz=sz)), m_delim(mr("s", sz=sz))]),
                ]),
                mr(" + ", sz=sz),
                m_sub(mr("w", sz=sz), mr(f"N,{idx_num}", sz=sz)),
                m_sub(
                    m_delim([
                        m_subsup(mr("N", sz=sz), mr("s", sz=sz), mr("ctrl", upright=True, sz=sz)),
                        m_delim(mr("s", sz=sz)),
                        mr(" − ", sz=sz),
                        m_sub(mr("N", sz=sz), mr("s", sz=sz)),
                        m_delim(mr("s", sz=sz)),
                    ], beg="[", end="]"),
                    mr("+", sz=sz),
                ),
            ], beg="[", end="]"),
            mr(" d", upright=True, sz=sz),
            mr("s", sz=sz),
        ]
        return [
            m_sub(mr("ℒ", upright=True, sz=sz), mr(dis, upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr(" = ", sz=sz),
            m_nary("∫", m_sub(mr("t", sz=sz), mr("0", sz=sz)), mr("t", sz=sz), integrand, lim_loc="subSup"),
        ]

    # ------------------------------------------------------------------
    # Eq. (12): Normalized liabilities & 4-regime diagnostic classification
    # ------------------------------------------------------------------
    if key == "12":
        sz = 20
        row_norm = [
            m_sub(m_acc(mr("ℒ", upright=True, sz=sz)), mr("d", sz=sz)),
            mr(" = ", sz=sz),
            m_frac(
                [mr("max", upright=True, sz=sz), m_delim([mr("0, ", sz=sz), m_sub(mr("ℒ", upright=True, sz=sz), mr("d", sz=sz)), m_delim(m_sub(mr("T", sz=sz), mr("max", upright=True, sz=sz)))])],
                m_sub(mr("θ", sz=sz), mr("d", sz=sz)),
            ),
            mr(",   ", sz=sz),
            mr("𝒞", upright=True, sz=sz),
            mr(" = ", sz=sz),
        ]
        l_a = m_sub(m_acc(mr("ℒ", upright=True, sz=sz)), mr("ASD", upright=True, sz=sz))
        l_s = m_sub(m_acc(mr("ℒ", upright=True, sz=sz)), mr("SCZ", upright=True, sz=sz))
        cases = m_delim(
            m_eqArr([
                [mr("Comorbid,   if ", upright=True, sz=sz), l_a, mr(" ≥ 1 ∧ ", sz=sz), l_s, mr(" ≥ 1", sz=sz)],
                [mr("ASD-only,   if ", upright=True, sz=sz), l_a, mr(" ≥ 1 > ", sz=sz), l_s],
                [mr("SCZ-only,   if ", upright=True, sz=sz), l_s, mr(" ≥ 1 > ", sz=sz), l_a],
                [mr("Resilient,   otherwise", upright=True, sz=sz)],
            ]),
            beg="{",
            end="",
        )
        return [*row_norm, cases]

    # ------------------------------------------------------------------
    # Eq. (13): Continuous Phenotypic Bias Index Psi
    # ------------------------------------------------------------------
    if key == "13":
        sz = 24
        l_a = m_sub(m_acc(mr("ℒ", upright=True, sz=sz)), mr("ASD", upright=True, sz=sz))
        l_s = m_sub(m_acc(mr("ℒ", upright=True, sz=sz)), mr("SCZ", upright=True, sz=sz))
        return [
            mr("Ψ", sz=sz),
            mr(" = ", sz=sz),
            m_frac([l_s, mr(" − ", sz=sz), l_a], [l_s, mr(" + ", sz=sz), l_a]),
            mr(" ∈ ", sz=sz),
            m_delim(mr("−1, +1", sz=sz), beg="[", end="]"),
        ]

    # ------------------------------------------------------------------
    # Eq. (14): Conditional developmental splicing perturbation chi_delta4(t)
    # ------------------------------------------------------------------
    if key == "14":
        sz = 24
        return [
            m_sub(mr("χ", sz=sz), mr("Δ4", sz=sz)),
            m_delim([mr("t; ", sz=sz), m_sub(mr("τ", sz=sz), mr("on", upright=True, sz=sz)), mr(", Δ", sz=sz), mr("χ", sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("ctrl", upright=True, sz=sz)),
            mr(" + Δ", sz=sz),
            mr("χ", sz=sz),
            mr(" ", sz=sz),
            mr("σ", sz=sz),
            m_delim(m_frac([mr("t − ", sz=sz), m_sub(mr("τ", sz=sz), mr("on", upright=True, sz=sz))], mr("ϵ", sz=sz))),
        ]

    # ------------------------------------------------------------------
    # Eq. (15): SSO therapeutic splicing rescue & saturating efficacy
    # ------------------------------------------------------------------
    if key == "15":
        sz = 20
        row1 = [
            m_subsup(mr("χ", sz=sz), mr("Δ4", sz=sz), mr("SSO", upright=True, sz=sz)),
            m_delim([mr("t; ", sz=sz), m_sub(mr("τ", sz=sz), mr("rx", upright=True, sz=sz)), mr(", ", sz=sz), m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))]),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("ctrl", upright=True, sz=sz)),
            mr(" + ", sz=sz),
            m_delim([m_sub(mr("χ", sz=sz), mr("path", upright=True, sz=sz)), m_delim(mr("t", sz=sz)), mr(" − ", sz=sz), m_sub(mr("χ", sz=sz), mr("ctrl", upright=True, sz=sz))]),
            m_delim([
                mr("1 − ", sz=sz),
                m_sub(mr("f", sz=sz), mr("SSO", upright=True, sz=sz)),
                m_delim(m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))),
                mr("σ", sz=sz),
                m_delim(m_frac([mr("t − ", sz=sz), m_sub(mr("τ", sz=sz), mr("rx", upright=True, sz=sz))], mr("ϵ", sz=sz))),
            ], beg="[", end="]"),
        ]
        row2 = [
            m_sub(mr("f", sz=sz), mr("SSO", upright=True, sz=sz)),
            m_delim(m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))),
            mr(" = ", sz=sz),
            m_frac(
                [m_delim([mr("1 + ", sz=sz), m_sub(mr("K", sz=sz), mr("SSO", upright=True, sz=sz))]), m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))],
                [m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz)), mr(" + ", sz=sz), m_sub(mr("K", sz=sz), mr("SSO", upright=True, sz=sz))],
            ),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (16): Therapeutic Reversibility Index R_d
    # ------------------------------------------------------------------
    if key == "16":
        sz = 24
        return [
            m_sub(mr("ℛ", upright=True, sz=sz), mr("d", sz=sz)),
            m_delim([m_sub(mr("τ", sz=sz), mr("rx", upright=True, sz=sz)), mr(", ", sz=sz), m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))]),
            mr(" = 1 − ", sz=sz),
            m_frac(
                [
                    m_subsup(mr("ℒ", upright=True, sz=sz), mr("d", sz=sz), mr("SSO", upright=True, sz=sz)),
                    m_delim([m_sub(mr("τ", sz=sz), mr("rx", upright=True, sz=sz)), mr(", ", sz=sz), m_sub(mr("d", sz=sz), mr("SSO", upright=True, sz=sz))]),
                    mr(" − ", sz=sz),
                    m_subsup(mr("ℒ", upright=True, sz=sz), mr("d", sz=sz), mr("ctrl", upright=True, sz=sz)),
                ],
                [
                    m_subsup(mr("ℒ", upright=True, sz=sz), mr("d", sz=sz), mr("untreated", upright=True, sz=sz)),
                    mr(" − ", sz=sz),
                    m_subsup(mr("ℒ", upright=True, sz=sz), mr("d", sz=sz), mr("ctrl", upright=True, sz=sz)),
                ],
            ),
            mr(" ∈ ", sz=sz),
            m_delim(mr("0, 1", sz=sz), beg="[", end="]"),
        ]

    # ------------------------------------------------------------------
    # Eq. (S1): Exact Scale-1 Quasi-Steady State (L*, S*, Phi*)
    # ------------------------------------------------------------------
    if key == "S1":
        sz = 22
        a_til = m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz))
        denom = [mr("B + βC", sz=sz), a_til]
        row1 = [
            m_sup(mr("L", sz=sz), mr("*", sz=sz)),
            mr(" = ", sz=sz),
            m_frac(mr("1", sz=sz), denom),
            mr(",   ", sz=sz),
            m_sup(mr("S", sz=sz), mr("*", sz=sz)),
            mr(" = ", sz=sz),
            m_frac([mr("C", sz=sz), a_til], [mr("B + βC", sz=sz), m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz))]),
            mr(",   ", sz=sz),
            m_sup(mr("Φ", sz=sz), mr("*", sz=sz)),
            mr(" = 1 − ", sz=sz),
            m_frac(
                [m_sub(mr("η", sz=sz), mr("L", sz=sz)), mr(" + ", sz=sz), m_sub(mr("η", sz=sz), mr("S", sz=sz)), mr("C", sz=sz), m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz))],
                [mr("B + βC", sz=sz), m_sub(m_acc(mr("A", sz=sz)), mr("eq", upright=True, sz=sz))],
            ),
        ]
        row2 = [
            mr("B = 1 + ", sz=sz),
            m_frac([m_sub(mr("k", sz=sz), mr("diss", upright=True, sz=sz)), m_sub(mr("R", sz=sz), mr("rev", upright=True, sz=sz)), m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz))], m_sub(mr("k", sz=sz), mr("form", upright=True, sz=sz))),
            mr(",   C = ", sz=sz),
            m_frac([m_sub(mr("k", sz=sz), mr("lock", upright=True, sz=sz)), m_delim([mr("1 + ", sz=sz), m_sub(mr("λ", sz=sz), mr("D", sz=sz)), m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz))])], m_sub(mr("k", sz=sz), mr("clr", upright=True, sz=sz))),
            mr(",   β = 1 + ", sz=sz),
            m_frac(m_sub(mr("k", sz=sz), mr("clr", upright=True, sz=sz)), m_sub(mr("k", sz=sz), mr("form", upright=True, sz=sz))),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (S2): Activity-shifted critical thresholds chi_1/2^lock & chi_c^eff
    # ------------------------------------------------------------------
    if key == "S2":
        sz = 22
        row1 = [
            m_subsup(mr("χ", sz=sz), mr("1/2", sz=sz), mr("lock", upright=True, sz=sz)),
            m_delim(m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz))),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("c", sz=sz)),
            m_delim(mr("pH", upright=True, sz=sz)),
            m_sup(
                m_delim(m_frac(mr("B", sz=sz), mr("B + βC", sz=sz)), beg="[", end="]"),
                m_frac(mr("1", sz=sz), m_sub(mr("n", sz=sz), mr("H", sz=sz))),
            ),
            mr(",   ", sz=sz),
            m_subsup(mr("χ", sz=sz), mr("c", sz=sz), mr("eff", upright=True, sz=sz)),
            m_delim(m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz))),
            mr(" = ", sz=sz),
            m_sub(mr("χ", sz=sz), mr("c", sz=sz)),
            m_delim(mr("pH", upright=True, sz=sz)),
            m_sup(
                m_delim(
                    m_frac(m_sub(mr("A", sz=sz), mr("crit", upright=True, sz=sz)), [mr("1 − ", sz=sz), m_sub(mr("A", sz=sz), mr("crit", upright=True, sz=sz))]),
                    beg="[", end="]",
                ),
                m_frac(mr("1", sz=sz), m_sub(mr("n", sz=sz), mr("H", sz=sz))),
            ),
        ]
        row2 = [
            m_sub(mr("A", sz=sz), mr("crit", upright=True, sz=sz)),
            m_delim(m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz))),
            mr(" = ", sz=sz),
            m_frac(
                [mr("B", sz=sz), m_delim([mr("1 − ", sz=sz), m_sub(mr("Φ", sz=sz), mr("crit", upright=True, sz=sz))]), mr(" − ", sz=sz), m_sub(mr("η", sz=sz), mr("L", sz=sz))],
                [mr("C", sz=sz), m_delim([m_sub(mr("η", sz=sz), mr("S", sz=sz)), mr(" − β", sz=sz), m_delim([mr("1 − ", sz=sz), m_sub(mr("Φ", sz=sz), mr("crit", upright=True, sz=sz))])])],
            ),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (S3): Developmental synaptogenesis alpha_syn(t) & pruning beta_prun(t)
    # ------------------------------------------------------------------
    if key == "S3":
        sz = 20
        row1 = [
            m_sub(mr("α", sz=sz), mr("syn", upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr(" = ", sz=sz),
            m_sub(mr("α", sz=sz), mr("base", upright=True, sz=sz)),
            mr(" + ", sz=sz),
            m_sub(mr("a", sz=sz), mr("peri", upright=True, sz=sz)),
            m_sup(mr("e", upright=True, sz=sz), [mr("−", sz=sz), m_frac(m_sup(m_delim([mr("t − ", sz=sz), m_sub(mr("t", sz=sz), mr("peri", upright=True, sz=sz))]), mr("2", sz=sz)), [mr("2", sz=sz), m_sup(m_sub(mr("s", sz=sz), mr("peri", upright=True, sz=sz)), mr("2", sz=sz))])]),
            mr("σ", sz=sz),
            m_delim(m_frac(mr("t + 0.34", sz=sz), mr("0.05", sz=sz))),
            mr(" + ", sz=sz),
            m_sub(mr("a", sz=sz), mr("inf", upright=True, sz=sz)),
            m_sup(mr("e", upright=True, sz=sz), [mr("−", sz=sz), m_frac(m_sup(m_delim([mr("t − ", sz=sz), m_sub(mr("t", sz=sz), mr("inf", upright=True, sz=sz))]), mr("2", sz=sz)), [mr("2", sz=sz), m_sup(m_sub(mr("s", sz=sz), mr("inf", upright=True, sz=sz)), mr("2", sz=sz))])]),
            mr("σ", sz=sz),
            m_delim(m_frac(mr("t − 0.10", sz=sz), mr("0.25", sz=sz))),
        ]
        row2 = [
            m_sub(mr("β", sz=sz), mr("prun", upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr(" = ", sz=sz),
            m_sub(mr("b", sz=sz), mr("prun", upright=True, sz=sz)),
            m_sub(mr("D", sz=sz), mr("act", upright=True, sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr("σ", sz=sz),
            m_delim(m_frac([mr("t − ", sz=sz), m_sub(mr("t", sz=sz), mr("prun,on", upright=True, sz=sz))], mr("1.0", sz=sz))),
            m_sup(mr("e", upright=True, sz=sz), [mr("−", sz=sz), m_frac(m_sup(m_delim([mr("t − ", sz=sz), m_sub(mr("t", sz=sz), mr("prun,pk", upright=True, sz=sz))]), mr("2", sz=sz)), [mr("2", sz=sz), m_sup(m_sub(mr("s", sz=sz), mr("prun", upright=True, sz=sz)), mr("2", sz=sz))])]),
        ]
        return [m_eqArr([row1, row2])]

    # ------------------------------------------------------------------
    # Eq. (S4): Birth-cohort developmental splicing trajectory chi_{Delta4,i}(t)
    # ------------------------------------------------------------------
    if key == "S4":
        sz = 20
        row1 = [
            m_sub(mr("χ", sz=sz), mr("Δ4,i", sz=sz)),
            m_delim(mr("t", sz=sz)),
            mr(" = ", sz=sz),
            mr("clip", upright=True, sz=sz),
            m_delim([
                m_sub(mr("χ", sz=sz), mr("ctrl", upright=True, sz=sz)),
                mr(" + ", sz=sz),
                m_sub(mr("δ", sz=sz), mr("const,i", upright=True, sz=sz)),
                mr(" + ", sz=sz),
                m_sub(mr("δ", sz=sz), [mr("W", sz=sz), mr("1", sz=sz), mr(",i", sz=sz)]),
                mr("σ", sz=sz),
                m_delim(m_frac(mr("6.5 − t", sz=sz), mr("1.0", sz=sz))),
                mr(" + ", sz=sz),
                m_sub(mr("δ", sz=sz), [mr("W", sz=sz), mr("2", sz=sz), mr(",i", sz=sz)]),
                mr("σ", sz=sz),
                m_delim(m_frac(mr("t − 10.0", sz=sz), mr("1.5", sz=sz))),
                mr(", 0.05, 0.95", sz=sz),
            ]),
        ]
        row2 = [
            m_sub(mr("δ", sz=sz), mr("const,i", upright=True, sz=sz)),
            mr(" ~ ", sz=sz),
            mr("𝒩", upright=True, sz=sz),
            m_delim([mr("0, ", sz=sz), m_subsup(mr("σ", sz=sz), mr("χ", sz=sz), mr("2", sz=sz))]),
            mr(",   ", sz=sz),
            m_sub(mr("δ", sz=sz), [mr("W", sz=sz), mr("1", sz=sz), mr(",i", sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("I", sz=sz), [mr("W", sz=sz), mr("1", sz=sz), mr(",i", sz=sz)]),
            m_sub(mr("U", sz=sz), [mr("W", sz=sz), mr("1", sz=sz), mr(",i", sz=sz)]),
            mr(",   ", sz=sz),
            m_sub(mr("δ", sz=sz), [mr("W", sz=sz), mr("2", sz=sz), mr(",i", sz=sz)]),
            mr(" = ", sz=sz),
            m_sub(mr("I", sz=sz), [mr("W", sz=sz), mr("2", sz=sz), mr(",i", sz=sz)]),
            m_sub(mr("U", sz=sz), [mr("W", sz=sz), mr("2", sz=sz), mr(",i", sz=sz)]),
        ]
        return [m_eqArr([row1, row2])]

    raise KeyError(f"Unknown equation key: {eq_key!r} (normalized={key!r})")


def add_equation_paragraph(doc, eq_label: Union[int, str], eq_key: Optional[Union[int, str]] = None):
    """
    Append a centered native Word OMML (<m:oMath>) display equation with a
    right-aligned equation number at 9026 twips (A4 with 2.54 cm margins).
    """
    key = eq_label if eq_key is None else eq_key
    lbl_str = str(eq_label).strip()
    if not (lbl_str.startswith("(") and lbl_str.endswith(")")):
        lbl_str = f"({lbl_str})"

    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15

    # Centered tab at 4513 twips, right-aligned tab at 9026 twips (15.92 cm)
    tabs = OxmlElement("w:tabs")
    tab_center = OxmlElement("w:tab")
    tab_center.set(qn("w:val"), "center")
    tab_center.set(qn("w:pos"), "4513")
    tabs.append(tab_center)
    tab_right = OxmlElement("w:tab")
    tab_right.set(qn("w:val"), "right")
    tab_right.set(qn("w:pos"), "9026")
    tabs.append(tab_right)
    pPr.append(tabs)

    # 1. Leading tab to center equation
    r1 = OxmlElement("w:r")
    r1.append(OxmlElement("w:tab"))
    p._p.append(r1)

    # 2. Native <m:oMath> block
    oMath = _m("oMath")
    for el in build_omml_eq(key):
        oMath.append(el)
    p._p.append(oMath)

    # 3. Trailing tab and right-aligned Times New Roman 12 pt black equation label
    r2 = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), "Times New Roman")
    rFonts.set(qn("w:hAnsi"), "Times New Roman")
    rFonts.set(qn("w:cs"), "Times New Roman")
    rPr.append(rFonts)
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), "24")
    szCs = OxmlElement("w:szCs")
    szCs.set(qn("w:val"), "24")
    rPr.append(sz)
    rPr.append(szCs)
    col = OxmlElement("w:color")
    col.set(qn("w:val"), "000000")
    rPr.append(col)
    r2.append(rPr)
    r2.append(OxmlElement("w:tab"))
    t = OxmlElement("w:t")
    t.text = lbl_str
    r2.append(t)
    p._p.append(r2)
    return p


def _self_test() -> None:
    import tempfile
    import zipfile
    from pathlib import Path
    from docx import Document

    doc = Document()
    keys = [str(i) for i in range(1, 17)] + ["S1", "S2", "S3", "S4"]
    for k in keys:
        add_equation_paragraph(doc, f"({k})", k)

    with tempfile.TemporaryDirectory() as td:
        out_p = Path(td) / "test_omml.docx"
        doc.save(str(out_p))
        with zipfile.ZipFile(out_p, "r") as zf:
            xml_bytes = zf.read("word/document.xml")
        root = etree.fromstring(xml_bytes)
        omaths = root.findall(f".//{{{M_NS}}}oMath")
        assert len(omaths) == 20, f"Expected 20 <m:oMath>, got {len(omaths)}"
        imgs = [n for n in zf.namelist() if n.startswith("word/media/")]
        assert len(imgs) == 0, f"Expected 0 images, got {imgs}"
        print(f"OMML self-test PASSED: {len(omaths)}/20 <m:oMath> elements verified, 0 images, valid OOXML.")


if __name__ == "__main__":
    _self_test()
