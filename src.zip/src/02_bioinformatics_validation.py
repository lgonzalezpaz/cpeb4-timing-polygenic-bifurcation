#!/usr/bin/env python3
"""
Step 2: Real-Data Multi-Omics Neurodevelopmental & Cross-Disorder Validation
===========================================================================
Rigorous statistical validation of CPEB4 targetome enrichment, BrainSpan
developmental temporal segregation, PsychENCODE postmortem cortical validation,
and empirical PFC calibration kernels.

All analyses operate strictly on harmonized real datasets in data/processed/
and raw PsychENCODE DER-13/14/15 files in data/raw/psychencode/.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PROC = BASE_DIR / "data" / "processed"
DATA_RAW = BASE_DIR / "data" / "raw"
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

SEED = 42
N_PERM = 10000
N_BOOT = 2000


def bh_fdr(pvals: np.ndarray | List[float]) -> np.ndarray:
    """Benjamini-Hochberg FDR correction handling NaNs gracefully."""
    p = np.asarray(pvals, dtype=float)
    q = np.full_like(p, np.nan)
    valid = np.isfinite(p)
    m = valid.sum()
    if m == 0:
        return q
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    adj = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0.0, 1.0)
    qv = np.empty_like(pv)
    qv[order] = adj
    q[valid] = qv
    return q


def fisher_with_ci(a: int, b: int, c: int, d: int) -> Dict[str, float]:
    """
    Two-sided Fisher's exact test with Woolf 95% CI (Haldane-Anscombe 0.5
    correction only when a cell is zero for CI stability) and exact conditional CI.
    """
    table = np.array([[a, b], [c, d]], dtype=int)
    or_fisher, p_fisher = stats.fisher_exact(table, alternative="two-sided")

    # Woolf log-OR CI
    aa, bb, cc, dd = float(a), float(b), float(c), float(d)
    if min(a, b, c, d) == 0:
        aa += 0.5
        bb += 0.5
        cc += 0.5
        dd += 0.5
    or_woolf = (aa * dd) / (bb * cc)
    se_log_or = math.sqrt(1.0 / aa + 1.0 / bb + 1.0 / cc + 1.0 / dd)
    ci_low_woolf = math.exp(math.log(or_woolf) - 1.959963984540054 * se_log_or)
    ci_high_woolf = math.exp(math.log(or_woolf) + 1.959963984540054 * se_log_or)

    # Exact conditional MLE CI via scipy.stats.contingency.odds_ratio
    try:
        res_exact = stats.contingency.odds_ratio(table, kind="conditional")
        ci_exact = res_exact.confidence_interval(confidence_level=0.95)
        exact_ci_low, exact_ci_high = float(ci_exact.low), float(ci_exact.high)
    except Exception:
        exact_ci_low, exact_ci_high = np.nan, np.nan

    return {
        "fisher_or": float(or_fisher),
        "fisher_p": float(p_fisher),
        "woolf_ci_low": float(ci_low_woolf),
        "woolf_ci_high": float(ci_high_woolf),
        "exact_ci_low": exact_ci_low,
        "exact_ci_high": exact_ci_high,
    }


def covariate_logit(
    df: pd.DataFrame, target_col: str, risk_mask: np.ndarray
) -> Dict[str, float]:
    """
    Multivariable logistic regression:
      risk_gene ~ is_target + mean_log2_rpkm + log10_gene_length_bp
    """
    sub = df[[target_col, "mean_log2_rpkm", "gene_length_bp"]].copy()
    sub["y"] = risk_mask.astype(int)
    sub = sub.dropna(subset=[target_col, "mean_log2_rpkm", "gene_length_bp"])
    sub = sub[sub["gene_length_bp"] > 0].copy()
    n_obs = len(sub)
    n_pos = int(sub["y"].sum())

    if n_pos < 3 or (sub["y"] & sub[target_col].astype(bool)).sum() == 0:
        return {
            "logit_n": n_obs,
            "logit_n_pos": n_pos,
            "logit_adj_or": np.nan,
            "logit_adj_ci_low": np.nan,
            "logit_adj_ci_high": np.nan,
            "logit_wald_z": np.nan,
            "logit_p": np.nan,
            "logit_cov_expr_or": np.nan,
            "logit_cov_expr_p": np.nan,
            "logit_cov_len_or": np.nan,
            "logit_cov_len_p": np.nan,
            "logit_converged": False,
        }

    X = pd.DataFrame(
        {
            "const": 1.0,
            "target": sub[target_col].astype(float).values,
            "mean_log2_rpkm": sub["mean_log2_rpkm"].astype(float).values,
            "log10_gene_length": np.log10(sub["gene_length_bp"].astype(float).values),
        }
    )
    y = sub["y"].values

    try:
        model = sm.Logit(y, X)
        fit = model.fit(disp=False, maxiter=200)
        converged = bool(fit.mle_retvals.get("converged", True))
        b_t = float(fit.params["target"])
        se_t = float(fit.bse["target"])
        z_t = float(fit.tvalues["target"])
        p_t = float(fit.pvalues["target"])
        ci_low = math.exp(b_t - 1.959963984540054 * se_t)
        ci_high = math.exp(b_t + 1.959963984540054 * se_t)
        return {
            "logit_n": n_obs,
            "logit_n_pos": n_pos,
            "logit_adj_or": math.exp(b_t),
            "logit_adj_ci_low": ci_low,
            "logit_adj_ci_high": ci_high,
            "logit_wald_z": z_t,
            "logit_p": p_t,
            "logit_cov_expr_or": math.exp(float(fit.params["mean_log2_rpkm"])),
            "logit_cov_expr_p": float(fit.pvalues["mean_log2_rpkm"]),
            "logit_cov_len_or": math.exp(float(fit.params["log10_gene_length"])),
            "logit_cov_len_p": float(fit.pvalues["log10_gene_length"]),
            "logit_converged": converged,
        }
    except Exception:
        return {
            "logit_n": n_obs,
            "logit_n_pos": n_pos,
            "logit_adj_or": np.nan,
            "logit_adj_ci_low": np.nan,
            "logit_adj_ci_high": np.nan,
            "logit_wald_z": np.nan,
            "logit_p": np.nan,
            "logit_cov_expr_or": np.nan,
            "logit_cov_expr_p": np.nan,
            "logit_cov_len_or": np.nan,
            "logit_cov_len_p": np.nan,
            "logit_converged": False,
        }


def stratified_permutation_enrichment(
    target_mask: np.ndarray,
    risk_mask: np.ndarray,
    expr_vals: np.ndarray,
    len_vals: np.ndarray,
    n_perm: int = N_PERM,
    seed: int = SEED,
) -> Dict[str, float]:
    """
    Stratified permutation test preserving joint expression-decile x length-quintile
    distribution of the target set, testing overlap with risk_mask.
    """
    valid = np.isfinite(expr_vals) & np.isfinite(len_vals) & (len_vals > 0)
    t = target_mask[valid].astype(bool)
    r = risk_mask[valid].astype(bool)
    e = expr_vals[valid]
    l = np.log10(len_vals[valid])

    e_bins = pd.qcut(e, q=10, labels=False, duplicates="drop")
    l_bins = pd.qcut(l, q=5, labels=False, duplicates="drop")
    strata = e_bins * 10 + l_bins

    obs_overlap = int((t & r).sum())
    rng = np.random.default_rng(seed)

    # Pre-group indices and target counts per stratum
    stratum_data = []
    for s in np.unique(strata):
        idx = np.where(strata == s)[0]
        k = int(t[idx].sum())
        if k > 0 and len(idx) > k:
            stratum_data.append((r[idx].astype(np.int8), k, len(idx)))
        elif k > 0 and len(idx) == k:
            # All genes in stratum are targets -> deterministic contribution
            stratum_data.append((r[idx].astype(np.int8), k, len(idx)))

    perm_overlaps = np.zeros(n_perm, dtype=np.int32)
    for r_arr, k, n_s in stratum_data:
        if k == n_s:
            perm_overlaps += int(r_arr.sum())
        else:
            # Vectorized sampling via random scores or per-stratum sampling
            # Since n_perm=10,000 and ~50 strata, hypergeometric draw exact for binary r_arr!
            n_pos = int(r_arr.sum())
            n_neg = n_s - n_pos
            if n_pos > 0:
                perm_overlaps += rng.hypergeometric(n_pos, n_neg, k, size=n_perm)

    exp_overlap = float(perm_overlaps.mean())
    perm_or_approx = obs_overlap / exp_overlap if exp_overlap > 0 else np.nan
    # Two-sided empirical p around expected mean
    obs_dev = abs(obs_overlap - exp_overlap)
    perm_dev = np.abs(perm_overlaps - exp_overlap)
    p_emp_two = float((1 + np.sum(perm_dev >= obs_dev - 1e-12)) / (n_perm + 1))
    p_emp_one_hi = float((1 + np.sum(perm_overlaps >= obs_overlap)) / (n_perm + 1))
    return {
        "perm_obs_overlap": obs_overlap,
        "perm_exp_overlap": exp_overlap,
        "perm_fold_enrichment": float(perm_or_approx),
        "perm_p_two_sided": p_emp_two,
        "perm_p_one_sided_hi": p_emp_one_hi,
    }


def build_risk_masks(
    df: pd.DataFrame, der14_raw: pd.DataFrame
) -> Tuple[Dict[str, Tuple[str, np.ndarray]], Dict[str, Tuple[str, np.ndarray]]]:
    """
    Construct genetic/synaptic risk sets and PsychENCODE postmortem risk sets.
    Returns (genetic_sets, psychencode_sets) mapping name -> (domain, boolean_mask).
    """
    sfari1 = df["sfari_score"] == 1.0
    sfari12 = df["sfari_score"].isin([1.0, 2.0])
    sfari_all = df["is_sfari"] == True

    fu185 = df["fu22_ASD185"] == 1.0
    fu72 = df["fu22_ASD72"] == 1.0
    fu_fdr05 = df["fu22_FDR_TADA_ASD"] < 0.05
    fu_fdr10 = df["fu22_FDR_TADA_ASD"] < 0.10
    fu_dd477 = df["fu22_DD477"] == 1.0
    fu_ndd664 = df["fu22_NDD664"] == 1.0

    schema_001 = df["schema_P_meta"] < 0.001
    schema_01 = df["schema_P_meta"] < 0.01
    schema_05 = df["schema_P_meta"] < 0.05

    # Exact top 200 and top 300 by schema_P_meta within the evaluated dataframe
    schema_p_valid = df["schema_P_meta"].dropna()
    top200_thresh = schema_p_valid.nsmallest(200).max() if len(schema_p_valid) >= 200 else np.inf
    top300_thresh = schema_p_valid.nsmallest(300).max() if len(schema_p_valid) >= 300 else np.inf
    schema_top200 = df["schema_P_meta"].notna() & (df["schema_P_meta"] <= top200_thresh)
    schema_top300 = df["schema_P_meta"].notna() & (df["schema_P_meta"] <= top300_thresh)

    ot_scz_20 = df["ot_scz_genetic_association"] >= 0.20
    ot_scz_15 = df["ot_scz_genetic_association"] >= 0.15
    ot_scz_10 = df["ot_scz_genetic_association"] >= 0.10
    ot_asd_20 = df["ot_asd_genetic_association"] >= 0.20
    ot_asd_10 = df["ot_asd_genetic_association"] >= 0.10

    syngo_all = df["is_syngo"] == True
    syngo_pre = df["is_syngo_presynapse"] == True
    syngo_post = df["is_syngo_postsynapse"] == True

    shared_sfari12_schema05 = sfari12 & schema_05
    shared_sfari12_sczcomb = sfari12 & (schema_05 | ot_scz_15)
    shared_asdcomb_sczcomb = (sfari12 | fu185) & (schema_05 | ot_scz_15)

    int17_scz = (df["is_int17_scz_hc"] == True) if "is_int17_scz_hc" in df.columns else pd.Series(False, index=df.index)
    scz_comb_int17 = schema_05 | ot_scz_15 | int17_scz
    shared_sfari12_int17 = sfari12 & int17_scz
    shared_sfari12_sczcomb_int17 = sfari12 & scz_comb_int17

    genetic_sets = {
        "SFARI_Score1": ("ASD_genetic", sfari1.values),
        "SFARI_Score1_2": ("ASD_genetic", sfari12.values),
        "SFARI_All": ("ASD_genetic", sfari_all.values),
        "Fu22_ASD72": ("ASD_genetic", fu72.values),
        "Fu22_ASD185": ("ASD_genetic", fu185.values),
        "Fu22_FDR_lt_0.05": ("ASD_genetic", fu_fdr05.values),
        "Fu22_FDR_lt_0.10": ("ASD_genetic", fu_fdr10.values),
        "Fu22_DD477": ("NDD_genetic", fu_dd477.values),
        "Fu22_NDD664": ("NDD_genetic", fu_ndd664.values),
        "OT_ASD_gen_ge_0.20": ("ASD_genetic", ot_asd_20.values),
        "OT_ASD_gen_ge_0.10": ("ASD_genetic", ot_asd_10.values),
        "SCHEMA_P_lt_0.001": ("SCZ_genetic", schema_001.values),
        "SCHEMA_P_lt_0.01": ("SCZ_genetic", schema_01.values),
        "SCHEMA_P_lt_0.05": ("SCZ_genetic", schema_05.values),
        "SCHEMA_top200": ("SCZ_genetic", schema_top200.values),
        "SCHEMA_top300": ("SCZ_genetic", schema_top300.values),
        "OT_SCZ_gen_ge_0.20": ("SCZ_genetic", ot_scz_20.values),
        "OT_SCZ_gen_ge_0.15": ("SCZ_genetic", ot_scz_15.values),
        "OT_SCZ_gen_ge_0.10": ("SCZ_genetic", ot_scz_10.values),
        "INT17_SCZ_HC": ("SCZ_genetic", int17_scz.values),
        "SCZ_combined_SCHEMA05_or_OT15": ("SCZ_genetic", (schema_05 | ot_scz_15).values),
        "SCZ_combined_SCHEMA05_OT15_INT17": ("SCZ_genetic", scz_comb_int17.values),
        "SynGO_all": ("Synaptic", syngo_all.values),
        "SynGO_presynapse": ("Synaptic", syngo_pre.values),
        "SynGO_postsynapse": ("Synaptic", syngo_post.values),
        "Shared_SFARI12_and_SCHEMA05": ("Shared_ASD_SCZ", shared_sfari12_schema05.values),
        "Shared_SFARI12_and_SCZcomb": ("Shared_ASD_SCZ", shared_sfari12_sczcomb.values),
        "Shared_SFARI12_and_INT17": ("Shared_ASD_SCZ", shared_sfari12_int17.values),
        "Shared_SFARI12_and_SCZcomb_INT17": ("Shared_ASD_SCZ", shared_sfari12_sczcomb_int17.values),
        "Shared_ASDcomb_and_SCZcomb": ("Shared_ASD_SCZ", shared_asdcomb_sczcomb.values),
    }

    # Exact raw DER-14 transcript-level gene sets (handles genes with both up & down transcripts)
    der14 = der14_raw.copy()
    der14["Disorder"] = der14["Disorder.DTE_RegulationDirection"].str.split(".").str[0]
    der14["Direction"] = der14["Disorder.DTE_RegulationDirection"].str.split("_").str[1]
    ens = df["ensembl_gene_id"]

    asd_dte_up_raw = ens.isin(set(der14[(der14["Disorder"] == "ASD") & (der14["Direction"] == "up")]["Ensembl_Gene"])).values
    asd_dte_dn_raw = ens.isin(set(der14[(der14["Disorder"] == "ASD") & (der14["Direction"] == "down")]["Ensembl_Gene"])).values
    scz_dte_up_raw = ens.isin(set(der14[(der14["Disorder"] == "SCZ") & (der14["Direction"] == "up")]["Ensembl_Gene"])).values
    scz_dte_dn_raw = ens.isin(set(der14[(der14["Disorder"] == "SCZ") & (der14["Direction"] == "down")]["Ensembl_Gene"])).values
    bd_dte_up_raw = ens.isin(set(der14[(der14["Disorder"] == "BD") & (der14["Direction"] == "up")]["Ensembl_Gene"])).values
    bd_dte_dn_raw = ens.isin(set(der14[(der14["Disorder"] == "BD") & (der14["Direction"] == "down")]["Ensembl_Gene"])).values

    psychencode_sets = {
        "PE_ASD_DGE_up": ("PsychENCODE_DGE", (df["psychencode_ASD_DGE"] == "up").values),
        "PE_ASD_DGE_down": ("PsychENCODE_DGE", (df["psychencode_ASD_DGE"] == "down").values),
        "PE_ASD_DGE_any": ("PsychENCODE_DGE", df["psychencode_ASD_DGE"].isin(["up", "down"]).values),
        "PE_SCZ_DGE_up": ("PsychENCODE_DGE", (df["psychencode_SCZ_DGE"] == "up").values),
        "PE_SCZ_DGE_down": ("PsychENCODE_DGE", (df["psychencode_SCZ_DGE"] == "down").values),
        "PE_SCZ_DGE_any": ("PsychENCODE_DGE", df["psychencode_SCZ_DGE"].isin(["up", "down"]).values),
        "PE_BD_DGE_up": ("PsychENCODE_DGE", (df["psychencode_BD_DGE"] == "up").values),
        "PE_BD_DGE_down": ("PsychENCODE_DGE", (df["psychencode_BD_DGE"] == "down").values),
        "PE_BD_DGE_any": ("PsychENCODE_DGE", df["psychencode_BD_DGE"].isin(["up", "down"]).values),
        "PE_ASD_DTE_up_raw": ("PsychENCODE_DTE", asd_dte_up_raw),
        "PE_ASD_DTE_down_raw": ("PsychENCODE_DTE", asd_dte_dn_raw),
        "PE_ASD_DTE_any_raw": ("PsychENCODE_DTE", asd_dte_up_raw | asd_dte_dn_raw),
        "PE_SCZ_DTE_up_raw": ("PsychENCODE_DTE", scz_dte_up_raw),
        "PE_SCZ_DTE_down_raw": ("PsychENCODE_DTE", scz_dte_dn_raw),
        "PE_SCZ_DTE_any_raw": ("PsychENCODE_DTE", scz_dte_up_raw | scz_dte_dn_raw),
        "PE_BD_DTE_up_raw": ("PsychENCODE_DTE", bd_dte_up_raw),
        "PE_BD_DTE_down_raw": ("PsychENCODE_DTE", bd_dte_dn_raw),
        "PE_BD_DTE_any_raw": ("PsychENCODE_DTE", bd_dte_up_raw | bd_dte_dn_raw),
        "PE_ASD_DTE_up_harm": ("PsychENCODE_DTE_harm", (df["psychencode_ASD_DTE"] == "up").values),
        "PE_ASD_DTE_down_harm": ("PsychENCODE_DTE_harm", (df["psychencode_ASD_DTE"] == "down").values),
        "PE_SCZ_DTE_up_harm": ("PsychENCODE_DTE_harm", (df["psychencode_SCZ_DTE"] == "up").values),
        "PE_SCZ_DTE_down_harm": ("PsychENCODE_DTE_harm", (df["psychencode_SCZ_DTE"] == "down").values),
        "PE_ASD_DS_leaf": ("PsychENCODE_DS", (df["psychencode_ASD_DS"] == True).values),
        "PE_SCZ_DS_leaf": ("PsychENCODE_DS", (df["psychencode_SCZ_DS"] == True).values),
        "PE_BD_DS_leaf": ("PsychENCODE_DS", (df["psychencode_BD_DS"] == True).values),
    }

    return genetic_sets, psychencode_sets


def run_analysis_1(
    univ: pd.DataFrame, der14_raw: pd.DataFrame
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Analysis 1: CPEB4 targetome enrichment across ASD, SCZ, SynGO, and PsychENCODE sets.
    """
    print("\n=== Running Analysis 1: CPEB4 Targetome Enrichment ===")
    universes = {
        "protein_coding_primary": univ[
            (univ["is_primary_symbol_row"] == True) & (univ["gene_biotype"] == "protein_coding")
        ].copy(),
        "protein_coding_brain_expr": univ[
            (univ["is_primary_symbol_row"] == True)
            & (univ["gene_biotype"] == "protein_coding")
            & (univ["max_rpkm"] >= 1.0)
        ].copy(),
        "all_primary_symbols": univ[univ["is_primary_symbol_row"] == True].copy(),
    }

    target_cols = [
        ("parras18_cpeb4_binder", "CPEB4_binder"),
        ("parras18_polya_shortened_hd", "PolyA_shortened_HD"),
    ]

    rows = []
    for u_name, df_u in universes.items():
        gen_sets, pe_sets = build_risk_masks(df_u, der14_raw)
        all_sets = {**gen_sets, **pe_sets}

        for t_col, t_label in target_cols:
            t_mask = (df_u[t_col] == True).values
            for r_name, (r_domain, r_mask) in all_sets.items():
                a = int(np.sum(t_mask & r_mask))
                b = int(np.sum(t_mask & (~r_mask)))
                c = int(np.sum((~t_mask) & r_mask))
                d = int(np.sum((~t_mask) & (~r_mask)))

                f_res = fisher_with_ci(a, b, c, d)
                l_res = covariate_logit(df_u, t_col, r_mask)

                # Run stratified permutation on primary pc universe for genetic/synaptic + key PE sets
                if u_name == "protein_coding_primary" and t_label == "CPEB4_binder":
                    p_res = stratified_permutation_enrichment(
                        t_mask,
                        r_mask,
                        df_u["mean_log2_rpkm"].values,
                        df_u["gene_length_bp"].values,
                        n_perm=N_PERM,
                        seed=SEED,
                    )
                else:
                    p_res = {
                        "perm_obs_overlap": np.nan,
                        "perm_exp_overlap": np.nan,
                        "perm_fold_enrichment": np.nan,
                        "perm_p_two_sided": np.nan,
                        "perm_p_one_sided_hi": np.nan,
                    }

                family_group = "PsychENCODE" if r_domain.startswith("PsychENCODE") else "Genetic_Synaptic"
                rows.append(
                    {
                        "universe": u_name,
                        "n_universe": len(df_u),
                        "target_set": t_label,
                        "risk_set": r_name,
                        "domain": r_domain,
                        "family_group": family_group,
                        "a_target_and_risk": a,
                        "b_target_only": b,
                        "c_risk_only": c,
                        "d_neither": d,
                        "n_target": a + b,
                        "n_risk": a + c,
                        "pct_risk_in_target": 100.0 * a / (a + c) if (a + c) > 0 else np.nan,
                        "pct_target_in_risk": 100.0 * a / (a + b) if (a + b) > 0 else np.nan,
                        **f_res,
                        **l_res,
                        **p_res,
                    }
                )

    res_df = pd.DataFrame(rows)
    # Apply BH-FDR within (universe, target_set, family_group)
    res_df["bh_fdr_fisher"] = np.nan
    res_df["bh_fdr_logit"] = np.nan
    for (u_name, t_label, f_grp), idx in res_df.groupby(
        ["universe", "target_set", "family_group"]
    ).groups.items():
        res_df.loc[idx, "bh_fdr_fisher"] = bh_fdr(res_df.loc[idx, "fisher_p"].values)
        res_df.loc[idx, "bh_fdr_logit"] = bh_fdr(res_df.loc[idx, "logit_p"].values)

    # Also compute overall BH-FDR within (universe, target_set) across all tests
    res_df["bh_fdr_fisher_all"] = np.nan
    res_df["bh_fdr_logit_all"] = np.nan
    for (u_name, t_label), idx in res_df.groupby(["universe", "target_set"]).groups.items():
        res_df.loc[idx, "bh_fdr_fisher_all"] = bh_fdr(res_df.loc[idx, "fisher_p"].values)
        res_df.loc[idx, "bh_fdr_logit_all"] = bh_fdr(res_df.loc[idx, "logit_p"].values)

    out_path = RESULTS_DIR / "enrichment_table.csv"
    res_df.to_csv(out_path, index=False)
    print(f"Saved enrichment table ({len(res_df)} rows) to {out_path}")

    # Extract concise summary for JSON
    pc_bind = res_df[
        (res_df["universe"] == "protein_coding_primary")
        & (res_df["target_set"] == "CPEB4_binder")
    ]
    pc_polya = res_df[
        (res_df["universe"] == "protein_coding_primary")
        & (res_df["target_set"] == "PolyA_shortened_HD")
    ]
    summary = {
        "n_pc_primary": int(len(universes["protein_coding_primary"])),
        "n_pc_brain_expr": int(len(universes["protein_coding_brain_expr"])),
        "n_all_primary": int(len(universes["all_primary_symbols"])),
        "n_cpeb4_binders_pc": int(universes["protein_coding_primary"]["parras18_cpeb4_binder"].sum()),
        "n_polya_shortened_pc": int(universes["protein_coding_primary"]["parras18_polya_shortened_hd"].sum()),
        "key_pc_binder_results": pc_bind[
            [
                "risk_set",
                "a_target_and_risk",
                "n_risk",
                "fisher_or",
                "woolf_ci_low",
                "woolf_ci_high",
                "fisher_p",
                "bh_fdr_fisher",
                "logit_adj_or",
                "logit_adj_ci_low",
                "logit_adj_ci_high",
                "logit_wald_z",
                "logit_p",
                "bh_fdr_logit",
                "perm_fold_enrichment",
                "perm_p_two_sided",
            ]
        ].to_dict(orient="records"),
        "key_pc_polya_results": pc_polya[
            [
                "risk_set",
                "a_target_and_risk",
                "n_risk",
                "fisher_or",
                "woolf_ci_low",
                "woolf_ci_high",
                "fisher_p",
                "bh_fdr_fisher",
                "logit_adj_or",
                "logit_adj_ci_low",
                "logit_adj_ci_high",
                "logit_wald_z",
                "logit_p",
                "bh_fdr_logit",
            ]
        ].to_dict(orient="records"),
    }
    return res_df, summary


def compare_two_groups_timing(
    vals: np.ndarray,
    expr_deciles: np.ndarray,
    len_quintiles: np.ndarray,
    mask_a: np.ndarray,
    mask_b: np.ndarray,
    pool_mask: np.ndarray,
    label_a: str,
    label_b: str,
    metric_name: str,
    contrast_family: str,
    n_perm: int = N_PERM,
    n_boot: int = N_BOOT,
    seed: int = SEED,
    do_joint_perm: bool = False,
) -> Dict[str, Any]:
    """
    Compare timing values between group A (e.g., T_SCZ_only) and group B (e.g., T_ASD_only):
    - Descriptive stats (n, mean, sd, median, q25, q75)
    - Mann-Whitney U, two-sided P, rank-biserial correlation r
    - Welch t-test, exact Welch-Satterthwaite df, two-sided P, Cohen's d
    - Bootstrap 95% CI (mean diff and median diff)
    - B=10,000 expression-decile-matched permutation test (sampling from pool_mask)
    - Optional joint expression-decile x length-quintile permutation test
    """
    valid = np.isfinite(vals)
    ma = mask_a & valid
    mb = mask_b & valid
    mp = pool_mask & valid

    xa = vals[ma]
    xb = vals[mb]
    na, nb = len(xa), len(xb)

    if na < 3 or nb < 3:
        return {
            "contrast_family": contrast_family,
            "metric": metric_name,
            "group_a": label_a,
            "group_b": label_b,
            "n_a": na,
            "n_b": nb,
            "mean_a": np.nan,
            "mean_b": np.nan,
        }

    mean_a, sd_a = float(np.mean(xa)), float(np.std(xa, ddof=1))
    mean_b, sd_b = float(np.mean(xb)), float(np.std(xb, ddof=1))
    med_a, q25_a, q75_a = float(np.median(xa)), float(np.percentile(xa, 25)), float(np.percentile(xa, 75))
    med_b, q25_b, q75_b = float(np.median(xb)), float(np.percentile(xb, 25)), float(np.percentile(xb, 75))

    diff_mean = mean_a - mean_b
    diff_med = med_a - med_b

    # Mann-Whitney U
    u_stat, mw_p = stats.mannwhitneyu(xa, xb, alternative="two-sided")
    # Rank-biserial r = 2*U/(na*nb) - 1 (positive means A > B)
    rb_r = float(2.0 * u_stat / (na * nb) - 1.0)

    # Welch t-test + exact Welch-Satterthwaite df
    t_stat, t_p = stats.ttest_ind(xa, xb, equal_var=False, alternative="two-sided")
    va = np.var(xa, ddof=1) / na
    vb = np.var(xb, ddof=1) / nb
    welch_df = float((va + vb) ** 2 / ((va ** 2) / (na - 1) + (vb ** 2) / (nb - 1))) if (va + vb) > 0 else np.nan
    pooled_sd = math.sqrt(((na - 1) * sd_a ** 2 + (nb - 1) * sd_b ** 2) / (na + nb - 2))
    cohens_d = float(diff_mean / pooled_sd) if pooled_sd > 0 else np.nan

    # Bootstrap 95% CI
    rng = np.random.default_rng(seed)
    idx_a = rng.integers(0, na, size=(n_boot, na))
    idx_b = rng.integers(0, nb, size=(n_boot, nb))
    boot_a = xa[idx_a]
    boot_b = xb[idx_b]
    boot_mean_diffs = boot_a.mean(axis=1) - boot_b.mean(axis=1)
    boot_med_diffs = np.median(boot_a, axis=1) - np.median(boot_b, axis=1)
    boot_mean_ci_low, boot_mean_ci_high = np.percentile(boot_mean_diffs, [2.5, 97.5])
    boot_med_ci_low, boot_med_ci_high = np.percentile(boot_med_diffs, [2.5, 97.5])

    # B=10,000 expression-decile-matched permutation test
    # Within pool_mask, match decile counts of group A and group B independently (with non-overlapping draws?
    # Better: draw stratified sets of size na and nb matching decile profiles of A and B from pool_mask).
    # For disjoint comparison, we also sample without replacement from pool within each decile if possible,
    # or with replacement if decile demand > supply; let's check pool sizes and draw without replacement across A+B
    # when stratum_size >= k_a + k_b!
    def run_stratified_perm(strata_arr: np.ndarray) -> Tuple[float, float, float, float]:
        sa_counts = np.bincount(strata_arr[ma], minlength=100)
        sb_counts = np.bincount(strata_arr[mb], minlength=100)
        active_strata = np.where((sa_counts + sb_counts) > 0)[0]

        sum_a = np.zeros(n_perm, dtype=np.float64)
        sum_b = np.zeros(n_perm, dtype=np.float64)

        for s in active_strata:
            ka = int(sa_counts[s])
            kb = int(sb_counts[s])
            pool_idx = np.where(mp & (strata_arr == s))[0]
            if len(pool_idx) == 0:
                continue
            pool_vals = vals[pool_idx]
            n_pool = len(pool_vals)
            # Vectorized sampling per stratum
            if n_pool >= ka + kb:
                # Sample ka+kb without replacement per perm using random argsort on small array or choice
                # Fast & exact: draw random floats (n_perm, n_pool) and argpartition if n_pool <= 500
                rand_mat = rng.random((n_perm, n_pool))
                part = np.argpartition(rand_mat, ka + kb - 1, axis=1)
                if ka > 0:
                    sum_a += pool_vals[part[:, :ka]].sum(axis=1)
                if kb > 0:
                    sum_b += pool_vals[part[:, ka : ka + kb]].sum(axis=1)
            else:
                if ka > 0:
                    draws_a = rng.integers(0, n_pool, size=(n_perm, ka))
                    sum_a += pool_vals[draws_a].sum(axis=1)
                if kb > 0:
                    draws_b = rng.integers(0, n_pool, size=(n_perm, kb))
                    sum_b += pool_vals[draws_b].sum(axis=1)

        perm_diffs = (sum_a / na) - (sum_b / nb)
        p_two = float((1 + np.sum(np.abs(perm_diffs) >= abs(diff_mean) - 1e-12)) / (n_perm + 1))
        p_one = float((1 + np.sum(perm_diffs >= diff_mean - 1e-12)) / (n_perm + 1))
        return float(perm_diffs.mean()), float(perm_diffs.std(ddof=1)), p_two, p_one

    perm_mean, perm_sd, perm_p_two, perm_p_one = run_stratified_perm(expr_deciles)

    if do_joint_perm:
        joint_strata = expr_deciles * 10 + len_quintiles
        _, _, joint_p_two, joint_p_one = run_stratified_perm(joint_strata)
    else:
        joint_p_two, joint_p_one = np.nan, np.nan

    return {
        "contrast_family": contrast_family,
        "metric": metric_name,
        "group_a": label_a,
        "group_b": label_b,
        "n_a": int(na),
        "n_b": int(nb),
        "mean_a": mean_a,
        "sd_a": sd_a,
        "median_a": med_a,
        "q25_a": q25_a,
        "q75_a": q75_a,
        "mean_b": mean_b,
        "sd_b": sd_b,
        "median_b": med_b,
        "q25_b": q25_b,
        "q75_b": q75_b,
        "mean_diff_a_minus_b": float(diff_mean),
        "median_diff_a_minus_b": float(diff_med),
        "boot_mean_diff_ci_low": float(boot_mean_ci_low),
        "boot_mean_diff_ci_high": float(boot_mean_ci_high),
        "boot_med_diff_ci_low": float(boot_med_ci_low),
        "boot_med_diff_ci_high": float(boot_med_ci_high),
        "mannwhitney_u": float(u_stat),
        "mannwhitney_p": float(mw_p),
        "rank_biserial_r": rb_r,
        "welch_t": float(t_stat),
        "welch_df": welch_df,
        "welch_p": float(t_p),
        "cohens_d": cohens_d,
        "perm_expr_matched_null_mean": perm_mean,
        "perm_expr_matched_null_sd": perm_sd,
        "perm_expr_matched_p_two_sided": perm_p_two,
        "perm_expr_matched_p_one_sided_a_gt_b": perm_p_one,
        "perm_expr_len_matched_p_two_sided": joint_p_two,
        "perm_expr_len_matched_p_one_sided_a_gt_b": joint_p_one,
    }


def compute_timing_metrics(
    mat: np.ndarray, meta: pd.DataFrame
) -> pd.DataFrame:
    """
    Compute gene-wise Z-scores and Developmental Timing Shift Index (dZ) and
    expression-weighted developmental age (tau*) across BrainSpan samples.
    """
    age_pcw = meta["age_pcw"].values
    log2_pcw = meta["log2_pcw"].values
    is_pfc = meta["is_pfc"].values
    is_neo = meta["is_neocortex"].values
    is_prenatal = meta["is_prenatal"].values

    # Window masks
    w1_prim = (age_pcw >= 12.0) & (age_pcw <= 142.3)
    w2_prim = (age_pcw >= 663.7) & (age_pcw <= 1341.5)

    w1_sensA = is_prenatal.astype(bool)  # 8-37 pcw
    w2_sensA = age_pcw >= 663.7          # 12-40 yrs

    w1_sensB = (age_pcw >= 40.0) & (age_pcw <= 250.0)   # 0-4 yrs (4 mos - 4 yrs)
    w2_sensB = (age_pcw >= 663.7) & (age_pcw <= 1050.0) # 12-19 yrs

    def calc_subset_metrics(sample_mask: np.ndarray, prefix: str) -> Dict[str, np.ndarray]:
        sub_mat = mat[:, sample_mask].astype(np.float64)
        mu = sub_mat.mean(axis=1, keepdims=True)
        sd = sub_mat.std(axis=1, ddof=0, keepdims=True)
        valid_sd = (sd[:, 0] > 1e-8)

        z = np.full_like(sub_mat, np.nan)
        z[valid_sd] = (sub_mat[valid_sd] - mu[valid_sd]) / sd[valid_sd]

        sub_w1_p = w1_prim[sample_mask]
        sub_w2_p = w2_prim[sample_mask]
        sub_w1_a = w1_sensA[sample_mask]
        sub_w2_a = w2_sensA[sample_mask]
        sub_w1_b = w1_sensB[sample_mask]
        sub_w2_b = w2_sensB[sample_mask]
        sub_l2age = log2_pcw[sample_mask]

        dz_prim = z[:, sub_w2_p].mean(axis=1) - z[:, sub_w1_p].mean(axis=1)
        dz_sensA = z[:, sub_w2_a].mean(axis=1) - z[:, sub_w1_a].mean(axis=1)
        dz_sensB = z[:, sub_w2_b].mean(axis=1) - z[:, sub_w1_b].mean(axis=1)

        # Continuous expression-weighted mean developmental age tau*
        w_sum = sub_mat.sum(axis=1)
        tau_star = np.where(
            w_sum > 1e-8,
            (sub_mat * sub_l2age[None, :]).sum(axis=1) / np.where(w_sum > 1e-8, w_sum, 1.0),
            np.nan,
        )

        # Rank-weighted tau* (using sample ranks of expression per gene)
        ranks = np.apply_along_axis(stats.rankdata, 1, sub_mat)
        ranks_valid = np.where(valid_sd[:, None], ranks, np.nan)
        r_sum = np.nansum(ranks_valid, axis=1)
        tau_rank = np.where(
            valid_sd & (r_sum > 0),
            np.nansum(ranks_valid * sub_l2age[None, :], axis=1) / np.where(r_sum > 0, r_sum, 1.0),
            np.nan,
        )

        # Spearman rho with log2_pcw (fast vectorized via rankdata)
        age_ranks = stats.rankdata(sub_l2age)
        age_c = age_ranks - age_ranks.mean()
        age_norm = np.sqrt(np.sum(age_c ** 2))
        r_c = ranks_valid - np.nanmean(ranks_valid, axis=1, keepdims=True)
        r_norm = np.sqrt(np.nansum(r_c ** 2, axis=1))
        rho = np.where(
            valid_sd & (r_norm > 0),
            np.nansum(r_c * age_c[None, :], axis=1) / (np.where(r_norm > 0, r_norm, 1.0) * age_norm),
            np.nan,
        )

        return {
            f"dZ_{prefix}_primary": dz_prim,
            f"dZ_{prefix}_sensA_fetal_adoladult": dz_sensA,
            f"dZ_{prefix}_sensB_infchild_adol": dz_sensB,
            f"tau_star_{prefix}": tau_star,
            f"tau_rank_{prefix}": tau_rank,
            f"spearman_rho_{prefix}": rho,
        }

    all_m = calc_subset_metrics(np.ones(len(meta), dtype=bool), "all")
    pfc_m = calc_subset_metrics(is_pfc.astype(bool), "pfc")
    neo_m = calc_subset_metrics(is_neo.astype(bool), "neo")

    out = pd.DataFrame({**all_m, **pfc_m, **neo_m})
    return out


def run_analysis_2(
    univ: pd.DataFrame, meta: pd.DataFrame, mat: np.ndarray, traj: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    """
    Analysis 2: Developmental temporal segregation in BrainSpan + regulator/module trajectories.
    """
    print("\n=== Running Analysis 2: BrainSpan Developmental Timing Segregation ===")
    timing_all = compute_timing_metrics(mat, meta)
    df = pd.concat([univ.reset_index(drop=True), timing_all.reset_index(drop=True)], axis=1)

    # Filter to primary protein-coding brain-expressed (max_rpkm >= 1.0)
    pc_mask = (df["is_primary_symbol_row"] == True) & (df["gene_biotype"] == "protein_coding")
    brain_expr_mask = pc_mask & (df["max_rpkm"] >= 1.0)
    df_be = df[brain_expr_mask].copy().reset_index(drop=True)

    # Precompute expression deciles and length quintiles within brain-expressed pc genes
    expr_dec = pd.qcut(df_be["mean_log2_rpkm"], q=10, labels=False, duplicates="drop").values.astype(int)
    len_quin = pd.qcut(np.log10(df_be["gene_length_bp"]), q=5, labels=False, duplicates="drop").values.astype(int)

    is_binder = (df_be["parras18_cpeb4_binder"] == True).values
    is_polya = (df_be["parras18_polya_shortened_hd"] == True).values

    # Define risk definitions (ASD vs SCZ)
    sfari12 = df_be["sfari_score"].isin([1.0, 2.0]).values
    fu185 = (df_be["fu22_ASD185"] == 1.0).values
    schema05 = (df_be["schema_P_meta"] < 0.05).values
    ot_scz15 = (df_be["ot_scz_genetic_association"] >= 0.15).values
    int17 = (df_be["is_int17_scz_hc"] == True).values if "is_int17_scz_hc" in df_be.columns else np.zeros(len(df_be), dtype=bool)
    scz_comb = schema05 | ot_scz15
    scz_comb_int17 = schema05 | ot_scz15 | int17

    p_valid = df_be["schema_P_meta"].dropna()
    top250_t = p_valid.nsmallest(250).max()
    top500_t = p_valid.nsmallest(500).max()
    schema_top250 = (df_be["schema_P_meta"].notna() & (df_be["schema_P_meta"] <= top250_t)).values
    schema_top500 = (df_be["schema_P_meta"].notna() & (df_be["schema_P_meta"] <= top500_t)).values

    risk_defs = {
        "DefA_SFARI12_vs_SCZcomb": (sfari12, scz_comb),
        "DefB_SFARI12_vs_SCHEMA05": (sfari12, schema05),
        "DefC_Fu185_vs_SCHEMA05": (fu185, schema05),
        "DefD_SFARI12_vs_OT_SCZ15": (sfari12, ot_scz15),
        "DefE_SFARI12_vs_SCHEMA_top250": (sfari12, schema_top250),
        "DefF_SFARI12_vs_SCHEMA_top500": (sfari12, schema_top500),
        "DefG_SFARI12_vs_INT17": (sfari12, int17),
        "DefH_SFARI12_vs_SCZcomb_INT17": (sfari12, scz_comb_int17),
    }

    # Add disjoint labels for DefA and DefB to gene-level table
    for def_key in ["DefA_SFARI12_vs_SCZcomb", "DefB_SFARI12_vs_SCHEMA05"]:
        a_m, s_m = risk_defs[def_key]
        lbl = np.where(
            a_m & s_m,
            "Shared",
            np.where(a_m, "ASD_only", np.where(s_m, "SCZ_only", "Other")),
        )
        df_be[f"disjoint_all_{def_key}"] = lbl
        df_be[f"disjoint_cpeb4_{def_key}"] = np.where(is_binder, "T_" + lbl, "Non_CPEB4")

    metrics_to_test = [
        "dZ_all_primary",
        "dZ_pfc_primary",
        "dZ_neo_primary",
        "dZ_all_sensA_fetal_adoladult",
        "dZ_pfc_sensA_fetal_adoladult",
        "dZ_all_sensB_infchild_adol",
        "dZ_pfc_sensB_infchild_adol",
        "tau_star_all",
        "tau_star_pfc",
        "tau_rank_all",
        "tau_rank_pfc",
    ]

    disjoint_counts = []
    timing_tests = []

    for def_name, (asd_m, scz_m) in risk_defs.items():
        t_asd = is_binder & asd_m & (~scz_m)
        t_scz = is_binder & (~asd_m) & scz_m
        t_shr = is_binder & asd_m & scz_m
        t_oth = is_binder & (~asd_m) & (~scz_m)

        all_asd = asd_m & (~scz_m)
        all_scz = (~asd_m) & scz_m
        all_shr = asd_m & scz_m
        all_oth = (~asd_m) & (~scz_m)

        disjoint_counts.append(
            {
                "definition": def_name,
                "T_ASD_only": int(t_asd.sum()),
                "T_SCZ_only": int(t_scz.sum()),
                "T_Shared": int(t_shr.sum()),
                "T_CPEB4_other": int(t_oth.sum()),
                "T_CPEB4_total": int(is_binder.sum()),
                "All_ASD_only": int(all_asd.sum()),
                "All_SCZ_only": int(all_scz.sum()),
                "All_Shared": int(all_shr.sum()),
                "All_Other": int(all_oth.sum()),
            }
        )

        # Contrasts within CPEB4 binders (pool = is_binder) and unfiltered (pool = all brain-expr)
        contrasts = [
            (f"{def_name}__CPEB4_binders", "T_SCZ_only", "T_ASD_only", t_scz, t_asd, is_binder),
            (f"{def_name}__CPEB4_binders", "T_SCZ_only", "T_CPEB4_other", t_scz, t_oth, is_binder),
            (f"{def_name}__CPEB4_binders", "T_ASD_only", "T_CPEB4_other", t_asd, t_oth, is_binder),
            (f"{def_name}__CPEB4_binders", "T_Shared", "T_ASD_only", t_shr, t_asd, is_binder),
            (f"{def_name}__CPEB4_binders", "T_SCZ_only", "T_Shared", t_scz, t_shr, is_binder),
            (f"{def_name}__All_BrainExpr", "All_SCZ_only", "All_ASD_only", all_scz, all_asd, np.ones(len(df_be), dtype=bool)),
        ]

        # Run all metrics for primary DefA and DefB; run core 4 metrics for sensitivity DefC-F
        m_list = (
            metrics_to_test
            if def_name in ("DefA_SFARI12_vs_SCZcomb", "DefB_SFARI12_vs_SCHEMA05")
            else ["dZ_all_primary", "dZ_pfc_primary", "tau_star_all", "tau_star_pfc"]
        )

        for m_name in m_list:
            vals = df_be[m_name].values
            for c_fam, la, lb, ma, mb, pool_m in contrasts:
                # Only run non-primary sub-contrasts for DefA and DefB to keep runtime focused
                if (
                    def_name not in ("DefA_SFARI12_vs_SCZcomb", "DefB_SFARI12_vs_SCHEMA05")
                    and la not in ("T_SCZ_only", "All_SCZ_only")
                ):
                    continue
                if (
                    def_name not in ("DefA_SFARI12_vs_SCZcomb", "DefB_SFARI12_vs_SCHEMA05")
                    and lb not in ("T_ASD_only", "All_ASD_only")
                ):
                    continue
                do_joint = (
                    def_name in ("DefA_SFARI12_vs_SCZcomb", "DefB_SFARI12_vs_SCHEMA05")
                    and m_name in ("dZ_all_primary", "dZ_pfc_primary", "tau_star_all", "tau_star_pfc")
                    and lb in ("T_ASD_only", "All_ASD_only")
                )
                res_t = compare_two_groups_timing(
                    vals=vals,
                    expr_deciles=expr_dec,
                    len_quintiles=len_quin,
                    mask_a=ma,
                    mask_b=mb,
                    pool_mask=pool_m,
                    label_a=la,
                    label_b=lb,
                    metric_name=m_name,
                    contrast_family=c_fam,
                    n_perm=N_PERM,
                    n_boot=N_BOOT,
                    seed=SEED,
                    do_joint_perm=do_joint,
                )
                timing_tests.append(res_t)

    # Also test unfiltered pc (max_rpkm >= 0, std > 0) sensitivity for DefA and DefB on dZ_all_primary & dZ_pfc_primary
    df_all_pc = df[pc_mask].copy().reset_index(drop=True)
    expr_dec_all = pd.qcut(df_all_pc["mean_log2_rpkm"], q=10, labels=False, duplicates="drop").values.astype(int)
    len_quin_all = pd.qcut(np.log10(df_all_pc["gene_length_bp"]), q=5, labels=False, duplicates="drop").values.astype(int)
    b_all = (df_all_pc["parras18_cpeb4_binder"] == True).values
    sf_all = df_all_pc["sfari_score"].isin([1.0, 2.0]).values
    scz_a_all = ((df_all_pc["schema_P_meta"] < 0.05) | (df_all_pc["ot_scz_genetic_association"] >= 0.15)).values
    scz_b_all = (df_all_pc["schema_P_meta"] < 0.05).values
    for def_name, scz_x in [("DefA_UnfilteredPC", scz_a_all), ("DefB_UnfilteredPC", scz_b_all)]:
        for m_name in ["dZ_all_primary", "dZ_pfc_primary"]:
            timing_tests.append(
                compare_two_groups_timing(
                    vals=df_all_pc[m_name].values,
                    expr_deciles=expr_dec_all,
                    len_quintiles=len_quin_all,
                    mask_a=b_all & (~sf_all) & scz_x,
                    mask_b=b_all & sf_all & (~scz_x),
                    pool_mask=b_all,
                    label_a="T_SCZ_only",
                    label_b="T_ASD_only",
                    metric_name=m_name,
                    contrast_family=f"{def_name}__CPEB4_binders",
                    n_perm=N_PERM,
                    n_boot=N_BOOT,
                    seed=SEED,
                )
            )

    timing_tests_df = pd.DataFrame(timing_tests)
    timing_tests_df["bh_fdr_mannwhitney"] = bh_fdr(timing_tests_df["mannwhitney_p"].values)
    timing_tests_df["bh_fdr_perm_expr"] = bh_fdr(timing_tests_df["perm_expr_matched_p_two_sided"].values)

    # Export gene-level BrainSpan timing table
    export_cols = [
        "ensembl_gene_id",
        "gene_symbol",
        "mean_rpkm",
        "mean_log2_rpkm",
        "max_rpkm",
        "gene_length_bp",
        "parras18_cpeb4_binder",
        "parras18_polya_shortened_hd",
        "sfari_score",
        "fu22_ASD185",
        "schema_P_meta",
        "ot_scz_genetic_association",
        "is_int17_scz_hc",
        "is_syngo",
        "disjoint_all_DefA_SFARI12_vs_SCZcomb",
        "disjoint_cpeb4_DefA_SFARI12_vs_SCZcomb",
        "disjoint_all_DefB_SFARI12_vs_SCHEMA05",
        "disjoint_cpeb4_DefB_SFARI12_vs_SCHEMA05",
        *metrics_to_test,
        "spearman_rho_all",
        "spearman_rho_pfc",
    ]
    gene_timing_path = RESULTS_DIR / "brainspan_gene_timing.csv"
    df_be[export_cols].to_csv(gene_timing_path, index=False)
    print(f"Saved gene timing table ({len(df_be)} genes) to {gene_timing_path}")

    # --- Regulator & Module Developmental Trajectories across 524 samples & 16 regions ---
    traj_df = traj.copy()
    # Compute Synaptogenesis module Z and Complement/Pruning module Z from brainspan_log2rpkm directly
    # to ensure exact gene-wise Z-scoring across all 524 samples (and PFC-only)
    syn_genes = ["SYP", "DLG4", "SNAP25", "SYN1", "GRIN2B", "GRIN2A", "SLC17A7", "GAD1", "NRXN1", "SHANK3"]
    prun_genes = ["C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "ITGAM", "ITGB2", "TREM2", "TYROBP", "CX3CR1", "P2RY12", "CD68", "CSF1R", "C3AR1", "PROS1", "MERTK"]
    prun_core = ["C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "TREM2", "CX3CR1"]
    kinase_mat_genes = ["CAMK2A", "CAMK2B", "MAPK1", "MAPK3"]

    def module_z_series(gene_list: List[str]) -> np.ndarray:
        sub_cols = [g for g in gene_list if g in traj_df.columns]
        arr = traj_df[sub_cols].values.astype(np.float64)
        z_arr = (arr - arr.mean(axis=0, keepdims=True)) / arr.std(axis=0, ddof=0, keepdims=True)
        return z_arr.mean(axis=1)

    traj_df["Synaptogenesis_module_Z"] = module_z_series(syn_genes)
    traj_df["Complement_Pruning_module_Z"] = module_z_series(prun_genes)
    traj_df["Complement_Core_module_Z"] = module_z_series(prun_core)
    traj_df["Kinase_Maturation_module_Z"] = module_z_series(kinase_mat_genes)

    # Also compute SynGO module Z across all brain-expressed SynGO genes
    syngo_idx = np.where(pc_mask.values & (df["max_rpkm"].values >= 1.0) & (df["is_syngo"].values == True))[0]
    syngo_mat = mat[syngo_idx].astype(np.float64)
    syngo_z = (syngo_mat - syngo_mat.mean(axis=1, keepdims=True)) / syngo_mat.std(axis=1, ddof=0, keepdims=True)
    traj_df["SynGO_module_Z"] = syngo_z.mean(axis=0)

    # Also T_ASD_only and T_SCZ_only (DefA) module Z trajectories across 524 samples
    def subset_module_z(symbol_list: List[str]) -> np.ndarray:
        idx = np.where(df["is_primary_symbol_row"].values & (df["gene_biotype"].values == "protein_coding") & df["gene_symbol"].isin(symbol_list).values)[0]
        m = mat[idx].astype(np.float64)
        sd = m.std(axis=1, ddof=0, keepdims=True)
        valid = sd[:, 0] > 1e-8
        z = (m[valid] - m[valid].mean(axis=1, keepdims=True)) / sd[valid]
        return z.mean(axis=0)

    t_asd_syms = df_be.loc[df_be["disjoint_cpeb4_DefA_SFARI12_vs_SCZcomb"] == "T_ASD_only", "gene_symbol"].tolist()
    t_scz_syms = df_be.loc[df_be["disjoint_cpeb4_DefA_SFARI12_vs_SCZcomb"] == "T_SCZ_only", "gene_symbol"].tolist()
    traj_df["T_ASD_only_Z"] = subset_module_z(t_asd_syms)
    traj_df["T_SCZ_only_Z"] = subset_module_z(t_scz_syms)

    # Schema-only T_ASD_only and T_SCZ_only (DefB)
    t_asd_b_syms = df_be.loc[df_be["disjoint_cpeb4_DefB_SFARI12_vs_SCHEMA05"] == "T_ASD_only", "gene_symbol"].tolist()
    t_scz_b_syms = df_be.loc[df_be["disjoint_cpeb4_DefB_SFARI12_vs_SCHEMA05"] == "T_SCZ_only", "gene_symbol"].tolist()
    traj_df["T_ASD_only_DefB_Z"] = subset_module_z(t_asd_b_syms)
    traj_df["T_SCZ_only_DefB_Z"] = subset_module_z(t_scz_b_syms)

    targets_traj = [
        "CPEB4", "CPEB1", "CPEB2", "CPEB3",
        "SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "HNRNPC", "PTBP1", "PTBP2",
        "MAPK1", "MAPK3", "CAMK2A", "CAMK2B",
        "Synaptogenesis_module_Z", "SynGO_module_Z",
        "Complement_Pruning_module_Z", "Complement_Core_module_Z",
        "Kinase_Maturation_module_Z",
        "T_ASD_only_Z", "T_SCZ_only_Z", "T_ASD_only_DefB_Z", "T_SCZ_only_DefB_Z",
    ]

    pfc_mask_s = traj_df["is_pfc"].values.astype(bool)
    nonpfc_mask_s = ~pfc_mask_s
    major_regions = (
        traj_df["structure_acronym"]
        .value_counts()[lambda s: s >= 24]
        .index.tolist()
    )

    traj_results = []
    for col in targets_traj:
        y_all = traj_df[col].values.astype(float)
        x_all = traj_df["log2_pcw"].values.astype(float)

        rho_all, p_rho_all = stats.spearmanr(x_all, y_all)
        rho_pfc, p_rho_pfc = stats.spearmanr(x_all[pfc_mask_s], y_all[pfc_mask_s])
        rho_nonpfc, p_rho_nonpfc = stats.spearmanr(x_all[nonpfc_mask_s], y_all[nonpfc_mask_s])

        # Peak age (by mean expression at each distinct age_pcw, and by dev_stage)
        age_means_all = traj_df.groupby(["age_pcw", "age"])[col].mean().reset_index()
        peak_row_all = age_means_all.loc[age_means_all[col].idxmax()]
        age_means_pfc = traj_df[pfc_mask_s].groupby(["age_pcw", "age"])[col].mean().reset_index()
        peak_row_pfc = age_means_pfc.loc[age_means_pfc[col].idxmax()]
        stage_means_pfc = traj_df[pfc_mask_s].groupby("dev_stage")[col].mean()
        peak_stage_pfc = str(stage_means_pfc.idxmax())

        # OLS Interaction: expr ~ log2_pcw * is_pfc
        X_int = pd.DataFrame(
            {
                "const": 1.0,
                "log2_pcw": x_all,
                "is_pfc": pfc_mask_s.astype(float),
                "log2_pcw_x_is_pfc": x_all * pfc_mask_s.astype(float),
            }
        )
        ols_fit = sm.OLS(y_all, X_int).fit()

        # Separate PFC & non-PFC slopes
        fit_pfc = sm.OLS(y_all[pfc_mask_s], sm.add_constant(x_all[pfc_mask_s])).fit()
        fit_nonpfc = sm.OLS(y_all[nonpfc_mask_s], sm.add_constant(x_all[nonpfc_mask_s])).fit()

        # 16 major regions spearman summary
        reg_rhos = {}
        for reg in major_regions:
            rm = (traj_df["structure_acronym"] == reg).values
            r_reg, p_reg = stats.spearmanr(x_all[rm], y_all[rm])
            reg_rhos[reg] = {"rho": float(r_reg), "p": float(p_reg), "n": int(rm.sum())}

        traj_results.append(
            {
                "feature": col,
                "n_all": int(len(y_all)),
                "n_pfc": int(pfc_mask_s.sum()),
                "n_nonpfc": int(nonpfc_mask_s.sum()),
                "spearman_rho_all": float(rho_all),
                "spearman_p_all": float(p_rho_all),
                "spearman_rho_pfc": float(rho_pfc),
                "spearman_p_pfc": float(p_rho_pfc),
                "spearman_rho_nonpfc": float(rho_nonpfc),
                "spearman_p_nonpfc": float(p_rho_nonpfc),
                "peak_age_all": str(peak_row_all["age"]),
                "peak_age_pcw_all": float(peak_row_all["age_pcw"]),
                "peak_age_pfc": str(peak_row_pfc["age"]),
                "peak_age_pcw_pfc": float(peak_row_pfc["age_pcw"]),
                "peak_stage_pfc": peak_stage_pfc,
                "pfc_slope": float(fit_pfc.params[1]),
                "pfc_slope_p": float(fit_pfc.pvalues[1]),
                "nonpfc_slope": float(fit_nonpfc.params[1]),
                "nonpfc_slope_p": float(fit_nonpfc.pvalues[1]),
                "ols_df_resid": int(ols_fit.df_resid),
                "ols_beta_age": float(ols_fit.params["log2_pcw"]),
                "ols_p_age": float(ols_fit.pvalues["log2_pcw"]),
                "ols_beta_pfc": float(ols_fit.params["is_pfc"]),
                "ols_p_pfc": float(ols_fit.pvalues["is_pfc"]),
                "ols_beta_interaction": float(ols_fit.params["log2_pcw_x_is_pfc"]),
                "ols_t_interaction": float(ols_fit.tvalues["log2_pcw_x_is_pfc"]),
                "ols_p_interaction": float(ols_fit.pvalues["log2_pcw_x_is_pfc"]),
                "n_major_regions_pos_rho": int(sum(1 for v in reg_rhos.values() if v["rho"] > 0 and v["p"] < 0.05)),
                "n_major_regions_neg_rho": int(sum(1 for v in reg_rhos.values() if v["rho"] < 0 and v["p"] < 0.05)),
                "major_regions_detail": reg_rhos,
            }
        )

    summary = {
        "n_brain_expressed_pc": int(len(df_be)),
        "disjoint_counts": disjoint_counts,
        "timing_tests": timing_tests_df.to_dict(orient="records"),
        "trajectory_regressions": traj_results,
    }
    return df_be, timing_tests_df, traj_df, summary


def run_analysis_3(
    df_be: pd.DataFrame,
    der13_raw: pd.DataFrame,
    der14_raw: pd.DataFrame,
    der15_raw: pd.DataFrame,
    der14_summary: pd.DataFrame,
    gandal_df: pd.DataFrame,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Analysis 3: Human Postmortem Cortical Cross-Disorder Validation
    (Categorical PsychENCODE DER-13/14/15 + Continuous Gandal et al. 2018).
    """
    print("\n=== Running Analysis 3: PsychENCODE Cortical Timing & Regulator Validation ===")
    expr_dec = pd.qcut(df_be["mean_log2_rpkm"], q=10, labels=False, duplicates="drop").values.astype(int)
    len_quin = pd.qcut(np.log10(df_be["gene_length_bp"]), q=5, labels=False, duplicates="drop").values.astype(int)
    is_binder = (df_be["parras18_cpeb4_binder"] == True).values

    # Build exact PsychENCODE disorder dysregulation masks
    ens = df_be["ensembl_gene_id"]
    der14 = der14_raw.copy()
    der14["Disorder"] = der14["Disorder.DTE_RegulationDirection"].str.split(".").str[0]
    der14["Direction"] = der14["Disorder.DTE_RegulationDirection"].str.split("_").str[1]

    asd_dge_up = (df_be["psychencode_ASD_DGE"] == "up").values
    asd_dge_dn = (df_be["psychencode_ASD_DGE"] == "down").values
    asd_dge_any = asd_dge_up | asd_dge_dn
    scz_dge_up = (df_be["psychencode_SCZ_DGE"] == "up").values
    scz_dge_dn = (df_be["psychencode_SCZ_DGE"] == "down").values
    scz_dge_any = scz_dge_up | scz_dge_dn

    asd_dte_up = ens.isin(set(der14[(der14["Disorder"] == "ASD") & (der14["Direction"] == "up")]["Ensembl_Gene"])).values
    asd_dte_dn = ens.isin(set(der14[(der14["Disorder"] == "ASD") & (der14["Direction"] == "down")]["Ensembl_Gene"])).values
    asd_dte_any = asd_dte_up | asd_dte_dn
    scz_dte_up = ens.isin(set(der14[(der14["Disorder"] == "SCZ") & (der14["Direction"] == "up")]["Ensembl_Gene"])).values
    scz_dte_dn = ens.isin(set(der14[(der14["Disorder"] == "SCZ") & (der14["Direction"] == "down")]["Ensembl_Gene"])).values
    scz_dte_any = scz_dte_up | scz_dte_dn

    asd_ds = (df_be["psychencode_ASD_DS"] == True).values
    scz_ds = (df_be["psychencode_SCZ_DS"] == True).values

    asd_union = asd_dge_any | asd_dte_any | asd_ds
    scz_union = scz_dge_any | scz_dte_any | scz_ds

    pe_contrasts = [
        ("PE_DGE_any", asd_dge_any, scz_dge_any),
        ("PE_DGE_down", asd_dge_dn, scz_dge_dn),
        ("PE_DGE_up", asd_dge_up, scz_dge_up),
        ("PE_DTE_any", asd_dte_any, scz_dte_any),
        ("PE_DTE_down", asd_dte_dn, scz_dte_dn),
        ("PE_DTE_up", asd_dte_up, scz_dte_up),
        ("PE_DS_leaf", asd_ds, scz_ds),
        ("PE_Union_DGE_DTE_DS", asd_union, scz_union),
    ]

    pe_metrics = [
        "dZ_all_primary",
        "dZ_pfc_primary",
        "dZ_all_sensA_fetal_adoladult",
        "dZ_pfc_sensA_fetal_adoladult",
        "tau_star_all",
        "tau_star_pfc",
    ]

    pe_rows = []
    pe_counts = []
    for c_name, m_asd, m_scz in pe_contrasts:
        t_asd_only = is_binder & m_asd & (~m_scz)
        t_scz_only = is_binder & (~m_asd) & m_scz
        t_shared = is_binder & m_asd & m_scz
        all_asd_only = m_asd & (~m_scz)
        all_scz_only = (~m_asd) & m_scz
        all_shared = m_asd & m_scz

        pe_counts.append(
            {
                "contrast": c_name,
                "T_ASD_only": int(t_asd_only.sum()),
                "T_SCZ_only": int(t_scz_only.sum()),
                "T_Shared": int(t_shared.sum()),
                "All_ASD_only": int(all_asd_only.sum()),
                "All_SCZ_only": int(all_scz_only.sum()),
                "All_Shared": int(all_shared.sum()),
            }
        )

        for m_name in pe_metrics:
            vals = df_be[m_name].values
            # 1. Within CPEB4-bound targets
            pe_rows.append(
                compare_two_groups_timing(
                    vals=vals,
                    expr_deciles=expr_dec,
                    len_quintiles=len_quin,
                    mask_a=t_scz_only,
                    mask_b=t_asd_only,
                    pool_mask=is_binder,
                    label_a="PE_T_SCZ_only",
                    label_b="PE_T_ASD_only",
                    metric_name=m_name,
                    contrast_family=f"{c_name}__CPEB4_binders",
                    n_perm=N_PERM,
                    n_boot=N_BOOT,
                    seed=SEED,
                    do_joint_perm=(m_name in ("dZ_all_primary", "dZ_pfc_primary")),
                )
            )
            # 2. Across all brain-expressed protein-coding genes
            pe_rows.append(
                compare_two_groups_timing(
                    vals=vals,
                    expr_deciles=expr_dec,
                    len_quintiles=len_quin,
                    mask_a=all_scz_only,
                    mask_b=all_asd_only,
                    pool_mask=np.ones(len(df_be), dtype=bool),
                    label_a="PE_All_SCZ_only",
                    label_b="PE_All_ASD_only",
                    metric_name=m_name,
                    contrast_family=f"{c_name}__All_BrainExpr",
                    n_perm=N_PERM,
                    n_boot=N_BOOT,
                    seed=SEED,
                    do_joint_perm=(m_name in ("dZ_all_primary", "dZ_pfc_primary")),
                )
            )

    pe_df = pd.DataFrame(pe_rows)
    pe_df["bh_fdr_mannwhitney"] = bh_fdr(pe_df["mannwhitney_p"].values)
    pe_df["bh_fdr_perm_expr"] = bh_fdr(pe_df["perm_expr_matched_p_two_sided"].values)

    out_path = RESULTS_DIR / "psychencode_timing_validation.csv"
    pe_df.to_csv(out_path, index=False)
    print(f"Saved PsychENCODE timing validation ({len(pe_df)} rows) to {out_path}")

    # Regulator & Kinase status in DER-13/14/15
    reg_genes = [
        "CPEB4", "CPEB1", "CPEB2", "CPEB3",
        "SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "HNRNPC", "PTBP1", "PTBP2",
        "MAPK1", "MAPK3", "CAMK2A", "CAMK2B",
    ]
    reg_status = []
    for g in reg_genes:
        d13 = der13_raw[der13_raw["Gene_Name"] == g]["Disorder.DGE_RegulationDirection"].tolist()
        d14 = der14_raw[der14_raw["Gene_Name"] == g][
            ["Transcript_Name", "Ensembl_Transcript", "Disorder.DTE_RegulationDirection"]
        ].to_dict(orient="records")
        d15 = der15_raw[der15_raw["Gene_Name"] == g]["Disorder.DS_leaf(cutter)"].tolist()
        reg_status.append(
            {
                "gene_symbol": g,
                "der13_dge": d13 if d13 else ["ns"],
                "der14_dte_transcripts": d14,
                "der15_ds_leaf": d15 if d15 else ["ns"],
            }
        )

    # --- Continuous Gandal et al. (2018) Cortical RNA-seq Validation ---
    print("Running continuous Gandal 2018 cortical RNA-seq validation...")
    g_cols_keep = [
        "ensembl_gene_id",
        "bd_cmc_logFC", "bd_cmc_t", "bd_cmc_P_Value", "bd_cmc_adj_P_Val",
        "bd_gvex_logFC", "bd_gvex_t", "bd_gvex_P_Value", "bd_gvex_adj_P_Val",
    ]
    df_g = df_be.merge(gandal_df[g_cols_keep].drop_duplicates("ensembl_gene_id"), on="ensembl_gene_id", how="left")

    # Continuous disorder-specificity indices (SCZ minus ASD)
    df_g["dbeta_signed_cmc_asd_frontal"] = df_g["scz_cmc_logFC"] - df_g["asd_frontal_logFC"]
    df_g["dbeta_signed_cmc_asd_all"] = df_g["scz_cmc_logFC"] - df_g["asd_all_logFC"]
    df_g["dbeta_signed_gvex_asd_frontal"] = df_g["scz_gvex_logFC"] - df_g["asd_frontal_logFC"]
    df_g["dbeta_signed_gvex_asd_all"] = df_g["scz_gvex_logFC"] - df_g["asd_all_logFC"]

    df_g["dbeta_abs_cmc_asd_frontal"] = df_g["scz_cmc_logFC"].abs() - df_g["asd_frontal_logFC"].abs()
    df_g["dbeta_abs_cmc_asd_all"] = df_g["scz_cmc_logFC"].abs() - df_g["asd_all_logFC"].abs()
    df_g["dbeta_abs_gvex_asd_frontal"] = df_g["scz_gvex_logFC"].abs() - df_g["asd_frontal_logFC"].abs()
    df_g["dbeta_abs_gvex_asd_all"] = df_g["scz_gvex_logFC"].abs() - df_g["asd_all_logFC"].abs()

    df_g["dt_abs_cmc_asd_frontal"] = df_g["scz_cmc_t"].abs() - df_g["asd_frontal_t"].abs()
    df_g["dt_abs_gvex_asd_frontal"] = df_g["scz_gvex_t"].abs() - df_g["asd_frontal_t"].abs()

    g_subsets = {
        "CPEB4_binders": (df_g["parras18_cpeb4_binder"] == True).values,
        "PolyA_shortened_HD": (df_g["parras18_polya_shortened_hd"] == True).values,
        "All_BrainExpr_PC": np.ones(len(df_g), dtype=bool),
    }
    timing_vars = ["dZ_all_primary", "dZ_pfc_primary", "tau_star_all", "tau_star_pfc"]
    diff_vars = [
        "dbeta_signed_cmc_asd_frontal",
        "dbeta_signed_cmc_asd_all",
        "dbeta_signed_gvex_asd_frontal",
        "dbeta_signed_gvex_asd_all",
        "dbeta_abs_cmc_asd_frontal",
        "dbeta_abs_cmc_asd_all",
        "dbeta_abs_gvex_asd_frontal",
        "dbeta_abs_gvex_asd_all",
        "dt_abs_cmc_asd_frontal",
        "dt_abs_gvex_asd_frontal",
        "asd_frontal_logFC",
        "asd_all_logFC",
        "scz_cmc_logFC",
        "scz_gvex_logFC",
    ]

    cont_corr_rows = []
    for s_name, s_mask in g_subsets.items():
        sub_s = df_g[s_mask]
        for t_var in timing_vars:
            for d_var in diff_vars:
                valid = sub_s[[t_var, d_var, "mean_log2_rpkm", "gene_length_bp"]].dropna()
                if len(valid) < 10:
                    continue
                x = valid[t_var].values.astype(float)
                y = valid[d_var].values.astype(float)
                rho, p_rho = stats.spearmanr(x, y)
                r_p, p_r = stats.pearsonr(x, y)

                # Covariate-adjusted OLS: y ~ x + mean_log2_rpkm + log10(gene_length_bp)
                X_cov = pd.DataFrame(
                    {
                        "const": 1.0,
                        "timing": x,
                        "mean_log2_rpkm": valid["mean_log2_rpkm"].values.astype(float),
                        "log10_gene_length": np.log10(valid["gene_length_bp"].values.astype(float)),
                    }
                )
                ols_c = sm.OLS(y, X_cov).fit()
                cont_corr_rows.append(
                    {
                        "subset": s_name,
                        "timing_metric": t_var,
                        "cortical_metric": d_var,
                        "n": int(len(valid)),
                        "spearman_rho": float(rho),
                        "spearman_p": float(p_rho),
                        "pearson_r": float(r_p),
                        "pearson_p": float(p_r),
                        "ols_adj_beta": float(ols_c.params["timing"]),
                        "ols_adj_t": float(ols_c.tvalues["timing"]),
                        "ols_adj_p": float(ols_c.pvalues["timing"]),
                    }
                )

    # Also test parras18_polya_fc_hd correlations with continuous logFC & dZ
    polya_fc_rows = []
    for d_var in [
        "asd_frontal_logFC", "asd_all_logFC", "scz_cmc_logFC", "scz_gvex_logFC",
        "dbeta_signed_cmc_asd_frontal", "dbeta_abs_cmc_asd_frontal",
        "dZ_all_primary", "dZ_pfc_primary",
    ]:
        valid = df_g[["parras18_polya_fc_hd", d_var, "mean_log2_rpkm", "gene_length_bp"]].dropna()
        if len(valid) >= 10:
            x = valid["parras18_polya_fc_hd"].values.astype(float)
            y = valid[d_var].values.astype(float)
            rho, p_rho = stats.spearmanr(x, y)
            r_p, p_r = stats.pearsonr(x, y)
            polya_fc_rows.append(
                {
                    "x_var": "parras18_polya_fc_hd",
                    "y_var": d_var,
                    "n": int(len(valid)),
                    "spearman_rho": float(rho),
                    "spearman_p": float(p_rho),
                    "pearson_r": float(r_p),
                    "pearson_p": float(p_r),
                }
            )

    cont_corr_df = pd.DataFrame(cont_corr_rows)
    cont_corr_df["bh_fdr_spearman"] = np.nan
    for s_name, idx in cont_corr_df.groupby("subset").groups.items():
        cont_corr_df.loc[idx, "bh_fdr_spearman"] = bh_fdr(cont_corr_df.loc[idx, "spearman_p"].values)

    # Group comparisons on continuous Gandal 2018 logFC & |logFC|
    is_polya_g = (df_g["parras18_polya_shortened_hd"] == True).values
    sf12_g = df_g["sfari_score"].isin([1.0, 2.0]).values
    scz_comb_g = ((df_g["schema_P_meta"] < 0.05) | (df_g["ot_scz_genetic_association"] >= 0.15)).values
    scz_sch_g = (df_g["schema_P_meta"] < 0.05).values
    int17_g = (df_g["is_int17_scz_hc"] == True).values

    cont_group_rows = []
    group_defs = [
        ("DefA_T_SCZ_vs_T_ASD", is_binder & (~sf12_g) & scz_comb_g, is_binder & sf12_g & (~scz_comb_g), is_binder, "T_SCZ_only", "T_ASD_only"),
        ("DefB_T_SCZ_vs_T_ASD", is_binder & (~sf12_g) & scz_sch_g, is_binder & sf12_g & (~scz_sch_g), is_binder, "T_SCZ_only", "T_ASD_only"),
        ("DefG_INT17_T_SCZ_vs_T_ASD", is_binder & (~sf12_g) & int17_g, is_binder & sf12_g & (~int17_g), is_binder, "T_SCZ_INT17_only", "T_ASD_only"),
        ("CPEB4_Binder_vs_NonBinder", is_binder, ~is_binder, np.ones(len(df_g), dtype=bool), "CPEB4_binder", "Non_binder"),
        ("PolyA_Short_vs_NonPolyA_within_Binders", is_polya_g, is_binder & (~is_polya_g), is_binder, "PolyA_shortened", "Binder_non_shortened"),
    ]
    cont_outcomes = [
        "asd_frontal_logFC", "asd_all_logFC", "scz_cmc_logFC", "scz_gvex_logFC",
        "dbeta_signed_cmc_asd_frontal", "dbeta_abs_cmc_asd_frontal",
        "dbeta_signed_gvex_asd_frontal", "dbeta_abs_gvex_asd_frontal",
    ]
    # Add absolute logFC columns temporarily
    for c_src in ["asd_frontal_logFC", "asd_all_logFC", "scz_cmc_logFC", "scz_gvex_logFC"]:
        df_g[f"abs_{c_src}"] = df_g[c_src].abs()
        cont_outcomes.append(f"abs_{c_src}")

    for fam_name, ma, mb, pool_m, la, lb in group_defs:
        for out_c in cont_outcomes:
            cont_group_rows.append(
                compare_two_groups_timing(
                    vals=df_g[out_c].values,
                    expr_deciles=expr_dec,
                    len_quintiles=len_quin,
                    mask_a=ma,
                    mask_b=mb,
                    pool_mask=pool_m,
                    label_a=la,
                    label_b=lb,
                    metric_name=out_c,
                    contrast_family=fam_name,
                    n_perm=N_PERM,
                    n_boot=N_BOOT,
                    seed=SEED,
                )
            )
    cont_group_df = pd.DataFrame(cont_group_rows)
    cont_group_df["bh_fdr_mannwhitney"] = bh_fdr(cont_group_df["mannwhitney_p"].values)

    cont_corr_path = RESULTS_DIR / "gandal2018_continuous_correlations.csv"
    cont_corr_df.to_csv(cont_corr_path, index=False)
    cont_group_path = RESULTS_DIR / "gandal2018_continuous_group_tests.csv"
    cont_group_df.to_csv(cont_group_path, index=False)
    print(f"Saved Gandal 2018 continuous results ({len(cont_corr_df)} corrs, {len(cont_group_df)} group tests)")

    # Exact Gandal 2018 continuous stats for key regulators, kinases, and complement genes
    key_genes_gandal = [
        "CPEB4", "CPEB1", "CPEB2", "CPEB3",
        "SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "HNRNPC", "PTBP1", "PTBP2",
        "MAPK1", "MAPK3", "CAMK2A", "CAMK2B",
        "C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "TREM2", "CX3CR1",
    ]
    g_cols_export = [
        "gene_symbol", "ensembl_gene_id", "is_int17_scz_hc",
        "asd_all_logFC", "asd_all_t", "asd_all_P_Value", "asd_all_adj_P_Val",
        "asd_frontal_logFC", "asd_frontal_t", "asd_frontal_P_Value", "asd_frontal_adj_P_Val",
        "scz_cmc_logFC", "scz_cmc_t", "scz_cmc_P_Value", "scz_cmc_adj_P_Val",
        "scz_gvex_logFC", "scz_gvex_t", "scz_gvex_P_Value", "scz_gvex_adj_P_Val",
        "bd_cmc_logFC", "bd_cmc_t", "bd_cmc_P_Value", "bd_cmc_adj_P_Val",
        "bd_gvex_logFC", "bd_gvex_t", "bd_gvex_P_Value", "bd_gvex_adj_P_Val",
    ]
    gandal_key_genes = gandal_df[gandal_df["gene_symbol"].isin(key_genes_gandal)][g_cols_export].to_dict(orient="records")

    summary = {
        "psychencode_counts": pe_counts,
        "psychencode_timing_tests": pe_df.to_dict(orient="records"),
        "regulator_status_in_der13_14_15": reg_status,
        "der14_cpeb_summary_file": der14_summary.to_dict(orient="records"),
        "gandal2018_continuous_correlations": cont_corr_df.to_dict(orient="records"),
        "gandal2018_polya_fc_correlations": polya_fc_rows,
        "gandal2018_continuous_group_tests": cont_group_df.to_dict(orient="records"),
        "gandal2018_key_genes": gandal_key_genes,
    }
    return pe_df, summary


def run_analysis_4(
    df_be: pd.DataFrame, traj_df: pd.DataFrame
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Analysis 4: Export smooth BrainSpan PFC empirical calibration curves across log2(pcw).
    Produces results/brainspan_empirical_kernels.csv on a uniform 100-point grid
    plus exact binned PFC age-point averages.
    """
    print("\n=== Running Analysis 4: Exporting BrainSpan PFC Empirical Kernels ===")
    pfc = traj_df[traj_df["is_pfc"] == True].copy().sort_values("log2_pcw")
    x_obs = pfc["log2_pcw"].values.astype(float)

    # Grid across observed PFC log2_pcw range [3.0, 11.052296]
    grid_x = np.linspace(float(x_obs.min()), float(x_obs.max()), 100)
    grid_age_pcw = np.power(2.0, grid_x)

    # Nadaraya-Watson Gaussian kernel smoother in log2_pcw space
    # Bandwidth h = 0.75 log2-pcw units (~1.68x age factor) balances smoothness across 29 PFC age bins
    bw = 0.75
    diff = (grid_x[:, None] - x_obs[None, :]) / bw
    weights = np.exp(-0.5 * diff ** 2)
    weights /= weights.sum(axis=1, keepdims=True)

    def smooth_curve(col: str) -> np.ndarray:
        return weights @ pfc[col].values.astype(float)

    def minmax01(arr: np.ndarray) -> np.ndarray:
        mn, mx = float(np.min(arr)), float(np.max(arr))
        return (arr - mn) / (mx - mn) if mx > mn else np.zeros_like(arr)

    z_syn_sm = smooth_curve("Synaptogenesis_module_Z")
    z_syngo_sm = smooth_curve("SynGO_module_Z")
    z_prun_sm = smooth_curve("Complement_Pruning_module_Z")
    z_prun_core_sm = smooth_curve("Complement_Core_module_Z")
    z_kin_sm = smooth_curve("Kinase_Maturation_module_Z")
    z_tasd_sm = smooth_curve("T_ASD_only_Z")
    z_tscz_sm = smooth_curve("T_SCZ_only_Z")
    z_tasd_b_sm = smooth_curve("T_ASD_only_DefB_Z")
    z_tscz_b_sm = smooth_curve("T_SCZ_only_DefB_Z")
    cpeb4_sm = smooth_curve("CPEB4")
    srrm4_sm = smooth_curve("SRRM4")
    rbfox1_sm = smooth_curve("RBFOX1")
    rbfox3_sm = smooth_curve("RBFOX3")

    # Synaptogenesis developmental derivative/drive: positive d/d(log2_pcw) of combined synaptogenesis + T_ASD_only
    syn_comb = 0.5 * (z_syn_sm + z_tasd_sm)
    dsyn_dt = np.gradient(syn_comb, grid_x)
    dsyn_pos = np.maximum(dsyn_dt, 0.0)

    # Pure synaptogenesis markers derivative as well
    dsyn_markers_dt = np.maximum(np.gradient(z_syn_sm, grid_x), 0.0)

    kernels_df = pd.DataFrame(
        {
            "grid_idx": np.arange(len(grid_x)),
            "log2_pcw": grid_x,
            "age_pcw": grid_age_pcw,
            "age_years_postnatal": (grid_age_pcw - 38.0) / 52.14,
            "alpha_syn_emp": minmax01(dsyn_pos),
            "alpha_syn_markers_deriv_emp": minmax01(dsyn_markers_dt),
            "alpha_syn_level_emp": minmax01(syn_comb),
            "beta_prun_emp": minmax01(z_prun_sm),
            "beta_prun_core_emp": minmax01(z_prun_core_sm),
            "D_act_emp": minmax01(z_kin_sm),
            "V_ASD_emp": minmax01(z_tasd_sm),
            "V_SCZ_emp": minmax01(z_tscz_sm),
            "V_ASD_DefB_emp": minmax01(z_tasd_b_sm),
            "V_SCZ_DefB_emp": minmax01(z_tscz_b_sm),
            "Z_syn_markers_smooth": z_syn_sm,
            "Z_syngo_smooth": z_syngo_sm,
            "Z_pruning_smooth": z_prun_sm,
            "Z_pruning_core_smooth": z_prun_core_sm,
            "Z_kinase_smooth": z_kin_sm,
            "Z_T_ASD_only_smooth": z_tasd_sm,
            "Z_T_SCZ_only_smooth": z_tscz_sm,
            "CPEB4_log2rpkm_smooth": cpeb4_sm,
            "SRRM4_log2rpkm_smooth": srrm4_sm,
            "RBFOX1_log2rpkm_smooth": rbfox1_sm,
            "RBFOX3_log2rpkm_smooth": rbfox3_sm,
        }
    )

    out_path = RESULTS_DIR / "brainspan_empirical_kernels.csv"
    kernels_df.to_csv(out_path, index=False)
    print(f"Saved BrainSpan PFC empirical kernels ({len(kernels_df)} grid points) to {out_path}")

    # Also save exact unsmoothed 29-age-point PFC averages for complete transparency
    pfc_binned = (
        pfc.groupby(["age_pcw", "log2_pcw", "age", "dev_stage"], as_index=False)
        .agg(
            n_pfc=("column_num", "count"),
            Synaptogenesis_module_Z=("Synaptogenesis_module_Z", "mean"),
            Complement_Pruning_module_Z=("Complement_Pruning_module_Z", "mean"),
            Kinase_Maturation_module_Z=("Kinase_Maturation_module_Z", "mean"),
            T_ASD_only_Z=("T_ASD_only_Z", "mean"),
            T_SCZ_only_Z=("T_SCZ_only_Z", "mean"),
            CPEB4=("CPEB4", "mean"),
            SRRM4=("SRRM4", "mean"),
            RBFOX1=("RBFOX1", "mean"),
            RBFOX3=("RBFOX3", "mean"),
        )
        .sort_values("age_pcw")
    )
    pfc_binned_path = RESULTS_DIR / "brainspan_pfc_age_binned.csv"
    pfc_binned.to_csv(pfc_binned_path, index=False)

    # Peak timing summary of the kernels
    def peak_info(col: str) -> Dict[str, float]:
        idx = int(np.argmax(kernels_df[col].values))
        return {
            "peak_log2_pcw": float(kernels_df.loc[idx, "log2_pcw"]),
            "peak_age_pcw": float(kernels_df.loc[idx, "age_pcw"]),
            "peak_age_years_postnatal": float(kernels_df.loc[idx, "age_years_postnatal"]),
        }

    summary = {
        "bandwidth_log2_pcw": bw,
        "n_pfc_samples": int(len(pfc)),
        "n_pfc_distinct_ages": int(len(pfc_binned)),
        "kernel_peaks": {
            "alpha_syn_emp": peak_info("alpha_syn_emp"),
            "alpha_syn_level_emp": peak_info("alpha_syn_level_emp"),
            "beta_prun_emp": peak_info("beta_prun_emp"),
            "D_act_emp": peak_info("D_act_emp"),
            "V_ASD_emp": peak_info("V_ASD_emp"),
            "V_SCZ_emp": peak_info("V_SCZ_emp"),
        },
        "corr_V_ASD_vs_alpha_syn_level": float(
            stats.spearmanr(kernels_df["V_ASD_emp"], kernels_df["alpha_syn_level_emp"])[0]
        ),
        "corr_V_SCZ_vs_beta_prun": float(
            stats.spearmanr(kernels_df["V_SCZ_emp"], kernels_df["beta_prun_emp"])[0]
        ),
        "corr_V_SCZ_vs_D_act": float(
            stats.spearmanr(kernels_df["V_SCZ_emp"], kernels_df["D_act_emp"])[0]
        ),
    }
    return kernels_df, summary


def main() -> None:
    print("Loading harmonized datasets...")
    univ = pd.read_csv(DATA_PROC / "harmonized_gene_universe.csv", low_memory=False)
    meta = pd.read_csv(DATA_PROC / "brainspan_metadata.csv")
    traj = pd.read_csv(DATA_PROC / "brainspan_module_trajectories.csv")
    npz = np.load(DATA_PROC / "brainspan_log2rpkm.npz", allow_pickle=True)
    mat = npz["log2_rpkm"]

    # Sanity alignment checks
    assert (univ["ensembl_gene_id"].values == npz["ensembl_gene_id"]).all(), "Ensembl ID mismatch!"
    assert (meta["column_num"].values == npz["column_num"]).all(), "Column number mismatch!"

    der13_raw = pd.read_csv(DATA_RAW / "psychencode" / "DER-13_Disorder_DEX_Genes.csv")
    der14_raw = pd.read_csv(DATA_RAW / "psychencode" / "DER-14_Disorder_DEX_Transcripts.csv")
    der15_raw = pd.read_csv(DATA_RAW / "psychencode" / "DER-15_Disorder_DifferentialSplicing.csv")
    der14_summary = pd.read_csv(DATA_PROC / "psychencode_der14_cpeb4_and_summary.csv")
    gandal_df = pd.read_csv(DATA_PROC / "gandal2018_continuous_sumstats.csv", low_memory=False)

    enr_df, sum1 = run_analysis_1(univ, der14_raw)
    df_be, timing_df, traj_full, sum2 = run_analysis_2(univ, meta, mat, traj)
    pe_df, sum3 = run_analysis_3(df_be, der13_raw, der14_raw, der15_raw, der14_summary, gandal_df)
    kernels_df, sum4 = run_analysis_4(df_be, traj_full)

    def sanitize_json(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {k: sanitize_json(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [sanitize_json(v) for v in obj]
        if isinstance(obj, (float, np.floating)):
            val = float(obj)
            return None if (math.isnan(val) or math.isinf(val)) else val
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        return obj

    # Save master JSON results
    master = sanitize_json(
        {
            "metadata": {
                "seed": SEED,
                "n_permutations": N_PERM,
                "n_bootstrap": N_BOOT,
                "n_brainspan_samples": int(len(meta)),
                "n_brainspan_pfc_samples": int(meta["is_pfc"].sum()),
            },
            "analysis_1_enrichment": sum1,
            "analysis_2_brainspan_timing": sum2,
            "analysis_3_psychencode_validation": sum3,
            "analysis_4_empirical_kernels": sum4,
        }
    )
    json_path = RESULTS_DIR / "bioinformatics_results.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(master, f, indent=2, allow_nan=False)
    print(f"\nSaved master JSON results to {json_path}")


if __name__ == "__main__":
    main()
