# -*- coding: utf-8 -*-
"""
richtext.py
===========
Lightweight inline-markup parser shared by the DOCX and Markdown builders.

Supported markup (as produced by `manuscript_content.py`):
  **bold**, *italic*, `literal`, ^superscript^, ~subscript~
Superscripts/subscripts may contain nested italics (e.g. ``*n*~*H*~``).
A tilde or caret is treated as markup only when it is attached to the
preceding character and closes within a short, space-free span; otherwise it
is kept as a literal character (e.g. the approximation sign in "~1.5").
"""

from __future__ import annotations

import html
from dataclasses import dataclass, replace

MAX_SCRIPT_LEN = 40


@dataclass(frozen=True)
class Style:
    bold: bool = False
    italic: bool = False
    sup: bool = False
    sub: bool = False
    mono: bool = False


@dataclass
class Run:
    text: str
    style: Style


def _find_script_close(s: str, i: int, ch: str) -> int:
    """Return index of closing `ch` for a script opened at s[i], or -1."""
    j = s.find(ch, i + 1)
    if j == -1:
        return -1
    content = s[i + 1 : j]
    if not content or len(content) > MAX_SCRIPT_LEN or " " in content or "\n" in content:
        return -1
    return j


def _find_italic_close(s: str, i: int) -> int:
    j = i + 1
    while True:
        j = s.find("*", j)
        if j == -1:
            return -1
        if s.startswith("**", j):
            # skip bold delimiters nested inside italics
            k = s.find("**", j + 2)
            if k == -1:
                return -1
            j = k + 2
            continue
        if j == i + 1:
            return -1
        return j


def parse(s: str, style: Style = Style()) -> list[Run]:
    runs: list[Run] = []
    buf: list[str] = []

    def flush() -> None:
        if buf:
            runs.append(Run("".join(buf), style))
            buf.clear()

    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if s.startswith("**", i):
            j = s.find("**", i + 2)
            if j != -1:
                flush()
                runs.extend(parse(s[i + 2 : j], replace(style, bold=True)))
                i = j + 2
                continue
        if c == "`":
            j = s.find("`", i + 1)
            if j != -1:
                flush()
                runs.append(Run(s[i + 1 : j], replace(style, mono=True)))
                i = j + 1
                continue
        if c in "^~":
            prev = s[i - 1] if i > 0 else " "
            attached = not prev.isspace() and prev not in "([{"
            j = _find_script_close(s, i, c) if attached or c == "^" else -1
            if j != -1:
                flush()
                key = "sup" if c == "^" else "sub"
                runs.extend(parse(s[i + 1 : j], replace(style, **{key: True})))
                i = j + 1
                continue
            if (style.sup or style.sub) and attached:
                # unclosed script inside a script segment: run to segment end
                flush()
                key = "sup" if c == "^" else "sub"
                runs.extend(parse(s[i + 1 :], replace(style, **{key: True})))
                i = n
                continue
        if c == "*":
            j = _find_italic_close(s, i)
            if j != -1:
                flush()
                runs.extend(parse(s[i + 1 : j], replace(style, italic=not style.italic)))
                i = j + 1
                continue
        buf.append(c)
        i += 1
    flush()
    return _merge(runs)


def _merge(runs: list[Run]) -> list[Run]:
    out: list[Run] = []
    for r in runs:
        if not r.text:
            continue
        if out and out[-1].style == r.style:
            out[-1].text += r.text
        else:
            out.append(Run(r.text, r.style))
    return out


def plain(s: str) -> str:
    return "".join(r.text for r in parse(s))


def to_markdown(s: str) -> str:
    """Render to GitHub-flavoured Markdown + inline HTML for scripts."""
    parts: list[str] = []
    for r in parse(s):
        st = r.style
        if st.sup or st.sub:
            t = html.escape(r.text, quote=False)
            if st.italic:
                t = f"<i>{t}</i>"
            if st.bold:
                t = f"<b>{t}</b>"
            tag = "sup" if st.sup else "sub"
            parts.append(f"<{tag}>{t}</{tag}>")
            continue
        t = r.text
        if st.mono:
            parts.append(f"`{t}`")
            continue
        t = t.replace("*", r"\*").replace("_", r"\_") if (st.italic or st.bold) else t.replace("*", r"\*")
        lead = len(t) - len(t.lstrip())
        trail = len(t) - len(t.rstrip())
        core = t.strip()
        if not core:
            parts.append(t)
            continue
        mark = ("**" if st.bold else "") + ("*" if st.italic else "")
        parts.append(t[:lead] + mark + core + mark[::-1] + (t[len(t) - trail :] if trail else ""))
    return "".join(parts)


if __name__ == "__main__":
    tests = [
        "*pK*~*a*~ = 7.11 and *χ*~*c*~^ref^ (~1.5 yr)",
        "[Author 1]^1,*^, [Author 2]^1^",
        "*Correspondence: x@y.edu",
        "[1 + (*χ*~*c*~(pH)/*χ*~Δ4~)^*n*~*H*^]^−1^",
        "**Figure 1. *CPEB4* biophysics.** **a**, text^3–5^",
        "`SCHEMA P < 0.05` and 10^−170^",
    ]
    for t in tests:
        print(repr(plain(t)), "|", to_markdown(t))
