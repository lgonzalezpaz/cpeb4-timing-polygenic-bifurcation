"""Step 1: Real Biological Database Acquisition & Harmonization.

Downloads raw datasets into data/raw/ (skipping existing non-empty files),
records full SHA-256 / byte-size / HTTP-status / UTC-timestamp provenance in
data/raw/provenance.json, and harmonizes all biological datasets into clean,
analysis-ready tables in data/processed/.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import openpyxl
import pandas as pd


WORKSPACE = Path(__file__).resolve().parent.parent
RAW_DIR = WORKSPACE / "data" / "raw"
PROC_DIR = WORKSPACE / "data" / "processed"
PROVENANCE_PATH = RAW_DIR / "provenance.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BioDataEngineer/1.0"
}


# ---------------------------------------------------------------------------
# Download & Provenance Utilities
# ---------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_provenance() -> dict[str, Any]:
    if PROVENANCE_PATH.exists():
        with open(PROVENANCE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"files": {}}


def save_provenance(prov: dict[str, Any]) -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    with open(PROVENANCE_PATH, "w", encoding="utf-8") as f:
        json.dump(prov, f, indent=2)


def download_file(
    key: str,
    url: str,
    rel_path: str,
    prov: dict[str, Any],
    timeout: int = 300,
) -> Path:
    dest = RAW_DIR / rel_path
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        if key not in prov["files"]:
            prov["files"][key] = {
                "url": url,
                "local_path": str(dest.relative_to(WORKSPACE)).replace("\\", "/"),
                "byte_size": dest.stat().st_size,
                "sha256": sha256_file(dest),
                "http_status": "cached_existing",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            }
        return dest

    req = urllib.request.Request(url, headers=HEADERS)
    last_err: Exception | None = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = getattr(resp, "status", 200)
                final_url = resp.geturl()
                tmp_dest = dest.with_suffix(dest.suffix + ".part")
                with open(tmp_dest, "wb") as out:
                    while True:
                        chunk = resp.read(1024 * 256)
                        if not chunk:
                            break
                        out.write(chunk)
                tmp_dest.replace(dest)
                prov["files"][key] = {
                    "url": url,
                    "final_url": final_url,
                    "local_path": str(dest.relative_to(WORKSPACE)).replace("\\", "/"),
                    "byte_size": dest.stat().st_size,
                    "sha256": sha256_file(dest),
                    "http_status": status,
                    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                }
                print(f"[GET ] {key} -> {dest.stat().st_size:,} bytes (HTTP {status})")
                return dest
        except Exception as e:
            last_err = e
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"Failed to download {key} from {url}: {last_err}")


def fetch_opentargets_disease(
    disease_id: str,
    disease_label: str,
    rel_path: str,
    prov: dict[str, Any],
) -> Path:
    dest = RAW_DIR / rel_path
    dest.parent.mkdir(parents=True, exist_ok=True)
    url = "https://api.platform.opentargets.org/api/v4/graphql"
    if dest.exists() and dest.stat().st_size > 0:
        if f"opentargets_{disease_label}" not in prov["files"]:
            prov["files"][f"opentargets_{disease_label}"] = {
                "url": url,
                "disease_id": disease_id,
                "local_path": str(dest.relative_to(WORKSPACE)).replace("\\", "/"),
                "byte_size": dest.stat().st_size,
                "sha256": sha256_file(dest),
                "http_status": "cached_existing",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            }
        return dest

    all_rows: list[dict[str, Any]] = []
    page_idx = 0
    page_size = 500
    total_count = None
    disease_name = None

    while True:
        query = (
            '{ disease(efoId: "'
            + disease_id
            + '") { id name associatedTargets(page: {index: '
            + str(page_idx)
            + ", size: "
            + str(page_size)
            + "}) { count rows { target { id approvedSymbol } score datatypeScores { id score } } } } }"
        )
        req = urllib.request.Request(
            url,
            data=json.dumps({"query": query}).encode("utf-8"),
            headers={"Content-Type": "application/json", **HEADERS},
        )
        with urllib.request.urlopen(req, timeout=60) as r:
            payload = json.loads(r.read().decode("utf-8"))
        d = payload["data"]["disease"]
        if d is None:
            raise RuntimeError(f"Open Targets disease {disease_id} returned None")
        disease_name = d["name"]
        assoc = d["associatedTargets"]
        total_count = assoc["count"]
        rows = assoc["rows"]
        if not rows:
            break
        all_rows.extend(rows)
        if len(all_rows) >= total_count:
            break
        page_idx += 1

    out_obj = {
        "disease_id": disease_id,
        "disease_name": disease_name,
        "total_count": total_count,
        "fetched_count": len(all_rows),
        "rows": all_rows,
    }
    dest.write_text(json.dumps(out_obj, indent=2), encoding="utf-8")
    prov["files"][f"opentargets_{disease_label}"] = {
        "url": url,
        "disease_id": disease_id,
        "local_path": str(dest.relative_to(WORKSPACE)).replace("\\", "/"),
        "byte_size": dest.stat().st_size,
        "sha256": sha256_file(dest),
        "http_status": 200,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }
    print(f"[GQL ] OpenTargets {disease_id} ({disease_name}) -> {len(all_rows):,} targets")
    return dest


def download_all_raw() -> dict[str, Any]:
    prov = load_provenance()
    downloads = [
        ("uniprot_Q17RY0", "https://rest.uniprot.org/uniprotkb/Q17RY0.json", "uniprot/Q17RY0.json"),
        ("pmc_PMC11711090", "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id=PMC11711090&retmode=xml", "pmc/PMC11711090.xml"),
        ("pmc_PMC6217926", "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id=PMC6217926&retmode=xml", "pmc/PMC6217926.xml"),
        ("gc25_fig1_moesm6", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08289-w/MediaObjects/41586_2024_8289_MOESM6_ESM.xlsx", "garcia_cabau_2025/41586_2024_8289_MOESM6_ESM.xlsx"),
        ("gc25_fig2_moesm7", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08289-w/MediaObjects/41586_2024_8289_MOESM7_ESM.xlsx", "garcia_cabau_2025/41586_2024_8289_MOESM7_ESM.xlsx"),
        ("gc25_fig4_moesm9", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08289-w/MediaObjects/41586_2024_8289_MOESM9_ESM.xlsx", "garcia_cabau_2025/41586_2024_8289_MOESM9_ESM.xlsx"),
        ("gc25_fig5_moesm10", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08289-w/MediaObjects/41586_2024_8289_MOESM10_ESM.xlsx", "garcia_cabau_2025/41586_2024_8289_MOESM10_ESM.xlsx"),
        ("gc25_edfig6_moesm16", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08289-w/MediaObjects/41586_2024_8289_MOESM16_ESM.xlsx", "garcia_cabau_2025/41586_2024_8289_MOESM16_ESM.xlsx"),
        ("parras18_moesm3", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-018-0423-5/MediaObjects/41586_2018_423_MOESM3_ESM.xlsx", "parras_2018/41586_2018_423_MOESM3_ESM.xlsx"),
        ("parras18_moesm4", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-018-0423-5/MediaObjects/41586_2018_423_MOESM4_ESM.xlsx", "parras_2018/41586_2018_423_MOESM4_ESM.xlsx"),
        ("parras18_moesm7", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-018-0423-5/MediaObjects/41586_2018_423_MOESM7_ESM.xlsx", "parras_2018/41586_2018_423_MOESM7_ESM.xlsx"),
        ("mgi_hom_mouse_human", "https://www.informatics.jax.org/downloads/reports/HOM_MouseHumanSequence.rpt", "parras_2018/HOM_MouseHumanSequence.rpt"),
        ("brainspan_zip", "http://www.brainspan.org/api/v2/well_known_file_download/267666525", "brainspan/genes_matrix_csv.zip"),
        ("psychencode_der13", "http://resource.psychencode.org/Datasets/Derived/DEXgenes_CoExp/DER-13_Disorder_DEX_Genes.csv", "psychencode/DER-13_Disorder_DEX_Genes.csv"),
        ("psychencode_der14", "http://resource.psychencode.org/Datasets/Derived/DEXgenes_CoExp/DER-14_Disorder_DEX_Transcripts.csv", "psychencode/DER-14_Disorder_DEX_Transcripts.csv"),
        ("psychencode_der15", "http://resource.psychencode.org/Datasets/Derived/DEXgenes_CoExp/DER-15_Disorder_DifferentialSplicing.csv", "psychencode/DER-15_Disorder_DifferentialSplicing.csv"),
        ("gandal18_asd_4region", "https://raw.githubusercontent.com/mgandal/Shared-molecular-neuropathology-across-major-psychiatric-disorders-parallels-polygenic-overlap/master/results/tables/RNAseq_ASD_4region_sumstats.csv", "psychencode/RNAseq_ASD_4region_sumstats.csv"),
        ("gandal18_scz_bd_cmc", "https://raw.githubusercontent.com/mgandal/Shared-molecular-neuropathology-across-major-psychiatric-disorders-parallels-polygenic-overlap/master/results/tables/RNAseq_SCZ_BD_CMC.csv", "psychencode/RNAseq_SCZ_BD_CMC.csv"),
        ("gandal18_scz_bd_gvex", "https://raw.githubusercontent.com/mgandal/Shared-molecular-neuropathology-across-major-psychiatric-disorders-parallels-polygenic-overlap/master/results/tables/RNAseq_SCZ_BD_GVEX.csv", "psychencode/RNAseq_SCZ_BD_GVEX.csv"),
        ("psychencode_int17_scz", "http://resource.psychencode.org/Datasets/Integrative/INT-17_SCZ_High_Confidence_Gene_List.csv", "psychencode/INT-17_SCZ_High_Confidence_Gene_List.csv"),
        ("sfari_genes", "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes", "risk_catalogs/sfari_genes.csv"),
        ("fu2022_moesm3", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41588-022-01104-0/MediaObjects/41588_2022_1104_MOESM3_ESM.xlsx", "risk_catalogs/41588_2022_1104_MOESM3_ESM.xlsx"),
        ("schema2022_moesm3", "https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-022-04556-w/MediaObjects/41586_2022_4556_MOESM3_ESM.xlsx", "risk_catalogs/41586_2022_4556_MOESM3_ESM.xlsx"),
        ("syngo_home", "https://www.syngoportal.org/", "risk_catalogs/syngoportal.html"),
        ("syngo_release_1_3", "https://www.syngoportal.org/data/syngo1.3_complete_data.zip", "risk_catalogs/syngo1.3_complete_data.zip"),
    ]
    for key, url, rel in downloads:
        download_file(key, url, rel, prov)
        save_provenance(prov)

    # Ensembl BioMart human gene coordinates & biotype
    biomart_xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        "<!DOCTYPE Query>"
        '<Query virtualSchemaName="default" formatter="TSV" header="1" uniqueRows="1" count="" datasetConfigVersion="0.6">'
        '<Dataset name="hsapiens_gene_ensembl" interface="default">'
        '<Attribute name="ensembl_gene_id"/>'
        '<Attribute name="hgnc_symbol"/>'
        '<Attribute name="chromosome_name"/>'
        '<Attribute name="start_position"/>'
        '<Attribute name="end_position"/>'
        '<Attribute name="gene_biotype"/>'
        "</Dataset></Query>"
    )
    biomart_url = "https://www.ensembl.org/biomart/martservice?query=" + urllib.parse.quote(biomart_xml)
    download_file("ensembl_biomart_genes", biomart_url, "risk_catalogs/ensembl_biomart_genes.tsv", prov)
    save_provenance(prov)

    # Open Targets GraphQL (MONDO_0005090 Schizophrenia, MONDO_0005258 Autism spectrum disorder)
    fetch_opentargets_disease("MONDO_0005090", "scz", "risk_catalogs/opentargets_scz.json", prov)
    fetch_opentargets_disease("MONDO_0005258", "asd", "risk_catalogs/opentargets_asd.json", prov)
    save_provenance(prov)

    # Extract BrainSpan archive if needed
    bs_dir = RAW_DIR / "brainspan"
    if not (bs_dir / "expression_matrix.csv").exists():
        with zipfile.ZipFile(bs_dir / "genes_matrix_csv.zip", "r") as zf:
            zf.extractall(bs_dir)
    return prov


# ---------------------------------------------------------------------------
# 1. UniProt & PMC Literature Verification
# ---------------------------------------------------------------------------

def parse_uniprot_and_pmc() -> dict[str, Any]:
    up = json.loads((RAW_DIR / "uniprot" / "Q17RY0.json").read_text(encoding="utf-8"))
    seq = up["sequence"]["value"]

    alt_features = []
    his_cluster = None
    for feat in up.get("features", []):
        ftype = feat.get("type", "")
        loc = feat.get("location", {})
        s = loc.get("start", {}).get("value")
        e = loc.get("end", {}).get("value")
        if ftype == "Alternative sequence":
            alt_features.append(
                {
                    "feature_id": feat.get("featureId"),
                    "description": feat.get("description"),
                    "start": s,
                    "end": e,
                    "subseq": seq[s - 1 : e] if isinstance(s, int) and isinstance(e, int) else None,
                }
            )
        if ftype == "Compositional bias" and s == 232 and e == 249:
            his_cluster = {
                "start": s,
                "end": e,
                "midpoint": (s + e) / 2.0,
                "description": feat.get("description"),
                "subseq": seq[s - 1 : e],
                "histidine_count": seq[s - 1 : e].count("H"),
            }

    # Verify microexon 4 coordinates:
    # Garcia-Cabau 2025 PMC11711090 specifies nt 1258-1281 deleted in Q17RY0-1 -> aa 420-427
    me4_aa_1based = (420, 427)
    me4_seq = seq[me4_aa_1based[0] - 1 : me4_aa_1based[1]]

    pmc_gc25 = re.sub(r"<[^>]+>", " ", (RAW_DIR / "pmc" / "PMC11711090.xml").read_text(encoding="utf-8", errors="ignore"))
    pmc_gc25 = re.sub(r"\s+", " ", pmc_gc25)
    pmc_p18 = re.sub(r"<[^>]+>", " ", (RAW_DIR / "pmc" / "PMC6217926.xml").read_text(encoding="utf-8", errors="ignore"))
    pmc_p18 = re.sub(r"\s+", " ", pmc_p18)

    dpsi_matches = re.findall(r"ΔPSI\s*=\s*[-–]?\d+(?:\.\d+)?", pmc_p18)
    nt_match = re.search(r"nucleotides\s+1258[–-]1281", pmc_gc25)
    hclust_match = re.search(r"cluster of histidine residues \(HClust\) centered on position 240", pmc_gc25)

    out = {
        "uniprot_accession": up["primaryAccession"],
        "uniprot_id": up["uniProtkbId"],
        "canonical_length_aa": len(seq),
        "microexon4_nt_coordinates_Q17RY0_1": "1258-1281 (24 nt)",
        "microexon4_aa_coordinates_1based": list(me4_aa_1based),
        "microexon4_aa_sequence": me4_seq,
        "exon3_flank_VSP_022041": seq[402:419],
        "isoform_alternative_features": alt_features,
        "histidine_cluster_uniprot": his_cluster,
        "pmc11711090_verified_nt_mention": nt_match.group(0) if nt_match else None,
        "pmc11711090_verified_hclust_mention": hclust_match.group(0) if hclust_match else None,
        "pmc6217926_verified_cortical_dpsi_mentions": dpsi_matches,
    }
    (PROC_DIR / "cpeb4_sequence_and_literature_verified.json").write_text(
        json.dumps(out, indent=2), encoding="utf-8"
    )
    return out


# ---------------------------------------------------------------------------
# 2. Garcia-Cabau et al. (2025) Source Data
# ---------------------------------------------------------------------------

def parse_garcia_cabau_2025() -> dict[str, pd.DataFrame]:
    gc_dir = RAW_DIR / "garcia_cabau_2025"

    # --- A. Fig. 4c & Fig. 4d -> gc25_fig4_tc_and_agg.csv ---
    wb9 = openpyxl.load_workbook(gc_dir / "41586_2024_8289_MOESM9_ESM.xlsx", data_only=True)
    records_fig4: list[dict[str, Any]] = []

    # Fig. 4c: Cloud points Tc vs chi_delta4
    ws4c = wb9["Fig.4c"]
    rows4c = list(ws4c.iter_rows(values_only=True))
    chi_vals_4c = [float(x) for x in rows4c[3][1:9]]
    for r in rows4c[4:7]:  # N=1, N=2, N=3
        rep = str(r[0]).strip()
        for j, chi in enumerate(chi_vals_4c):
            val = r[1 + j]
            if val is not None:
                records_fig4.append(
                    {
                        "source_sheet": "Fig.4c",
                        "metric": "cloud_point_Tc_C",
                        "channel": "turbidity",
                        "chi_delta4": chi,
                        "replicate": rep,
                        "fov": np.nan,
                        "value": float(val),
                    }
                )

    # Fig. 4d: Aggregation of different isoform ratios (two sub-tables: nCPEB4 DL488, nCPEB4d4 AF647)
    ws4d = wb9["Fig.4d"]
    rows4d = list(ws4d.iter_rows(values_only=True))
    subtables_4d = [
        ("nCPEB4_DL488", 4, 5, 15),
        ("nCPEB4d4_AF647", 21, 22, 32),
    ]
    for channel, hdr_idx, start_idx, end_idx in subtables_4d:
        chi_vals = [float(x) for x in rows4d[hdr_idx][2:10]]
        cur_rep = None
        for r in rows4d[start_idx:end_idx]:
            if r[0] is not None:
                cur_rep = str(r[0]).strip()
            fov = int(r[1])
            for j, chi in enumerate(chi_vals):
                raw_v = r[2 + j]
                if raw_v is None or str(raw_v).strip() == "NA":
                    continue
                records_fig4.append(
                    {
                        "source_sheet": "Fig.4d",
                        "metric": "aggregation_pct_area",
                        "channel": channel,
                        "chi_delta4": chi,
                        "replicate": cur_rep,
                        "fov": fov,
                        "value": float(raw_v),
                    }
                )

    df_fig4 = pd.DataFrame(records_fig4)
    df_fig4.to_csv(PROC_DIR / "gc25_fig4_tc_and_agg.csv", index=False)

    # --- B. ED Fig. 6d, ED Fig. 6e & Fig. 2e -> gc25_edfig6_ph_and_agg.csv ---
    wb16 = openpyxl.load_workbook(gc_dir / "41586_2024_8289_MOESM16_ESM.xlsx", data_only=True)
    wb7 = openpyxl.load_workbook(gc_dir / "41586_2024_8289_MOESM7_ESM.xlsx", data_only=True)
    records_ed6: list[dict[str, Any]] = []

    # ED Fig. 6d: Cloud point as a function of pH for Ctrl and ASD isoform ratios
    rows6d = list(wb16["ED Fig.6d"].iter_rows(values_only=True))
    for cond, hdr_row, r_start, r_end in [("Ctrl_ratio", 4, 5, 8), ("ASD_ratio", 14, 15, 18)]:
        phs = [float(x) for x in rows6d[hdr_row][1:4]]
        for r in rows6d[r_start:r_end]:
            rep = str(r[0]).strip()
            for j, ph in enumerate(phs):
                raw_v = r[1 + j]
                s_v = str(raw_v).strip()
                is_cens = s_v.startswith("<") or s_v.startswith(">")
                num_v = np.nan if is_cens else float(raw_v)
                records_ed6.append(
                    {
                        "source_sheet": "ED Fig.6d",
                        "metric": "cloud_point_Tc_C",
                        "condition": cond,
                        "pH": ph,
                        "day": np.nan,
                        "replicate": rep,
                        "fov": np.nan,
                        "value_numeric": num_v,
                        "value_raw": s_v,
                        "is_censored": is_cens,
                    }
                )

    # Fig. 2e: Cloud point of nCPEB4-NTD as a function of pH
    rows2e = list(wb7["Fig.2e"].iter_rows(values_only=True))
    phs_2e = [float(x) for x in rows2e[3][1:4]]
    for r in rows2e[4:7]:
        rep = str(r[0]).strip()
        for j, ph in enumerate(phs_2e):
            raw_v = r[1 + j]
            s_v = str(raw_v).strip()
            is_cens = s_v.startswith("<") or s_v.startswith(">")
            num_v = np.nan if is_cens else float(raw_v)
            records_ed6.append(
                {
                    "source_sheet": "Fig.2e",
                    "metric": "cloud_point_Tc_C",
                    "condition": "nCPEB4_NTD",
                    "pH": ph,
                    "day": np.nan,
                    "replicate": rep,
                    "fov": np.nan,
                    "value_numeric": num_v,
                    "value_raw": s_v,
                    "is_censored": is_cens,
                }
            )

    # ED Fig. 6e: Aggregation of isoform ratios at pH 6.0 and pH 8.0 across 0, 1, 2, 7 days
    rows6e = list(wb16["ED Fig.6e"].iter_rows(values_only=True))
    day_blocks = [(4, 6, 15, 0), (19, 21, 30, 1), (34, 36, 45, 2), (49, 51, 60, 7)]
    conds_6e = ["nCPEB4", "Ctrl_ratio", "ASD_ratio", "nCPEB4d4"]
    for _, r_start, r_end, day in day_blocks:
        # Left block: pH 6.0 (cols 0..5), Right block: pH 8.0 (cols 7..12)
        for ph_val, col_off in [(6.0, 0), (8.0, 7)]:
            cur_rep = None
            for r in rows6e[r_start:r_end]:
                if r[col_off] is not None:
                    cur_rep = str(r[col_off]).strip()
                fov = int(r[col_off + 1])
                for j, cond in enumerate(conds_6e):
                    val = r[col_off + 2 + j]
                    if val is None:
                        continue
                    records_ed6.append(
                        {
                            "source_sheet": "ED Fig.6e",
                            "metric": "aggregation_pct_area",
                            "condition": cond,
                            "pH": ph_val,
                            "day": day,
                            "replicate": cur_rep,
                            "fov": fov,
                            "value_numeric": float(val),
                            "value_raw": str(val),
                            "is_censored": False,
                        }
                    )

    df_ed6 = pd.DataFrame(records_ed6)
    df_ed6.to_csv(PROC_DIR / "gc25_edfig6_ph_and_agg.csv", index=False)

    # --- C. Proteostat & KCl Depolarization Kinetics -> gc25_proteostat_and_kinetics.csv ---
    wb6 = openpyxl.load_workbook(gc_dir / "41586_2024_8289_MOESM6_ESM.xlsx", data_only=True)
    wb10 = openpyxl.load_workbook(gc_dir / "41586_2024_8289_MOESM10_ESM.xlsx", data_only=True)
    records_kin: list[dict[str, Any]] = []

    # Fig. 4j: In vivo Proteostat positive foci in mice brain slices
    rows4j = list(wb9["Fig.4j"].iter_rows(values_only=True))
    for r in rows4j[5:]:
        # Control: cols 0,1,2
        if r[0] is not None:
            records_kin.append(
                {
                    "source_sheet": "Fig.4j",
                    "assay": "proteostat_foci_mouse_brain",
                    "condition": "Control",
                    "unit_id": f"Cell_{int(r[0])}_Mouse_{int(r[1])}",
                    "mouse_id": str(int(r[1])),
                    "x_var": "genotype",
                    "x_val": 0.0,
                    "y_metric": "proteostat_positive_foci",
                    "y_val": float(r[2]),
                }
            )
        # TgCPEB4Δ4: cols 4,5,6
        if len(r) > 6 and r[4] is not None:
            records_kin.append(
                {
                    "source_sheet": "Fig.4j",
                    "assay": "proteostat_foci_mouse_brain",
                    "condition": "TgCPEB4d4",
                    "unit_id": f"Cell_{int(r[4])}_Mouse_{int(r[5])}",
                    "mouse_id": str(int(r[5])),
                    "x_var": "genotype",
                    "x_val": 1.0,
                    "y_metric": "proteostat_positive_foci",
                    "y_val": float(r[6]),
                }
            )

    # Fig. 2b: Normalized condensed fraction of nCPEB4 upon KCl stimulation
    rows2b = list(wb7["Fig.2b"].iter_rows(values_only=True))
    hdr2b = rows2b[4]
    for r in rows2b[5:]:
        if r[0] is None:
            continue
        t_min = float(r[0])
        for c_idx in range(3, len(hdr2b)):
            if hdr2b[c_idx] is None or r[c_idx] is None:
                continue
            records_kin.append(
                {
                    "source_sheet": "Fig.2b",
                    "assay": "kcl_depolarization_condensate_dissolution",
                    "condition": "nCPEB4_KCl",
                    "unit_id": str(hdr2b[c_idx]).strip(),
                    "mouse_id": "",
                    "x_var": "TimeKCl_min",
                    "x_val": t_min,
                    "y_metric": "normalized_condensed_fraction",
                    "y_val": float(r[c_idx]),
                }
            )

    # Fig. 2c: Intracellular pH changes in N2a cells upon KCl stimulation
    rows2c = list(wb7["Fig.2c"].iter_rows(values_only=True))
    hdr2c = rows2c[4]
    for r in rows2c[5:]:
        if r[0] is None:
            continue
        t_min = float(r[0])
        for c_idx in range(3, len(hdr2c)):
            if hdr2c[c_idx] is None or r[c_idx] is None:
                continue
            records_kin.append(
                {
                    "source_sheet": "Fig.2c",
                    "assay": "kcl_depolarization_intracellular_pH",
                    "condition": "N2a_KCl",
                    "unit_id": str(hdr2c[c_idx]).strip(),
                    "mouse_id": "",
                    "x_var": "TimeKCl_min",
                    "x_val": t_min,
                    "y_metric": "delta_pH",
                    "y_val": float(r[c_idx]),
                }
            )

    # Fig. 1h & Fig. 1j: % cells with foci after KCl stimulation
    rows1h = list(wb6["Fig.1h"].iter_rows(values_only=True))
    for r in rows1h[3:]:
        if r[0] is not None and r[2] is not None:
            records_kin.append(
                {
                    "source_sheet": "Fig.1h",
                    "assay": "kcl_primary_striatal_neurons_foci",
                    "condition": "mEGFP_CPEB4_KCl",
                    "unit_id": str(r[0]).strip(),
                    "mouse_id": "",
                    "x_var": "n_cells",
                    "x_val": float(r[1]),
                    "y_metric": "cells_with_foci_pct",
                    "y_val": float(r[2]),
                }
            )

    rows1j = list(wb6["Fig.1j"].iter_rows(values_only=True))
    for r in rows1j[4:7]:  # N=1, N=2, N=3
        rep = str(r[0]).strip()
        for cond, n_col, pct_col in [("FL", 1, 3), ("NTD", 2, 4)]:
            records_kin.append(
                {
                    "source_sheet": "Fig.1j",
                    "assay": "kcl_n2a_cells_foci",
                    "condition": cond,
                    "unit_id": rep,
                    "mouse_id": "",
                    "x_var": "n_cells",
                    "x_val": float(r[n_col]),
                    "y_metric": "cells_with_foci_pct",
                    "y_val": float(r[pct_col]),
                }
            )

    # Fig. 5d: Temperature reversibility Tc across thermal cycles 0..3
    rows5d = list(wb10["Fig.5d"].iter_rows(values_only=True))
    # Scan for N=1..3 rows in blocks
    cur_cond = "nCPEB4"
    for r in rows5d:
        if r[0] is not None and str(r[0]).strip() in ("nCPEB4", "nCPEB4Δ4", "nCPEB4Δ4 + peptide"):
            cur_cond = str(r[0]).strip().replace("Δ4", "d4").replace(" + ", "_plus_")
        if r[0] is not None and str(r[0]).strip().startswith("N="):
            rep = str(r[0]).strip()
            for cyc in range(4):
                if r[1 + cyc] is not None and isinstance(r[1 + cyc], (int, float)):
                    records_kin.append(
                        {
                            "source_sheet": "Fig.5d",
                            "assay": "thermal_reversibility_Tc",
                            "condition": cur_cond,
                            "unit_id": rep,
                            "mouse_id": "",
                            "x_var": "cycle",
                            "x_val": float(cyc),
                            "y_metric": "Tc_C",
                            "y_val": float(r[1 + cyc]),
                        }
                    )

    df_kin = pd.DataFrame(records_kin)
    df_kin.to_csv(PROC_DIR / "gc25_proteostat_and_kinetics.csv", index=False)

    for wb in (wb6, wb7, wb9, wb10, wb16):
        wb.close()

    return {"fig4": df_fig4, "ed6": df_ed6, "kin": df_kin}


# ---------------------------------------------------------------------------
# 3. Parras et al. (2018) Mouse RIP-seq & Poly(A) Tail + MGI Ortholog Mapping
# ---------------------------------------------------------------------------

def build_mouse_to_human_map(human_symbols: set[str], syngo_synonyms: dict[str, str]) -> dict[str, str]:
    """Build deterministic mouse -> human HGNC symbol map using official MGI HOM_MouseHumanSequence.rpt."""
    rpt_path = RAW_DIR / "parras_2018" / "HOM_MouseHumanSequence.rpt"
    df = pd.read_csv(rpt_path, sep="\t", low_memory=False)
    # Columns: DB Class Key, Common Organism Name, NCBI Taxon ID, Symbol, ...
    mouse_rows = df[df["NCBI Taxon ID"] == 10090][["DB Class Key", "Symbol"]].dropna()
    human_rows = df[df["NCBI Taxon ID"] == 9606][["DB Class Key", "Symbol"]].dropna()
    merged = mouse_rows.merge(human_rows, on="DB Class Key", suffixes=("_mouse", "_human"))

    mgi_map: dict[str, str] = {}
    for _, row in merged.iterrows():
        ms = str(row["Symbol_mouse"]).strip()
        hs = str(row["Symbol_human"]).strip()
        if ms not in mgi_map:
            mgi_map[ms] = hs
        elif hs in human_symbols and mgi_map[ms] not in human_symbols:
            mgi_map[ms] = hs
    return mgi_map


def parse_parras_2018(
    brainspan_symbols: set[str],
    all_human_symbols: set[str],
    syngo_synonyms: dict[str, str],
) -> pd.DataFrame:
    mgi_map = build_mouse_to_human_map(all_human_symbols, syngo_synonyms)
    wb = openpyxl.load_workbook(
        RAW_DIR / "parras_2018" / "41586_2018_423_MOESM3_ESM.xlsx",
        read_only=True,
        data_only=True,
    )

    # Supplementary Table 1a (probes -> mouse symbol aggregation)
    ws1a = wb["Supplementary Table 1a"]
    probe_rows = []
    for i, r in enumerate(ws1a.iter_rows(values_only=True)):
        if i < 5:
            continue
        if r[0] is None and r[1] is None:
            continue
        sym = str(r[1]).strip() if r[1] is not None else ""
        if not sym:
            continue
        c1_plus = "+" in str(r[5]) if r[5] is not None else False
        c4_plus = "+" in str(r[8]) if r[8] is not None else False
        probe_rows.append(
            {
                "mouse_symbol": sym,
                "mouse_gene_name": str(r[2]).strip() if r[2] is not None else "",
                "cpeb1_fc_wt": float(r[3]) if isinstance(r[3], (int, float)) else np.nan,
                "cpeb1_fc_hd": float(r[4]) if isinstance(r[4], (int, float)) else np.nan,
                "cpeb1_plus": c1_plus,
                "cpeb4_fc_wt": float(r[6]) if isinstance(r[6], (int, float)) else np.nan,
                "cpeb4_fc_hd": float(r[7]) if isinstance(r[7], (int, float)) else np.nan,
                "cpeb4_plus": c4_plus,
                "c1_c4_class": str(r[9]).strip() if r[9] is not None else "",
            }
        )
    df1a = pd.DataFrame(probe_rows)
    agg1a = (
        df1a.groupby("mouse_symbol", as_index=False)
        .agg(
            mouse_gene_name=("mouse_gene_name", "first"),
            n_probes=("mouse_symbol", "size"),
            cpeb4_binder=("cpeb4_plus", "any"),
            cpeb1_binder=("cpeb1_plus", "any"),
            cpeb4_fc_wt_max=("cpeb4_fc_wt", "max"),
            cpeb4_fc_wt_mean=("cpeb4_fc_wt", "mean"),
            cpeb4_fc_hd_max=("cpeb4_fc_hd", "max"),
            cpeb4_fc_hd_mean=("cpeb4_fc_hd", "mean"),
            cpeb1_fc_wt_max=("cpeb1_fc_wt", "max"),
            cpeb1_fc_hd_max=("cpeb1_fc_hd", "max"),
        )
    )

    # Supplementary Table 1b (poly(A) shortened transcripts in HD mice & CPEB4 binders in WT)
    ws1b = wb["Supplementary Table 1b"]
    rows1b = []
    for i, r in enumerate(ws1b.iter_rows(values_only=True)):
        if i < 2 or r[2] is None:
            continue
        rows1b.append(
            {
                "mouse_symbol": str(r[2]).strip(),
                "polya_rank": int(r[0]) if r[0] is not None else np.nan,
                "polya_fc_hd": float(r[1]) if r[1] is not None else np.nan,
                "polya_table_cpeb1_binding": str(r[4]).strip() if r[4] is not None else "",
            }
        )
    df1b = pd.DataFrame(rows1b).sort_values("polya_fc_hd").drop_duplicates("mouse_symbol", keep="first")
    wb.close()

    merged = agg1a.merge(df1b, on="mouse_symbol", how="outer")
    merged["cpeb4_binder"] = merged["cpeb4_binder"].fillna(False)
    merged["cpeb1_binder"] = merged["cpeb1_binder"].fillna(False)
    merged["polya_shortened_hd"] = merged["polya_fc_hd"].notna()

    def map_sym(ms: str) -> tuple[str, str]:
        if ms in mgi_map:
            hs = mgi_map[ms]
            if hs in all_human_symbols:
                return hs, "mgi_ortholog"
            if hs.upper() in syngo_synonyms:
                return syngo_synonyms[hs.upper()], "mgi_plus_synonym"
            return hs, "mgi_ortholog_not_in_universe"
        up = ms.upper()
        if up in all_human_symbols:
            return up, "uppercase_direct"
        if up in syngo_synonyms:
            return syngo_synonyms[up], "syngo_synonym"
        return "", "unmapped"

    mapped_pairs = [map_sym(s) for s in merged["mouse_symbol"]]
    merged["human_symbol"] = [p[0] for p in mapped_pairs]
    merged["mapping_method"] = [p[1] for p in mapped_pairs]
    merged["in_brainspan"] = merged["human_symbol"].isin(brainspan_symbols)

    def bclass(row: pd.Series) -> str:
        if row["cpeb4_binder"] and row["cpeb1_binder"]:
            return "Common"
        if row["cpeb4_binder"]:
            return "CPEB4_only"
        if row["cpeb1_binder"]:
            return "CPEB1_only"
        return "Non_binder"

    merged["binding_class"] = merged.apply(bclass, axis=1)
    merged.to_csv(PROC_DIR / "cpeb4_targets_parras2018.csv", index=False)
    return merged


# ---------------------------------------------------------------------------
# 4. BrainSpan Atlas Parsing & Module Trajectories
# ---------------------------------------------------------------------------

def parse_age_to_pcw(age_str: str) -> float:
    s = str(age_str).strip().lower()
    m = re.match(r"^(\d+(?:\.\d+)?)\s*(pcw|mos|yrs)$", s)
    if not m:
        raise ValueError(f"Unrecognized BrainSpan age format: {age_str!r}")
    val = float(m.group(1))
    unit = m.group(2)
    if unit == "pcw":
        return val
    if unit == "mos":
        return 38.0 + val * 4.33
    if unit == "yrs":
        return 38.0 + val * 52.14
    raise ValueError(f"Unhandled unit: {unit}")


def assign_kang_stage(age_pcw: float) -> str:
    if age_pcw < 10.0:
        return "S1_Early_fetal_8_9pcw"
    if age_pcw < 13.0:
        return "S2_Early_mid_fetal_10_12pcw"
    if age_pcw < 19.0:
        return "S3_Early_mid_fetal_13_18pcw"
    if age_pcw < 25.0:
        return "S4_Late_mid_fetal_19_24pcw"
    if age_pcw < 38.0:
        return "S5_Late_fetal_25_37pcw"
    if age_pcw < 90.0:
        return "S6_Infancy_4_10mos"
    if age_pcw < 350.0:
        return "S7_Early_childhood_1_5yrs"
    if age_pcw < 660.0:
        return "S8_Late_childhood_6_11yrs"
    if age_pcw < 1080.0:
        return "S9_Adolescence_12_19yrs"
    return "S10_Adulthood_20plus_yrs"


def parse_brainspan() -> tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
    bs_dir = RAW_DIR / "brainspan"
    cols_df = pd.read_csv(bs_dir / "columns_metadata.csv")
    rows_df = pd.read_csv(bs_dir / "rows_metadata.csv")

    # Verify every unique age string
    cols_df["age_pcw"] = cols_df["age"].apply(parse_age_to_pcw)
    cols_df["log2_pcw"] = np.log2(cols_df["age_pcw"])
    cols_df["dev_stage"] = cols_df["age_pcw"].apply(assign_kang_stage)
    cols_df["is_prenatal"] = cols_df["age_pcw"] < 38.0
    pfc_acronyms = {"DFC", "MFC", "OFC", "VFC"}
    neocortex_acronyms = {
        "DFC", "MFC", "OFC", "VFC", "M1C", "S1C", "M1C-S1C",
        "IPC", "A1C", "STC", "ITC", "V1C", "Ocx", "PCx", "TCx",
    }
    cols_df["is_pfc"] = cols_df["structure_acronym"].isin(pfc_acronyms)
    cols_df["is_neocortex"] = cols_df["structure_acronym"].isin(neocortex_acronyms)
    cols_df.to_csv(PROC_DIR / "brainspan_metadata.csv", index=False)

    # Load expression_matrix.csv fast (first col is row_num 1..52376, remaining 524 cols are RPKM)
    mat_df = pd.read_csv(bs_dir / "expression_matrix.csv", header=None)
    assert mat_df.shape == (len(rows_df), len(cols_df) + 1), f"Unexpected matrix shape {mat_df.shape}"
    assert np.array_equal(mat_df.iloc[:, 0].to_numpy(), rows_df["row_num"].to_numpy()), "Row index mismatch"
    rpkm = mat_df.iloc[:, 1:].to_numpy(dtype=np.float32)
    log2_rpkm = np.log2(rpkm + np.float32(1.0))

    rows_df["mean_rpkm"] = rpkm.mean(axis=1)
    rows_df["mean_log2_rpkm"] = log2_rpkm.mean(axis=1)
    rows_df["max_rpkm"] = rpkm.max(axis=1)
    rows_df.to_csv(PROC_DIR / "brainspan_gene_info.csv", index=False)

    np.savez_compressed(
        PROC_DIR / "brainspan_log2rpkm.npz",
        log2_rpkm=log2_rpkm,
        ensembl_gene_id=rows_df["ensembl_gene_id"].to_numpy(),
        gene_symbol=rows_df["gene_symbol"].to_numpy(),
        column_num=cols_df["column_num"].to_numpy(),
    )

    # Extract module trajectories
    module_genes = [
        # CPEB family
        "CPEB4", "CPEB1", "CPEB2", "CPEB3",
        # Splicing regulators
        "SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "PTBP1", "PTBP2", "HNRNPC", "ELAVL2", "ELAVL3", "ELAVL4",
        # Kinases
        "MAPK1", "MAPK3", "CAMK2A", "CAMK2B", "AURKA", "CDK1",
        # Synaptogenesis markers
        "SYP", "DLG4", "SNAP25", "SYN1", "GRIN2B", "GRIN2A", "SLC17A7", "GAD1", "NRXN1", "SHANK3",
        # Complement & microglial pruning markers
        "C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "ITGAM", "ITGB2", "TREM2", "TYROBP",
        "CX3CR1", "P2RY12", "CD68", "CSF1R", "C3AR1", "PROS1", "MERTK",
    ]
    traj = cols_df.copy()
    sym_to_idx = {s: idx for idx, s in enumerate(rows_df["gene_symbol"])}
    for g in module_genes:
        if g in sym_to_idx:
            traj[g] = log2_rpkm[sym_to_idx[g], :]
        else:
            traj[g] = np.nan
    traj.to_csv(PROC_DIR / "brainspan_module_trajectories.csv", index=False)

    return cols_df, rows_df, log2_rpkm


# ---------------------------------------------------------------------------
# 5. PsychENCODE (DER-13, DER-14, DER-15)
# ---------------------------------------------------------------------------

def parse_psychencode() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pe_dir = RAW_DIR / "psychencode"

    der13 = pd.read_csv(pe_dir / "DER-13_Disorder_DEX_Genes.csv")
    der13[["Disorder", "Direction"]] = der13["Disorder.DGE_RegulationDirection"].str.extract(r"^(ASD|SCZ|BD)\.DGE_(up|down)$")
    der13.to_csv(PROC_DIR / "psychencode_der13.csv", index=False)

    der14 = pd.read_csv(pe_dir / "DER-14_Disorder_DEX_Transcripts.csv")
    der14[["Disorder", "Direction"]] = der14["Disorder.DTE_RegulationDirection"].str.extract(r"^(ASD|SCZ|BD)\.DTE_(up|down)$")
    cpeb_rows = der14[der14["Gene_Name"].astype(str).str.startswith("CPEB")].copy()
    summary_14 = (
        der14.groupby(["Disorder", "Direction"], as_index=False)
        .agg(n_transcripts=("Ensembl_Transcript", "nunique"), n_genes=("Ensembl_Gene", "nunique"))
    )
    summary_14["record_type"] = "summary"
    if not cpeb_rows.empty:
        cpeb_rows["record_type"] = "cpeb_transcript"
        der14_out = pd.concat([summary_14, cpeb_rows], ignore_index=True)
    else:
        # Explicitly document zero CPEB-family transcripts in DER-14
        summary_14["cpeb_family_hits_in_der14"] = 0
        der14_out = summary_14
    der14_out.to_csv(PROC_DIR / "psychencode_der14_cpeb4_and_summary.csv", index=False)

    der15 = pd.read_csv(pe_dir / "DER-15_Disorder_DifferentialSplicing.csv")
    der15["Disorder"] = der15["Disorder.DS_leaf(cutter)"].str.replace(".DS_leaf", "", regex=False)
    der15.to_csv(PROC_DIR / "psychencode_der15.csv", index=False)

    return der13, der14, der15


def parse_gandal_continuous(bs_rows: pd.DataFrame) -> pd.DataFrame:
    """Parse continuous cortical RNA-seq summary stats from Gandal et al. (2018) & INT-17."""
    pe_dir = RAW_DIR / "psychencode"
    rc_dir = RAW_DIR / "risk_catalogs"

    asd = pd.read_csv(pe_dir / "RNAseq_ASD_4region_sumstats.csv").rename(columns={"Unnamed: 0": "ensembl_gene_id"})
    asd_keep = asd[
        [
            "ensembl_gene_id",
            "All.logFC", "All.AveExpr", "All.t", "All.P.Value", "All.adj.P.Val",
            "Frontal.logFC", "Frontal.t", "Frontal.P.Value", "Frontal.adj.P.Val",
            "Temporal.logFC", "Temporal.P.Value", "Temporal.adj.P.Val",
            "Parietal.logFC", "Parietal.P.Value", "Parietal.adj.P.Val",
            "Occipital.logFC", "Occipital.P.Value", "Occipital.adj.P.Val",
        ]
    ].rename(
        columns={
            "All.logFC": "asd_all_logFC",
            "All.AveExpr": "asd_all_AveExpr",
            "All.t": "asd_all_t",
            "All.P.Value": "asd_all_P_Value",
            "All.adj.P.Val": "asd_all_adj_P_Val",
            "Frontal.logFC": "asd_frontal_logFC",
            "Frontal.t": "asd_frontal_t",
            "Frontal.P.Value": "asd_frontal_P_Value",
            "Frontal.adj.P.Val": "asd_frontal_adj_P_Val",
            "Temporal.logFC": "asd_temporal_logFC",
            "Temporal.P.Value": "asd_temporal_P_Value",
            "Temporal.adj.P.Val": "asd_temporal_adj_P_Val",
            "Parietal.logFC": "asd_parietal_logFC",
            "Parietal.P.Value": "asd_parietal_P_Value",
            "Parietal.adj.P.Val": "asd_parietal_adj_P_Val",
            "Occipital.logFC": "asd_occipital_logFC",
            "Occipital.P.Value": "asd_occipital_P_Value",
            "Occipital.adj.P.Val": "asd_occipital_adj_P_Val",
        }
    )
    asd_keep["asd_all_SE"] = np.where(
        asd_keep["asd_all_t"] != 0,
        np.abs(asd_keep["asd_all_logFC"] / asd_keep["asd_all_t"]),
        np.nan,
    )
    asd_keep["asd_frontal_SE"] = np.where(
        asd_keep["asd_frontal_t"] != 0,
        np.abs(asd_keep["asd_frontal_logFC"] / asd_keep["asd_frontal_t"]),
        np.nan,
    )

    def _prep_scz_bd(path: Path, cohort: str) -> pd.DataFrame:
        df = pd.read_csv(path).rename(columns={"Unnamed: 0": "ensembl_gene_id"})
        keep = df[
            [
                "ensembl_gene_id",
                "SCZ.logFC", "SCZ.CI.L", "SCZ.CI.R", "SCZ.AveExpr", "SCZ.t", "SCZ.P.Value", "SCZ.adj.P.Val",
                "BD.logFC", "BD.CI.L", "BD.CI.R", "BD.t", "BD.P.Value", "BD.adj.P.Val",
            ]
        ].rename(
            columns={
                "SCZ.logFC": f"scz_{cohort}_logFC",
                "SCZ.CI.L": f"scz_{cohort}_CI_L",
                "SCZ.CI.R": f"scz_{cohort}_CI_R",
                "SCZ.AveExpr": f"scz_{cohort}_AveExpr",
                "SCZ.t": f"scz_{cohort}_t",
                "SCZ.P.Value": f"scz_{cohort}_P_Value",
                "SCZ.adj.P.Val": f"scz_{cohort}_adj_P_Val",
                "BD.logFC": f"bd_{cohort}_logFC",
                "BD.CI.L": f"bd_{cohort}_CI_L",
                "BD.CI.R": f"bd_{cohort}_CI_R",
                "BD.t": f"bd_{cohort}_t",
                "BD.P.Value": f"bd_{cohort}_P_Value",
                "BD.adj.P.Val": f"bd_{cohort}_adj_P_Val",
            }
        )
        keep[f"scz_{cohort}_SE"] = (keep[f"scz_{cohort}_CI_R"] - keep[f"scz_{cohort}_CI_L"]) / (2.0 * 1.959963984540054)
        keep[f"bd_{cohort}_SE"] = (keep[f"bd_{cohort}_CI_R"] - keep[f"bd_{cohort}_CI_L"]) / (2.0 * 1.959963984540054)
        return keep

    cmc_keep = _prep_scz_bd(pe_dir / "RNAseq_SCZ_BD_CMC.csv", "cmc")
    gvex_keep = _prep_scz_bd(pe_dir / "RNAseq_SCZ_BD_GVEX.csv", "gvex")

    int17 = pd.read_csv(pe_dir / "INT-17_SCZ_High_Confidence_Gene_List.csv")
    int17_ids = set(int17["ensembl_names"].dropna().astype(str).str.strip())
    int17_sym_map = (
        int17.dropna(subset=["ensembl_names", "sczgenenames"])
        .drop_duplicates("ensembl_names")
        .set_index("ensembl_names")["sczgenenames"]
        .to_dict()
    )

    # Symbol mapping via BrainSpan + Ensembl BioMart + INT-17
    bs_sym_map = (
        bs_rows.dropna(subset=["ensembl_gene_id", "gene_symbol"])
        .drop_duplicates("ensembl_gene_id")
        .set_index("ensembl_gene_id")["gene_symbol"]
        .to_dict()
    )
    bm_df = pd.read_csv(rc_dir / "ensembl_biomart_genes.tsv", sep="\t", usecols=["Gene stable ID", "HGNC symbol"], low_memory=False)
    bm_sym_map = (
        bm_df.dropna(subset=["Gene stable ID", "HGNC symbol"])
        .drop_duplicates("Gene stable ID")
        .set_index("Gene stable ID")["HGNC symbol"]
        .to_dict()
    )

    merged = asd_keep.merge(cmc_keep, on="ensembl_gene_id", how="outer").merge(gvex_keep, on="ensembl_gene_id", how="outer")
    merged["gene_symbol"] = (
        merged["ensembl_gene_id"]
        .map(bs_sym_map)
        .fillna(merged["ensembl_gene_id"].map(bm_sym_map))
        .fillna(merged["ensembl_gene_id"].map(int17_sym_map))
        .fillna("")
    )
    merged["is_int17_scz_hc"] = merged["ensembl_gene_id"].isin(int17_ids)

    # Place identifiers first
    id_cols = ["ensembl_gene_id", "gene_symbol", "is_int17_scz_hc"]
    other_cols = [c for c in merged.columns if c not in id_cols]
    merged = merged[id_cols + other_cols]
    merged.to_csv(PROC_DIR / "gandal2018_continuous_sumstats.csv", index=False)
    return merged


# ---------------------------------------------------------------------------
# 6. Risk Catalogs + SynGO + Master Harmonized Gene Universe
# ---------------------------------------------------------------------------

def load_syngo() -> tuple[pd.DataFrame, dict[str, str]]:
    zpath = RAW_DIR / "risk_catalogs" / "syngo1.3_complete_data.zip"
    with zipfile.ZipFile(zpath, "r") as zf:
        with zf.open("genes.xlsx") as f:
            genes_df = pd.read_excel(f)
        with zf.open("annotations.xlsx") as f:
            ann_df = pd.read_excel(f)

    # Synonym lookup -> canonical hgnc_symbol
    syn_map: dict[str, str] = {}
    for _, r in genes_df.iterrows():
        canon = str(r["hgnc_symbol"]).strip()
        syn_map[canon.upper()] = canon
        if pd.notna(r.get("hgnc_synonyms")):
            for s in str(r["hgnc_synonyms"]).split(","):
                s_clean = s.strip().upper()
                if s_clean and s_clean not in syn_map:
                    syn_map[s_clean] = canon

    ann_agg = (
        ann_df.groupby("hgnc_symbol", as_index=False)
        .agg(
            syngo_n_annotations=("id", "count"),
            syngo_domains=("go_domain", lambda x: ";".join(sorted(set(str(v) for v in x if pd.notna(v))))),
            syngo_go_names=("go_name", lambda x: ";".join(sorted(set(str(v) for v in x if pd.notna(v))))),
        )
    )
    ann_agg["is_syngo_presynapse"] = ann_agg["syngo_go_names"].str.contains("presynap", case=False, na=False)
    ann_agg["is_syngo_postsynapse"] = ann_agg["syngo_go_names"].str.contains("postsynap", case=False, na=False)

    syngo_df = genes_df[["hgnc_symbol", "hgnc_id", "ensembl_id"]].merge(ann_agg, on="hgnc_symbol", how="left")
    syngo_df["is_syngo"] = True
    return syngo_df, syn_map


def parse_opentargets(json_path: Path, prefix: str) -> pd.DataFrame:
    obj = json.loads(json_path.read_text(encoding="utf-8"))
    rows = []
    for item in obj["rows"]:
        dt_scores = {d["id"]: d["score"] for d in item.get("datatypeScores", [])}
        rows.append(
            {
                "ensembl_gene_id": item["target"]["id"],
                "approved_symbol": item["target"]["approvedSymbol"],
                f"ot_{prefix}_overall_score": float(item["score"]),
                f"ot_{prefix}_genetic_association": float(dt_scores.get("genetic_association", 0.0)),
            }
        )
    return pd.DataFrame(rows)


def build_harmonized_universe(
    bs_rows: pd.DataFrame,
    der13: pd.DataFrame,
    der14: pd.DataFrame,
    der15: pd.DataFrame,
    gandal_cont: pd.DataFrame,
    syngo_df: pd.DataFrame,
    parras_df: pd.DataFrame,
) -> pd.DataFrame:
    rc_dir = RAW_DIR / "risk_catalogs"

    # Base: BrainSpan 52,376 Ensembl gene rows
    univ = bs_rows[["row_num", "ensembl_gene_id", "gene_symbol", "entrez_id", "mean_rpkm", "mean_log2_rpkm", "max_rpkm"]].copy()
    univ["gene_symbol_upper"] = univ["gene_symbol"].astype(str).str.upper()

    # Mark primary representative row per unique gene_symbol (highest mean_rpkm, tie-break non-null entrez_id)
    univ = univ.sort_values(
        by=["gene_symbol", "mean_rpkm", "entrez_id"],
        ascending=[True, False, False],
        na_position="last",
    )
    univ["is_primary_symbol_row"] = ~univ.duplicated(subset=["gene_symbol"], keep="first")
    univ = univ.sort_values("row_num").reset_index(drop=True)

    # 1. Ensembl BioMart genomic length & biotype
    bm = pd.read_csv(rc_dir / "ensembl_biomart_genes.tsv", sep="\t", low_memory=False)
    bm = bm.rename(
        columns={
            "Gene stable ID": "ensembl_gene_id",
            "HGNC symbol": "biomart_hgnc_symbol",
            "Chromosome/scaffold name": "chromosome",
            "Gene start (bp)": "gene_start_bp",
            "Gene end (bp)": "gene_end_bp",
            "Gene type": "gene_biotype",
        }
    )
    bm["gene_length_bp"] = bm["gene_end_bp"] - bm["gene_start_bp"] + 1
    bm = bm.drop_duplicates("ensembl_gene_id")
    univ = univ.merge(
        bm[["ensembl_gene_id", "chromosome", "gene_length_bp", "gene_biotype"]],
        on="ensembl_gene_id",
        how="left",
    )

    # 2. SFARI Gene
    sfari = pd.read_csv(rc_dir / "sfari_genes.csv")
    sfari["sfari_symbol_upper"] = sfari["gene-symbol"].astype(str).str.upper()
    sfari_clean = (
        sfari.sort_values(["gene-score", "number-of-reports"], ascending=[True, False])
        .drop_duplicates("sfari_symbol_upper")
        [["sfari_symbol_upper", "ensembl-id", "gene-score", "syndromic", "eagle", "number-of-reports"]]
        .rename(
            columns={
                "gene-score": "sfari_score",
                "syndromic": "sfari_syndromic",
                "eagle": "sfari_eagle",
                "number-of-reports": "sfari_n_reports",
            }
        )
    )
    univ = univ.merge(
        sfari_clean.drop(columns=["ensembl-id"]),
        left_on="gene_symbol_upper",
        right_on="sfari_symbol_upper",
        how="left",
    ).drop(columns=["sfari_symbol_upper"])
    univ["is_sfari"] = univ["sfari_score"].notna() | (univ["sfari_syndromic"] == 1)

    # 3. Fu et al. 2022 TADA (Table 11 & Table 5)
    fu_path = rc_dir / "41588_2022_1104_MOESM3_ESM.xlsx"
    fu11 = pd.read_excel(
        fu_path,
        sheet_name="Supplementary Table 11",
        usecols=["gene", "gene_id", "ASD72", "ASD185", "DD309", "DD477", "NDD373", "NDD664", "FDR_TADA_ASD", "FDR_TADA_DD", "FDR_TADA_NDD", "p_TADA_ASD", "p_TADA_DD", "p_TADA_NDD"],
    )
    fu5 = pd.read_excel(
        fu_path,
        sheet_name="Supplementary Table 5",
        usecols=["gene_id", "pLI", "LOEUF", "mut.ptv", "dn.ptv", "dn.misb", "dn.misa"],
    )
    fu = fu11.merge(fu5, on="gene_id", how="left").drop_duplicates("gene_id")
    fu = fu.rename(
        columns={
            "gene_id": "ensembl_gene_id",
            "ASD72": "fu22_ASD72",
            "ASD185": "fu22_ASD185",
            "DD477": "fu22_DD477",
            "NDD664": "fu22_NDD664",
            "FDR_TADA_ASD": "fu22_FDR_TADA_ASD",
            "FDR_TADA_DD": "fu22_FDR_TADA_DD",
            "FDR_TADA_NDD": "fu22_FDR_TADA_NDD",
            "p_TADA_ASD": "fu22_p_TADA_ASD",
            "pLI": "gnomad_pLI",
            "LOEUF": "gnomad_LOEUF",
            "mut.ptv": "fu22_mut_ptv",
        }
    )
    # Primary merge on Ensembl ID, fallback on symbol if missing
    univ = univ.merge(
        fu[["ensembl_gene_id", "fu22_ASD72", "fu22_ASD185", "fu22_DD477", "fu22_NDD664", "fu22_FDR_TADA_ASD", "fu22_FDR_TADA_DD", "fu22_FDR_TADA_NDD", "fu22_p_TADA_ASD", "gnomad_pLI", "gnomad_LOEUF", "fu22_mut_ptv"]],
        on="ensembl_gene_id",
        how="left",
    )

    # 4. SCHEMA (Singh et al. 2022 Table S5)
    schema = pd.read_excel(
        rc_dir / "41586_2022_4556_MOESM3_ESM.xlsx",
        sheet_name="Table S5 - Gene Results",
        usecols=["Gene Symbol", "Case PTV", "Ctrl PTV", "P ca/co (Class 1)", "P ca/co (comb)", "P de novo", "P meta", "Q meta"],
    )
    schema["schema_sym_upper"] = schema["Gene Symbol"].astype(str).str.strip().str.upper()
    schema = (
        schema.sort_values("P meta", ascending=True, na_position="last")
        .drop_duplicates("schema_sym_upper")
        .rename(
            columns={
                "Case PTV": "schema_case_ptv",
                "Ctrl PTV": "schema_ctrl_ptv",
                "P ca/co (Class 1)": "schema_P_caco_class1",
                "P ca/co (comb)": "schema_P_caco_comb",
                "P de novo": "schema_P_denovo",
                "P meta": "schema_P_meta",
                "Q meta": "schema_Q_meta",
            }
        )
    )
    univ = univ.merge(
        schema.drop(columns=["Gene Symbol"]),
        left_on="gene_symbol_upper",
        right_on="schema_sym_upper",
        how="left",
    ).drop(columns=["schema_sym_upper"])

    # 5. Open Targets SCZ & ASD
    ot_scz = parse_opentargets(rc_dir / "opentargets_scz.json", "scz").drop_duplicates("ensembl_gene_id")
    ot_asd = parse_opentargets(rc_dir / "opentargets_asd.json", "asd").drop_duplicates("ensembl_gene_id")
    univ = univ.merge(ot_scz[["ensembl_gene_id", "ot_scz_overall_score", "ot_scz_genetic_association"]], on="ensembl_gene_id", how="left")
    univ = univ.merge(ot_asd[["ensembl_gene_id", "ot_asd_overall_score", "ot_asd_genetic_association"]], on="ensembl_gene_id", how="left")
    univ["ot_scz_overall_score"] = univ["ot_scz_overall_score"].fillna(0.0)
    univ["ot_scz_genetic_association"] = univ["ot_scz_genetic_association"].fillna(0.0)
    univ["ot_asd_overall_score"] = univ["ot_asd_overall_score"].fillna(0.0)
    univ["ot_asd_genetic_association"] = univ["ot_asd_genetic_association"].fillna(0.0)

    # 6. PsychENCODE DER-13/14/15 flags (categorical significant DGE/DTE/DS labels)
    for dis in ("ASD", "SCZ", "BD"):
        up_ids = set(der13[(der13["Disorder"] == dis) & (der13["Direction"] == "up")]["Ensembl_Name"])
        dn_ids = set(der13[(der13["Disorder"] == dis) & (der13["Direction"] == "down")]["Ensembl_Name"])
        univ[f"psychencode_{dis}_DGE"] = np.where(
            univ["ensembl_gene_id"].isin(up_ids),
            "up",
            np.where(univ["ensembl_gene_id"].isin(dn_ids), "down", "ns"),
        )
        dte_up = set(der14[(der14["Disorder"] == dis) & (der14["Direction"] == "up")]["Ensembl_Gene"])
        dte_dn = set(der14[(der14["Disorder"] == dis) & (der14["Direction"] == "down")]["Ensembl_Gene"])
        univ[f"psychencode_{dis}_DTE"] = np.where(
            univ["ensembl_gene_id"].isin(dte_up),
            "up",
            np.where(univ["ensembl_gene_id"].isin(dte_dn), "down", "ns"),
        )
        ds_ids = set(der15[der15["Disorder"] == dis]["Ensembl_Name"])
        univ[f"psychencode_{dis}_DS"] = univ["ensembl_gene_id"].isin(ds_ids)

    # 6b. Gandal et al. 2018 continuous cortical RNA-seq summary stats + INT-17
    gc_cols = [
        "ensembl_gene_id", "is_int17_scz_hc",
        "asd_all_logFC", "asd_all_SE", "asd_all_t", "asd_all_P_Value", "asd_all_adj_P_Val",
        "asd_frontal_logFC", "asd_frontal_SE", "asd_frontal_t", "asd_frontal_P_Value", "asd_frontal_adj_P_Val",
        "scz_cmc_logFC", "scz_cmc_SE", "scz_cmc_t", "scz_cmc_P_Value", "scz_cmc_adj_P_Val",
        "scz_gvex_logFC", "scz_gvex_SE", "scz_gvex_t", "scz_gvex_P_Value", "scz_gvex_adj_P_Val",
    ]
    univ = univ.merge(gandal_cont[gc_cols].drop_duplicates("ensembl_gene_id"), on="ensembl_gene_id", how="left")
    univ["is_int17_scz_hc"] = univ["is_int17_scz_hc"].fillna(False)

    # 7. SynGO 1.3
    syngo_sub = syngo_df[["ensembl_id", "hgnc_symbol", "is_syngo", "syngo_n_annotations", "syngo_domains", "is_syngo_presynapse", "is_syngo_postsynapse"]].copy()
    syngo_ens = syngo_sub.dropna(subset=["ensembl_id"]).drop_duplicates("ensembl_id")
    univ = univ.merge(
        syngo_ens.rename(columns={"ensembl_id": "ensembl_gene_id"}).drop(columns=["hgnc_symbol"]),
        on="ensembl_gene_id",
        how="left",
    )
    univ["is_syngo"] = univ["is_syngo"].fillna(False)
    univ["is_syngo_presynapse"] = univ["is_syngo_presynapse"].fillna(False)
    univ["is_syngo_postsynapse"] = univ["is_syngo_postsynapse"].fillna(False)

    # 8. Parras 2018 CPEB4 RIP-seq & poly(A) deadenylation
    p_mapped = parras_df[parras_df["human_symbol"] != ""].copy()
    p_mapped["human_sym_upper"] = p_mapped["human_symbol"].str.upper()
    p_agg = (
        p_mapped.groupby("human_sym_upper", as_index=False)
        .agg(
            parras18_cpeb4_binder=("cpeb4_binder", "any"),
            parras18_cpeb1_binder=("cpeb1_binder", "any"),
            parras18_cpeb4_fc_wt_max=("cpeb4_fc_wt_max", "max"),
            parras18_cpeb4_fc_hd_max=("cpeb4_fc_hd_max", "max"),
            parras18_polya_shortened_hd=("polya_shortened_hd", "any"),
            parras18_polya_fc_hd=("polya_fc_hd", "min"),
        )
    )
    univ = univ.merge(
        p_agg,
        left_on="gene_symbol_upper",
        right_on="human_sym_upper",
        how="left",
    ).drop(columns=["human_sym_upper"])
    univ["parras18_cpeb4_binder"] = univ["parras18_cpeb4_binder"].fillna(False)
    univ["parras18_cpeb1_binder"] = univ["parras18_cpeb1_binder"].fillna(False)
    univ["parras18_polya_shortened_hd"] = univ["parras18_polya_shortened_hd"].fillna(False)

    # 9. Module membership annotation
    module_map = {
        "CPEB4": "CPEB_family", "CPEB1": "CPEB_family", "CPEB2": "CPEB_family", "CPEB3": "CPEB_family",
        **{g: "Splicing_regulator" for g in ["SRRM4", "RBFOX1", "RBFOX2", "RBFOX3", "PTBP1", "PTBP2", "HNRNPC", "ELAVL2", "ELAVL3", "ELAVL4"]},
        **{g: "Kinase" for g in ["MAPK1", "MAPK3", "CAMK2A", "CAMK2B", "AURKA", "CDK1"]},
        **{g: "Synaptogenesis_marker" for g in ["SYP", "DLG4", "SNAP25", "SYN1", "GRIN2B", "GRIN2A", "SLC17A7", "GAD1", "NRXN1", "SHANK3"]},
        **{g: "Complement_microglial_pruning" for g in ["C4A", "C4B", "C1QA", "C1QB", "C1QC", "C3", "ITGAM", "ITGB2", "TREM2", "TYROBP", "CX3CR1", "P2RY12", "CD68", "CSF1R", "C3AR1", "PROS1", "MERTK"]},
    }
    univ["module_membership"] = univ["gene_symbol"].map(module_map).fillna("None")
    univ = univ.drop(columns=["gene_symbol_upper"])

    univ.to_csv(PROC_DIR / "harmonized_gene_universe.csv", index=False)
    return univ


def main() -> None:
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    print("=== Step 1: Downloading raw datasets ===")
    prov = download_all_raw()
    print(f"Total provenance entries: {len(prov['files'])}")

    print("\n=== Step 2: Verifying UniProt Q17RY0 & PMC XML ===")
    up_info = parse_uniprot_and_pmc()
    print("UniProt verified:", json.dumps(up_info, indent=2))

    print("\n=== Step 3: Parsing Garcia-Cabau et al. (2025) Source Data ===")
    gc = parse_garcia_cabau_2025()
    print(f"gc25_fig4_tc_and_agg rows: {len(gc['fig4'])}")
    print(f"gc25_edfig6_ph_and_agg rows: {len(gc['ed6'])}")
    print(f"gc25_proteostat_and_kinetics rows: {len(gc['kin'])}")

    print("\n=== Step 4: Parsing BrainSpan Atlas ===")
    bs_cols, bs_rows, _ = parse_brainspan()
    print(f"BrainSpan samples: {len(bs_cols)}, genes: {len(bs_rows)}")
    print(f"BrainSpan age_pcw range: {bs_cols['age_pcw'].min():.1f} to {bs_cols['age_pcw'].max():.1f} pcw")
    print(f"BrainSpan PFC samples: {int(bs_cols['is_pfc'].sum())}")

    print("\n=== Step 5: Parsing SynGO 1.3 & PsychENCODE / Gandal 2018 Continuous Sumstats ===")
    syngo_df, syn_map = load_syngo()
    der13, der14, der15 = parse_psychencode()
    gandal_cont = parse_gandal_continuous(bs_rows)
    print(f"SynGO genes: {len(syngo_df)}")
    print(f"PsychENCODE DER-13: {len(der13)}, DER-14: {len(der14)}, DER-15: {len(der15)}")
    print(f"Gandal 2018 continuous sumstats merged rows: {len(gandal_cont):,}, cols: {len(gandal_cont.columns)}")

    print("\n=== Step 6: Parsing Parras et al. (2018) & Mapping Orthologs ===")
    bs_syms = set(bs_rows["gene_symbol"].astype(str).str.upper())
    fu_syms = set(
        pd.read_excel(
            RAW_DIR / "risk_catalogs" / "41588_2022_1104_MOESM3_ESM.xlsx",
            sheet_name="Supplementary Table 11",
            usecols=["gene"],
        )["gene"]
        .dropna()
        .astype(str)
        .str.upper()
    )
    all_human_syms = bs_syms | fu_syms | set(syngo_df["hgnc_symbol"].astype(str).str.upper())
    parras_df = parse_parras_2018(bs_syms, all_human_syms, syn_map)
    n_mapped = (parras_df["human_symbol"] != "").sum()
    n_c4 = int(parras_df["cpeb4_binder"].sum())
    n_c4_mapped = int((parras_df["cpeb4_binder"] & (parras_df["human_symbol"] != "")).sum())
    n_1b = int(parras_df["polya_shortened_hd"].sum())
    n_1b_mapped = int((parras_df["polya_shortened_hd"] & (parras_df["human_symbol"] != "")).sum())
    print(f"Parras 2018 unique mouse genes: {len(parras_df)}, mapped: {n_mapped} ({n_mapped/len(parras_df):.1%})")
    print(f"  CPEB4 binders: {n_c4}, mapped: {n_c4_mapped} ({n_c4_mapped/n_c4:.1%})")
    print(f"  Poly(A) shortened HD: {n_1b}, mapped: {n_1b_mapped} ({n_1b_mapped/n_1b:.1%})")

    print("\n=== Step 7: Building Harmonized Gene Universe ===")
    univ = build_harmonized_universe(bs_rows, der13, der14, der15, gandal_cont, syngo_df, parras_df)
    p_univ = univ[univ["is_primary_symbol_row"]]
    print(f"Harmonized universe rows (Ensembl): {len(univ):,}, primary unique symbols: {len(p_univ):,}")
    print(f"  With gene_length_bp: {int(p_univ['gene_length_bp'].notna().sum()):,}")
    print(f"  CPEB4 binders (Parras 2018): {int(p_univ['parras18_cpeb4_binder'].sum()):,}")
    print(f"  Poly(A) shortened (Parras 2018): {int(p_univ['parras18_polya_shortened_hd'].sum()):,}")
    print(f"  SFARI genes: {int(p_univ['is_sfari'].sum()):,}")
    print(f"  Fu22 ASD185: {int((p_univ['fu22_ASD185'] == True).sum()):,}")
    print(f"  SCHEMA P_meta < 0.001: {int((p_univ['schema_P_meta'] < 0.001).sum()):,}")
    print(f"  OpenTargets SCZ gen_assoc > 0: {int((p_univ['ot_scz_genetic_association'] > 0).sum()):,}")
    print(f"  OpenTargets ASD gen_assoc > 0: {int((p_univ['ot_asd_genetic_association'] > 0).sum()):,}")
    print(f"  SynGO genes: {int(p_univ['is_syngo'].sum()):,}")


if __name__ == "__main__":
    main()
