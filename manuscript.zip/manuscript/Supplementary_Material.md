# Supplementary Material for: Developmental timing and polygenic background bifurcate CPEB4 microexon 4 mis-splicing between autism and schizophrenia

[Author 1]<sup>1,*</sup>, [Author 2]<sup>1</sup>

This file contains Supplementary Notes 1–3, Supplementary Equations (S1)–(S4), Supplementary Tables S1–S3, and Supplementary Figures S1–S3.

## Supplementary Note 1: Scale-1 Analytical Theorems, Quasi-Steady-State Proofs, and Biophysical Diagnostics

**Theorem 1 (Positive invariance of the probability simplex and translational bound).** Let *D* = {(*L*, *S*) ∈ ℝ<sup>2</sup> : *L* ≥ 0, *S* ≥ 0, *L* + *S* ≤ 1}. Along the three boundary facets of *D*, the Scale-1 kinetic vector field in Eqs. (4)–(5) points strictly inward or tangentially: (i) along *L* = 0, d*L*/d*t* = *k*<sub>form</sub>(1 − *S*) ≥ 0; (ii) along *S* = 0, d*S*/d*t* = *k*<sub>lock</sub>(*D*<sub>act</sub>)*Ã*<sub>eq</sub>*L* ≥ 0 (where *k*<sub>lock</sub>(*D*<sub>act</sub>) ≡ *k*<sub>lock</sub>[1 + *λ*<sub><i>D</i></sub>*D*<sub>act</sub>]); and (iii) along *L* + *S* = 1 (so free cytosolic protein *M* = 1 − *L* − *S* = 0), d(*L* + *S*)/d*t* = −*k*<sub>diss</sub>*R*<sub>rev</sub>*D*<sub>act</sub>*L* − *k*<sub>clr</sub>*S* ≤ 0 for all nonnegative rate constants and all *D*<sub>act</sub> ≥ 0, *χ*<sub>Δ4</sub> ∈ [0, 1]. By Nagumo's subtangentiality theorem, every trajectory initialized in *D* remains confined to *D* for all *t* ≥ 0, guaranteeing *M*(*t*) ≥ 0 and Φ(*t*) ∈ [1 − max(*η*<sub><i>L</i></sub>, *η*<sub><i>S</i></sub>), 1] ⊆ [0, 1]. Across all numerical stress tests in this study, maximum simplex violation was 0.0.

**Theorem 2 (Unique closed-form quasi-steady state and global exponential stability).** For any constant depolarization demand *D*<sub>act</sub> ≥ 0 and constant mis-splicing stoichiometry *χ*<sub>Δ4</sub> ∈ [0, 1] with fixed normalized cooperative propensity *Ã*<sub>eq</sub> = [1 + (*χ*<sub><i>c</i></sub>(pH)/*χ*<sub>Δ4</sub>)<sup><i>n</i></sup><sup><i>H</i></sup>]<sup>−1</sup>, the linear autonomous system Eqs. (4)–(5) possesses a unique equilibrium (*L*<sup>∗</sup>, *S*<sup>∗</sup>) in the interior of *D* and a unique equilibrium translational availability Φ<sup>∗</sup> given in closed form by:

$$
\begin{aligned} L^{*} &= \frac{1}{B+\beta C\tilde{A}_{\mathrm{eq}}},\quad S^{*}=\frac{C\tilde{A}_{\mathrm{eq}}}{B+\beta C\tilde{A}_{\mathrm{eq}}},\quad \Phi^{*}=1-\frac{\eta_L+\eta_S C\tilde{A}_{\mathrm{eq}}}{B+\beta C\tilde{A}_{\mathrm{eq}}},\\ B &= 1+\frac{k_{\mathrm{diss}}R_{\mathrm{rev}}D_{\mathrm{act}}}{k_{\mathrm{form}}},\quad C=\frac{k_{\mathrm{lock}}\left(1+\lambda_D D_{\mathrm{act}}\right)}{k_{\mathrm{clr}}},\quad \beta=1+\frac{k_{\mathrm{clr}}}{k_{\mathrm{form}}} \end{aligned} \tag{S1}
$$

Because all coefficients of the 2 × 2 constant-coefficient Jacobian matrix *J* satisfy tr(*J*) = −[*k*<sub>form</sub> + *k*<sub>diss</sub>*R*<sub>rev</sub>*D*<sub>act</sub> + *k*<sub>lock</sub>(*D*<sub>act</sub>)*Ã*<sub>eq</sub> + *k*<sub>clr</sub>] < 0 and det(*J*) = *k*<sub>form</sub>*k*<sub>clr</sub>(*B* + *βC* *Ã*<sub>eq</sub>) > 0 everywhere on parameter space, both eigenvalues have strictly negative real parts and (*L*<sup>∗</sup>, *S*<sup>∗</sup>) is globally exponentially stable within *D*. Furthermore, for fast kinetic equilibration (*k*<sub>form</sub> = 12 d<sup>−1</sup>) relative to multi-year developmental variation, singular perturbation convergence ensures tight adiabatic agreement between the full coupled ODE and QSS approximation (maximum synaptic density discrepancy Δ*N*<sub><i>s</i></sub> ≤ 0.0046; RK45 vs. Radau max state discrepancy 1.65e-10 in Scale 1 and 1.77e-10 across Scales 1–2).

**Theorem 3 (Activity-shifted critical locking threshold and depolarization-amplification condition).** Differentiating *S*<sup>∗</sup>(*D*<sub>act</sub>) in Eq. (S1) with respect to *D*<sub>act</sub> yields ∂*S*<sup>∗</sup>/∂*D*<sub>act</sub> > 0 and a strictly decreasing effective locking threshold ∂*χ*<sub><i>c</i></sub><sup>eff</sup>/∂*D*<sub>act</sub> < 0 whenever activity-driven alkalinization outpaces activity-mediated droplet dissolution, i.e., *λ*<sub><i>D</i></sub> > *k*<sub>diss</sub>*R*<sub>rev</sub>/*k*<sub>form</sub> = 0.1608. Under calibrated physiological values (*λ*<sub><i>D</i></sub> = 16.0 ≫ 0.1608), both the half-locking inflection *χ*<sub>1/2</sub><sup>lock</sup>(*D*<sub>act</sub>) (where *S*<sup>∗</sup> reaches 50% of its upper Möbius asymptote) and the effective functional collapse threshold *χ*<sub><i>c</i></sub><sup>eff</sup>(*D*<sub>act</sub>) (where Φ<sup>∗</sup> drops to Φ<sub>crit</sub> = 0.50) obey closed-form shifts:

$$
\begin{aligned} \chi_{1/2}^{\mathrm{lock}}(D_{\mathrm{act}}) &= \chi_c(\mathrm{pH})\left[\frac{B}{B+\beta C}\right]^{1/n_H},\quad \chi_c^{\mathrm{eff}}(D_{\mathrm{act}})=\chi_c(\mathrm{pH})\left[\frac{A_{\mathrm{crit}}}{1-A_{\mathrm{crit}}}\right]^{1/n_H},\\ A_{\mathrm{crit}}(D_{\mathrm{act}}) &= \frac{B\left(1-\Phi_{\mathrm{crit}}\right)-\eta_L}{C\left[\eta_S-\beta\left(1-\Phi_{\mathrm{crit}}\right)\right]} \end{aligned} \tag{S2}
$$

Raising cortical depolarization demand from childhood (*D*<sub>act</sub> = 0.15) to adolescent prefrontal levels (*D*<sub>act</sub> = 1.00) shifts *χ*<sub><i>c</i></sub><sup>eff</sup> downward by -0.0390 mole-fraction units (from 0.4060 to 0.3670). Diagnostics confirming residual normality (*r* = 0.986), narrow 5,000-bootstrap parameter localization for Cooperative Hill M4 (detailed metrics alongside targetome comparisons in Table S1), and invariant (*L*, *S*) simplex phase portraits appear in Figure S1.

*[Figure S1 near here]*

![Figure S1](../figures/Figure_S1.png)

**Figure S1. Scale-1 biophysical diagnostics, bootstrap posteriors, and (*****L*****,** ***S*****) simplex phase portraits.** **a**, Residuals versus fitted aggregation and normal Q–Q plot (*r* = 0.986) for Cooperative Hill model M4 (*n* = 140). **b**, Joint 5,000-bootstrap posterior density of (*χ*<sub><i>c</i></sub>, *n*<sub><i>H</i></sub>) showing tight localization of *χ*<sub><i>c</i></sub> = 0.4069 (95% CI 0.4003–0.4140) strictly between Control (0.30) and ASD (0.45). **c**, Positive simplex (*L* ≥ 0, *S* ≥ 0, *L* + *S* ≤ 1) ODE trajectories converging to analytical QSS fixed points at Childhood (*D*<sub>act</sub> = 0.15) versus Adolescent PFC (*D*<sub>act</sub> = 1.00) demand.

## Supplementary Note 2: Developmental Synaptogenesis and Pruning Functions, Extended Targetome Enrichments, and BrainSpan Sensitivity

In Scale 2 (Eq. 7), developmental synaptogenesis rate *α*<sub>syn</sub>(*t*) and activity-coupled adolescent pruning rate *β*<sub>prun</sub>(*t*) (in yr<sup>−1</sup> over developmental age *t* ∈ [−0.575, 30.0] yr) are parameterized smoothly around the empirical BrainSpan prefrontal depolarization-kinase trajectory *D*<sub>act</sub>(*t*) as:

$$
\begin{aligned} \alpha_{\mathrm{syn}}(t) &= \alpha_{\mathrm{base}}+a_{\mathrm{peri}}\,e^{-\frac{(t-t_{\mathrm{peri}})^2}{2s_{\mathrm{peri}}^2}}\,\sigma\!\left(\frac{t+0.34}{0.05}\right)+a_{\mathrm{inf}}\,e^{-\frac{(t-t_{\mathrm{inf}})^2}{2s_{\mathrm{inf}}^2}}\,\sigma\!\left(\frac{t-0.10}{0.25}\right),\\ \beta_{\mathrm{prun}}(t) &= b_{\mathrm{prun}}\,D_{\mathrm{act}}(t)\,\sigma\!\left(\frac{t-t_{\mathrm{prun,on}}}{1.0}\right)e^{-\frac{(t-t_{\mathrm{prun,pk}})^2}{2s_{\mathrm{prun}}^2}} \end{aligned} \tag{S3}
$$

with baseline adult synaptogenic replenishment *α*<sub>base</sub> = 0.2620 yr<sup>−1</sup> enforcing asymptotic healthy control normalization *N*<sub><i>s</i></sub><sup>ctrl</sup>(30) ≈ 1.00, perinatal burst (*a*<sub>peri</sub> = 2.722 yr<sup>−1</sup>, *t*<sub>peri</sub> = -0.181 yr, *s*<sub>peri</sub> = 0.137 yr), early-childhood extension (*a*<sub>inf</sub> = 0.477 yr<sup>−1</sup>, *t*<sub>inf</sub> = 1.279 yr, *s*<sub>inf</sub> = 0.796 yr), and adolescent pruning kernel (*b*<sub>prun</sub> = 0.081 yr<sup>−1</sup>, *t*<sub>prun,on</sub> = 3.910 yr, *t*<sub>prun,pk</sub> = 13.229 yr, *s*<sub>prun</sub> = 4.332 yr) fitted strictly to healthy control (*χ*<sub>Δ4</sub> = 0.30, *P*<sub>ASD</sub> = *P*<sub>SCZ</sub> = 0) prefrontal histological landmarks without utilizing any psychiatric case data. Complete Scale-1 model selection metrics (M1–M4 across pooled and individual fluorophore channels) together with covariate-adjusted logistic regressions and 10,000-permutation tests across supplementary ASD, SCZ, poly(A)-shortened, and PsychENCODE gene sets are compiled in Table S1.

*[Table S1 near here]*

**Table S1.** Biophysical model selection on Garcia-Cabau et al. (2025) Fig. 4d and extended CPEB4 targetome enrichment results.

| Analysis / Dataset | Model or Gene Set | *n* (or Overlap) | Primary Metric (95% CI) | Fit / Adj. *P* | Notes |
| --- | --- | --- | --- | --- | --- |
| Biophysical Pooled (*n*=140) | M1 Linear | 140 | *R*<sup>2</sup> = 0.6959, RMSE = 4.97% | ΔAIC = +105.35 | LOO-CV = 5.05% |
| Biophysical Pooled (*n*=140) | M2 Exponential saturating | 140 | *R*<sup>2</sup> = 0.7001, RMSE = 4.94% | ΔAIC = +105.40 | LOO-CV = 5.01% |
| Biophysical Pooled (*n*=140) | M3 Michaelis–Menten (*n*<sub><i>H</i></sub>=1) | 140 | *R*<sup>2</sup> = 0.6966, RMSE = 4.97% | ΔAIC = +107.04 | LOO-CV = 5.01% |
| Biophysical Pooled (*n*=140) | M4 Cooperative Hill (Eq. 2) | 140 | *χ*<sub><i>c</i></sub> = 0.4069 (0.4003–0.4140) | AIC = 349.76 (*w*=1.00) | *F*<sub>1,136</sub> = 160.33, *P* = 9.22×10<sup>−25</sup> |
| Biophysical `DL488` (*n*=70) | M4 Cooperative Hill (Eq. 2) | 70 | *χ*<sub><i>c</i></sub> = 0.4032, *n*<sub><i>H</i></sub> = 25.61 | *R*<sup>2</sup> = 0.8902 | ΔAIC ≥ 66.12 vs. M1–M3 |
| Biophysical `AF647` (*n*=70) | M4 Cooperative Hill (Eq. 2) | 70 | *χ*<sub><i>c</i></sub> = 0.4098, *n*<sub><i>H</i></sub> = 18.34 | *R*<sup>2</sup> = 0.8372 | ΔAIC ≥ 46.27 vs. M1–M3 |
| Targetome: *Fu22 ASD72* | CPEB4 RIP-seq binder | 35/71 | Adj. OR = 2.66 (1.63–4.34) | 8.95 × 10<sup>-5</sup> | Perm. *P* = 0.00050 |
| Targetome: *Fu22 DD477* | CPEB4 RIP-seq binder | 188/473 | Adj. OR = 2.01 (1.65–2.45) | 5.66 × 10<sup>-12</sup> | Perm. *P* = 1.00 × 10<sup>-4</sup> |
| Targetome: SCHEMA *P*<0.001 | CPEB4 RIP-seq binder | 15/61 | Adj. OR = 1.17 (0.63–2.15) | 0.619 | Null after length/expr adjustment |
| Targetome: Shared SFARI1+2∩SCHEMA05 | CPEB4 RIP-seq binder | 38/98 | Adj. OR = 1.77 (1.16–2.72) | 0.0086 | Perm. *P* = 0.012 |
| Poly(A)-shortened: *Fu22 ASD185* | Parras et al. deadenylated mRNA | 21/184 | Adj. OR = 2.19 (1.36–3.53) | 0.0013 | Logistic model (perm. N/A)\* |
| Poly(A)-shortened: SCHEMA *P*<0.01 | Parras et al. deadenylated mRNA | 18/232 | Adj. OR = 1.89 (1.15–3.11) | 0.013 | Logistic model (perm. N/A)\* |
| PsychENCODE `BD.DS_leaf` | CPEB4 RIP-seq binder | 27/72 | Adj. OR = 2.12 (1.28–3.52) | 0.0035 | Perm. *P* = 0.0084 |

\*N/A: covariate-adjusted logistic regression reported; 10,000-iteration expression × length permutations were executed on primary CPEB4 RIP-seq binder sets.

Systematic sensitivity testing across 12 risk-set and window definitions, all 4 prefrontal subregions (`DFC`, `MFC`, `OFC`, `VFC`), 10,000 expression-decile-matched permutations, and PFC vs. non-PFC developmental regulator slopes (Figure S2) confirmed that broad heterogeneous gene definitions (`SFARI 1+2` vs. combined SCZ) exhibit null temporal separation, whereas high-penetrance *de novo* ASD targets (*Fu22 ASD185*, `T_ASD_only` *n* = 60) versus SCZ targets (`SCHEMA P < 0.05`, `T_SCZ_only` *n* = 171) diverge robustly across every metric and cortical subregion.

*[Figure S2 near here]*

![Figure S2](../figures/Figure_S2.png)

**Figure S2. Sensitivity of BrainSpan developmental temporal segregation across risk definitions, developmental windows, prefrontal subregions, and** ***B*** **= 10,000 matched permutations.** **a**, Timing shift differences (Δ<sub>SCZ−ASD</sub>, 95% bootstrap CI) contrasting broad `SFARI 1+2` definitions (`DefA/B/D/G`, null) against *de novo* exome `Fu22 ASD185` vs. `SCHEMA` (`DefC`, *P*<sub>perm</sub> = 0.0013–0.0121). **b**, Empirical expression-decile-matched permutation null histograms (*B* = 10,000) for `DefC` Δ*Z*<sub>all</sub>, Δ*Z*<sub>PFC</sub>, and *τ*<sub>PFC</sub><sup>∗</sup>. **c**, Consistent prenatal ASD vs. later SCZ segregation across all four individual PFC subregions (`DFC`, `MFC`, `OFC`, `VFC`). **d**, Sample-level BrainSpan developmental regressions comparing PFC (blue) versus non-PFC (gray) slopes for *CPEB4*, *SRRM4*, and *CAMK2A* (PFC × age interaction *P* = 0.0001).

## Supplementary Note 3: Birth-Cohort Splicing Decomposition, Global Sensitivity Analysis, and Conditional Murine Power

To evaluate population epidemiology without tuning disease comorbidity, onset separation, or cortical ΔPSI gradients, *N* = 100,000 synthetic births (`seed = 20261119`) drew correlated polygenic liabilities (*P*<sub>ASD</sub>, *P*<sub>SCZ</sub>) with empirical *r*<sub><i>G</i></sub> = 0.211, environmental residuals (*σ*<sub>ε,ASD</sub> = 0.85, *σ*<sub>ε,SCZ</sub> = 0.90), and individual developmental splicing trajectories decomposing smooth constitutional variance from early (*W*<sub>1</sub>) and adolescent (*W*<sub>2</sub>) splicing perturbations:

$$
\begin{aligned} \chi_{\Delta4,i}(t) &= \operatorname{clip}\!\left(\chi_{\mathrm{ctrl}}+\delta_{\mathrm{const},i}+\delta_{W_1,i}\,\sigma\!\left(\frac{6.5-t}{1.0}\right)+\delta_{W_2,i}\,\sigma\!\left(\frac{t-10.0}{1.5}\right),\,0.05,\,0.95\right),\\ \delta_{\mathrm{const},i} &\sim\mathcal{N}(0,\sigma_\chi^2),\quad \delta_{W_1,i}=I_{W_1,i}U_{W_1,i},\quad \delta_{W_2,i}=I_{W_2,i}U_{W_2,i} \end{aligned} \tag{S4}
$$

where *σ*<sub><i>χ</i></sub> = 0.022 governs continuous baseline splicing variation around *χ*<sub>ctrl</sub> = 0.30, early perturbation indicator *I*<sub><i>W</i></sub><sub>1,</sub><sub><i>i</i></sub> ~ Bernoulli(0.025) modulates *U*<sub><i>W</i></sub><sub>1,</sub><sub><i>i</i></sub> ~ Uniform(0.090, 0.170), and adolescent perturbation indicator *I*<sub><i>W</i></sub><sub>2,</sub><sub><i>i</i></sub> ~ Bernoulli(0.048) modulates *U*<sub><i>W</i></sub><sub>2,</sub><sub><i>i</i></sub> ~ Uniform(0.040, 0.085), with diagnostic thresholds *θ*<sub>ASD</sub> and *θ*<sub>SCZ</sub> solved solely by exact quantile matching to baseline 1.80% ASD and 0.85% SCZ cumulative prevalences. Vectorized Saltelli Sobol variance indices (*N*<sub>base</sub> = 2,048), 5,000-draw LHS-PRCC monotonic correlations across ±30% bounds, and out-of-calibration comorbidity robustness across *r*<sub><i>G</i></sub> ∈ [0.10, 0.35] are reported in Table S2 and visualized in Figure S3. Finally, Table S3 provides complete Cohen's *d* effect sizes and two-sided *t*-test sample sizes (*α* = 0.05, 80% power) across all 18 conditional *Cpeb4*Δ4 induction × genetic background murine arms.

*[Table S2 near here]*

**Table S2.** Global variance-based Sobol indices (*N*<sub>base</sub> = 2,048), LHS-PRCC rankings (*N* = 5,000), and birth-cohort *r*<sub><i>G</i></sub> robustness sweep.

| Sensitivity / Validation Metric | Parameter or Condition | First-Order / Estimate | Total-Order *S*<sub><i>Ti</i></sub> or 95% CI | *P* Value |
| --- | --- | --- | --- | --- |
| Sobol on Ψ | P_SCZ | *S*<sub><i>i</i></sub> = 0.3934 | *S*<sub><i>Ti</i></sub> = 0.5564 (0.5177–0.5937) | — |
| Sobol on Ψ | P_ASD | *S*<sub><i>i</i></sub> = 0.3234 | *S*<sub><i>Ti</i></sub> = 0.4330 (0.4046–0.4643) | — |
| Sobol on Ψ | tau_on_yr | *S*<sub><i>i</i></sub> = 0.0548 | *S*<sub><i>Ti</i></sub> = 0.1312 (0.1145–0.1488) | — |
| Sobol on Ψ | delta_chi | *S*<sub><i>i</i></sub> = 0.0199 | *S*<sub><i>Ti</i></sub> = 0.1284 (0.1118–0.1473) | — |
| Sobol on Ψ | gamma_SCZ | *S*<sub><i>i</i></sub> = 0.0036 | *S*<sub><i>Ti</i></sub> = 0.0194 (0.0134–0.0260) | — |
| Sobol on Ψ | kappa_1 | *S*<sub><i>i</i></sub> = -0.0013 | *S*<sub><i>Ti</i></sub> = 0.0113 (0.0072–0.0161) | — |
| Sobol on *χ*<sub><i>c</i></sub><sub>,eff</sub>(*W*<sub>2</sub>) | chi_c_ref_pH8 | *S*<sub><i>i</i></sub> = 0.8223 | *S*<sub><i>Ti</i></sub> = 0.8227 (0.7849–0.8660) | — |
| Sobol on *χ*<sub><i>c</i></sub><sub>,eff</sub>(*W*<sub>2</sub>) | n_H | *S*<sub><i>i</i></sub> = 0.0659 | *S*<sub><i>Ti</i></sub> = 0.0681 (0.0638–0.0727) | — |
| Sobol on *χ*<sub><i>c</i></sub><sub>,eff</sub>(*W*<sub>2</sub>) | k_clr | *S*<sub><i>i</i></sub> = 0.0305 | *S*<sub><i>Ti</i></sub> = 0.0308 (0.0288–0.0327) | — |
| Sobol on *χ*<sub><i>c</i></sub><sub>,eff</sub>(*W*<sub>2</sub>) | k_lock | *S*<sub><i>i</i></sub> = 0.0284 | *S*<sub><i>Ti</i></sub> = 0.0304 (0.0284–0.0325) | — |
| LHS-PRCC on Ψ (*N*=5,000) | P_ASD | PRCC = -0.7246 | \|PRCC\| = 0.7246 | 1.00 × 10<sup>-300</sup> |
| LHS-PRCC on Ψ (*N*=5,000) | P_SCZ | PRCC = +0.6425 | \|PRCC\| = 0.6425 | 1.00 × 10<sup>-300</sup> |
| LHS-PRCC on Ψ (*N*=5,000) | delta_chi | PRCC = +0.1022 | \|PRCC\| = 0.1022 | 4.77 × 10<sup>-13</sup> |
| LHS-PRCC on Ψ (*N*=5,000) | tau_on_yr | PRCC = +0.0711 | \|PRCC\| = 0.0711 | 5.08 × 10<sup>-7</sup> |
| Cohort *r*<sub><i>G</i></sub> sweep (*N*=100,000) | *r*<sub><i>G</i></sub> = 0.100 | OR = 3.28 | 95% CI 2.44–4.42 | 1.92 × 10<sup>-11</sup> |
| Cohort *r*<sub><i>G</i></sub> sweep (*N*=100,000) | *r*<sub><i>G</i></sub> = 0.150 | OR = 3.49 | 95% CI 2.61–4.66 | 5.55 × 10<sup>-13</sup> |
| Cohort *r*<sub><i>G</i></sub> sweep (*N*=100,000) | *r*<sub><i>G</i></sub> = 0.211 | OR = 3.78 | 95% CI 2.86–5.01 | 3.41 × 10<sup>-15</sup> |
| Cohort *r*<sub><i>G</i></sub> sweep (*N*=100,000) | *r*<sub><i>G</i></sub> = 0.280 | OR = 4.07 | 95% CI 3.11–5.32 | 9.59 × 10<sup>-18</sup> |
| Cohort *r*<sub><i>G</i></sub> sweep (*N*=100,000) | *r*<sub><i>G</i></sub> = 0.350 | OR = 4.40 | 95% CI 3.39–5.70 | 1.16 × 10<sup>-20</sup> |

*[Figure S3 near here]*

![Figure S3](../figures/Figure_S3.png)

**Figure S3. Extended LHS-PRCC sensitivity, genetic-correlation sweep, and birth-cohort regime distributions.** **a**, Complete 15-parameter LHS-PRCC (*N* = 5,000) rankings across *χ*<sub><i>c</i></sub><sub>,eff</sub>(*W*<sub>2</sub>), Ψ, and adult *N*<sub><i>s</i></sub>(30). **b**, Emergent ASD–SCZ comorbidity OR and 95% CIs across *r*<sub><i>G</i></sub> ∈ [0.10, 0.35] within the Zheng et al. (2018) meta-analytic CI band (2.08–6.05). **c**, Diagnostic regime prevalences (left) and cortical ΔPSI<sub>me4</sub> distributions during childhood *W*<sub>1</sub> and adolescent *W*<sub>2</sub> relative to the Parras et al. (2018) <35 yr ASD benchmark (−8.8%, dashed).

*[Table S3 near here]*

**Table S3.** Complete 18-arm *in silico* conditional *Cpeb4*Δ4 induction predictions and experimental power analysis.

| Stage (Human Age) | Background | Δ*χ* (*χ*<sub>ind</sub>) | Regime (Ψ) | Cohen's *d*<sub>ASD</sub> (*n*<sub>80%</sub>) | Cohen's *d*<sub>SCZ</sub> (*n*<sub>80%</sub>) | Cohen's *d*<sub><i>N</i></sub><sub>s</sub> (*n*<sub>80%</sub>) |
| --- | --- | --- | --- | --- | --- | --- |
| E14.5 (-0.44 yr) | WT | +0.08 (0.38) | Resilient (-0.140) | 2.36 (5) | 1.91 (6) | -2.56 (4) |
| E14.5 (-0.44 yr) | WT | +0.16 (0.46) | ASD-only (-0.195) | 4.61 (3) | 3.05 (4) | -4.36 (3) |
| E14.5 (-0.44 yr) | ASD-PRS | +0.08 (0.38) | ASD-only (-0.471) | 3.49 (3) | 2.18 (5) | -3.85 (3) |
| E14.5 (-0.44 yr) | ASD-PRS | +0.16 (0.46) | ASD-only (-0.462) | 8.59 (2) | 3.60 (3) | -8.12 (2) |
| E14.5 (-0.44 yr) | SCZ-PRS | +0.08 (0.38) | SCZ-only (+0.318) | 2.36 (5) | 2.76 (4) | -2.58 (4) |
| E14.5 (-0.44 yr) | SCZ-PRS | +0.16 (0.46) | Comorbid (+0.182) | 4.71 (3) | 4.75 (3) | -4.47 (3) |
| P10 (+0.15 yr) | WT | +0.08 (0.38) | Resilient (-0.037) | 2.03 (5) | 1.95 (6) | -2.57 (4) |
| P10 (+0.15 yr) | WT | +0.16 (0.46) | Resilient (-0.093) | 3.75 (3) | 3.07 (3) | -4.35 (3) |
| P10 (+0.15 yr) | ASD-PRS | +0.08 (0.38) | ASD-only (-0.417) | 3.21 (3) | 2.26 (5) | -3.83 (3) |
| P10 (+0.15 yr) | ASD-PRS | +0.16 (0.46) | ASD-only (-0.397) | 7.02 (2) | 3.67 (3) | -8.17 (2) |
| P10 (+0.15 yr) | SCZ-PRS | +0.08 (0.38) | SCZ-only (+0.397) | 2.05 (5) | 2.71 (4) | -2.58 (4) |
| P10 (+0.15 yr) | SCZ-PRS | +0.16 (0.46) | SCZ-only (+0.272) | 3.83 (3) | 4.76 (3) | -4.40 (3) |
| P42 (+14.00 yr) | WT | +0.08 (0.38) | Resilient (+0.637) | 0.02 (>10<sup>4</sup>) | 1.75 (7) | -2.45 (4) |
| P42 (+14.00 yr) | WT | +0.16 (0.46) | Resilient (+0.774) | 0.01 (>10<sup>4</sup>) | 2.80 (4) | -4.39 (3) |
| P42 (+14.00 yr) | ASD-PRS | +0.08 (0.38) | Resilient (+0.078) | 0.02 (>10<sup>4</sup>) | 2.00 (6) | -3.89 (3) |
| P42 (+14.00 yr) | ASD-PRS | +0.16 (0.46) | Resilient (+0.293) | 0.00 (>10<sup>4</sup>) | 3.15 (3) | -8.07 (2) |
| P42 (+14.00 yr) | SCZ-PRS | +0.08 (0.38) | SCZ-only (+0.855) | -0.01 (>10<sup>4</sup>) | 2.54 (4) | -2.59 (4) |
| P42 (+14.00 yr) | SCZ-PRS | +0.16 (0.46) | SCZ-only (+0.884) | 0.03 (>10<sup>4</sup>) | 4.35 (3) | -4.39 (3) |

