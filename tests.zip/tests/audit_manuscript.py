#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tests/audit_manuscript.py
=========================
Comprehensive automated audit of all generated DOCX and Markdown deliverables
against `for-paper` specification, OOXML structural rules, strict ascending
equation/table/figure/citation ordering, AI-disclosure isolation, and exact
numerical reconciliation with `results/master_metrics.json`.
"""

from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path
from lxml import etree

WORKSPACE = Path(__file__).resolve().parent.parent
MS_DIR = WORKSPACE / "manuscript"
RESULTS_DIR = WORKSPACE / "results"

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"


def _check_docx(path: Path, expected_omath: int, expected_media: int) -> list[str]:
    errs: list[str] = []
    if not path.exists():
        return [f"Missing DOCX file: {path}"]
    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()
        media = [n for n in names if n.startswith("word/media/")]
        if len(media) != expected_media:
            errs.append(f"{path.name}: expected {expected_media} media files, found {len(media)}")

        root = etree.fromstring(zf.read("word/document.xml"))
        omaths = root.findall(f".//{{{M_NS}}}oMath")
        if len(omaths) != expected_omath:
            errs.append(f"{path.name}: expected {expected_omath} <m:oMath>, found {len(omaths)}")

        # Page geometry A4 (11906 x 16838 twips) & 2.54 cm margins (1440 twips)
        pg_sz = root.find(f".//{{{W_NS}}}pgSz")
        pg_mar = root.find(f".//{{{W_NS}}}pgMar")
        if pg_sz is None or abs(int(pg_sz.get(f"{{{W_NS}}}w", 0)) - 11906) > 30 or abs(int(pg_sz.get(f"{{{W_NS}}}h", 0)) - 16838) > 30:
            errs.append(f"{path.name}: page size is not A4")
        if pg_mar is None:
            errs.append(f"{path.name}: missing pgMar")
        else:
            for side in ("top", "bottom", "left", "right"):
                val = int(pg_mar.get(f"{{{W_NS}}}{side}", 0))
                if abs(val - 1440) > 30:
                    errs.append(f"{path.name}: margin {side}={val} != 1440 twips")

        # Line numbers continuous
        ln = root.find(f".//{{{W_NS}}}lnNumType")
        if ln is None or ln.get(f"{{{W_NS}}}restart") != "continuous":
            errs.append(f"{path.name}: missing continuous <w:lnNumType>")

        # Header PAGE field
        hdrs = [n for n in names if n.startswith("word/header")]
        has_page = False
        for h in hdrs:
            if b"PAGE" in zf.read(h):
                has_page = True
                break
        if not has_page:
            errs.append(f"{path.name}: missing PAGE field in header")

        # Check non-black colored body runs or leftover [[@
        all_txt = "".join(root.itertext())
        if "[[@" in all_txt:
            errs.append(f"{path.name}: leftover [[@ citation tag found")
        for col in root.findall(f".//{{{W_NS}}}rPr/{{{W_NS}}}color"):
            val = col.get(f"{{{W_NS}}}val", "").upper()
            if val not in ("000000", "AUTO", ""):
                errs.append(f"{path.name}: non-black font color #{val} found")
                break
    return errs


def _expand_citation_token(tok: str) -> list[int]:
    nums: list[int] = []
    for part in tok.split(","):
        part = part.strip()
        if not part:
            continue
        if "–" in part or "-" in part:
            a, b = re.split(r"[–-]", part, maxsplit=1)
            nums.extend(range(int(a), int(b) + 1))
        else:
            nums.append(int(part))
    return nums


def _check_strict_ascending(seq: list[int], label: str, expected_list: list[int] | None = None) -> list[str]:
    errs: list[str] = []
    seen: list[int] = []
    for x in seq:
        if x not in seen:
            seen.append(x)
    if expected_list is not None and seen != expected_list:
        errs.append(f"{label}: expected first-appearance order {expected_list}, got {seen}")
    elif seen != sorted(seen):
        errs.append(f"{label}: first-appearance order not ascending: {seen}")
    return errs


def main() -> int:
    errs: list[str] = []

    # 1. DOCX checks
    errs.extend(_check_docx(MS_DIR / "Manuscript_Complete_with_Figures.docx", expected_omath=16, expected_media=6))
    errs.extend(_check_docx(MS_DIR / "Manuscript_Text_Only.docx", expected_omath=16, expected_media=0))
    errs.extend(_check_docx(MS_DIR / "Supplementary_Material.docx", expected_omath=4, expected_media=3))
    for fn in ("Title_Page.docx", "Cover_Letter.docx", "FILE_LIST_GitHub_Zenodo.txt"):
        if not (MS_DIR / fn).exists():
            errs.append(f"Missing manuscript deliverable: {fn}")

    # 2. Markdown structure & ordering checks
    md_path = MS_DIR / "Manuscript.md"
    supp_md_path = MS_DIR / "Supplementary_Material.md"
    if not md_path.exists() or not supp_md_path.exists():
        errs.append("Missing Manuscript.md or Supplementary_Material.md")
    else:
        md = md_path.read_text(encoding="utf-8")
        supp_md = supp_md_path.read_text(encoding="utf-8")

        if "[[@" in md or "[[@" in supp_md:
            errs.append("Leftover [[@ marker in Markdown")

        # Exact H2 section headings order
        h2s = re.findall(r"^## (.+)$", md, flags=re.MULTILINE)
        expected_h2s = [
            "Abstract",
            "Introduction",
            "Methods",
            "Results",
            "Discussion",
            "Conclusions",
            "CRediT authorship contribution statement",
            "Ethics Statement",
            "Funding",
            "Declaration of Competing Interest",
            "Data Availability Statement",
            "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process",
            "References",
        ]
        if h2s != expected_h2s:
            errs.append(f"Section order mismatch: got {h2s}, expected {expected_h2s}")

        # Results declarative headings count
        res_block = md.split("## Results\n", 1)[1].split("## Discussion\n", 1)[0]
        res_h3 = re.findall(r"^### (.+)$", res_block, flags=re.MULTILINE)
        if not (6 <= len(res_h3) <= 8):
            errs.append(f"Expected 6-8 Results subheadings, got {len(res_h3)}")

        # Equations \tag{1..16} and \tag{S1..S4}
        eq_tags = [int(x) for x in re.findall(r"\\tag\{(\d+)\}", md)]
        if eq_tags != list(range(1, 17)):
            errs.append(f"Main LaTeX equation tags mismatch: {eq_tags}")
        seq_tags = re.findall(r"\\tag\{(S\d+)\}", supp_md)
        if seq_tags != ["S1", "S2", "S3", "S4"]:
            errs.append(f"Supp LaTeX equation tags mismatch: {seq_tags}")

        # Main Tables 1..4 and Figures 1..6 first-appearance order in body (before References)
        body_before_refs = md.split("## References\n", 1)[0]
        tbl_mentions = [int(x) for x in re.findall(r"\bTable (\d+)\b", body_before_refs)]
        fig_mentions = [int(x) for x in re.findall(r"\bFigure (\d+)", body_before_refs)]
        errs.extend(_check_strict_ascending(tbl_mentions, "Main Table mentions", [1, 2, 3, 4]))
        errs.extend(_check_strict_ascending(fig_mentions, "Main Figure mentions", [1, 2, 3, 4, 5, 6]))

        # Supplementary Tables S1..S3 and Figures S1..S3 in both Main and Supp
        stbl_main = [int(x) for x in re.findall(r"\bTable S(\d+)\b", body_before_refs)]
        sfig_main = [int(x) for x in re.findall(r"\bFigure S(\d+)", body_before_refs)]
        errs.extend(_check_strict_ascending(stbl_main, "Supp Table mentions in Main", [1, 2, 3]))
        errs.extend(_check_strict_ascending(sfig_main, "Supp Figure mentions in Main", [1, 2, 3]))

        stbl_supp = [int(x) for x in re.findall(r"\bTable S(\d+)\b", supp_md)]
        sfig_supp = [int(x) for x in re.findall(r"\bFigure S(\d+)", supp_md)]
        errs.extend(_check_strict_ascending(stbl_supp, "Supp Table mentions in Supp", [1, 2, 3]))
        errs.extend(_check_strict_ascending(sfig_supp, "Supp Figure mentions in Supp", [1, 2, 3]))

        # Citation superscript order in Main body
        cite_tokens = re.findall(r"<sup>(\d[\d,–-]*)</sup>", body_before_refs)
        seen_cites: list[int] = []
        for tok in cite_tokens:
            for num in _expand_citation_token(tok):
                if num not in seen_cites:
                    seen_cites.append(num)
        refs_block = md.split("## References\n", 1)[1]
        ref_nums = [int(x) for x in re.findall(r"^(\d+)\. ", refs_block, flags=re.MULTILINE)]
        if seen_cites != list(range(1, len(ref_nums) + 1)):
            errs.append(f"Citations not sequential 1..{len(ref_nums)}: {seen_cites}")
        if ref_nums != list(range(1, len(ref_nums) + 1)):
            errs.append(f"Reference numbering mismatch: {ref_nums}")

        # Verify zero AI/agent/orchestrator mentions outside Generative AI section
        no_ai_md = md.split("## Declaration of Generative AI", 1)[0] + "\n## References\n" + refs_block
        forbidden = [
            r"\bgenerative AI\b",
            r"\bAI-assisted\b",
            r"\bOrchestrator\b",
            r"\bBioDataEngineer\b",
            r"\bMathBiophysicist\b",
            r"\bBioinformaticsValidator\b",
            r"\bBiblioScienceVerifier\b",
            r"\bFigureAndDocBuilder\b",
            r"\bRigorousPeerReviewer\b",
            r"\bChatGPT\b",
            r"\bClaude\b",
            r"\bGemini\b",
        ]
        for pat in forbidden:
            if re.search(pat, no_ai_md, flags=re.IGNORECASE) or re.search(pat, supp_md, flags=re.IGNORECASE):
                errs.append(f"Forbidden AI/agent term matched `{pat}` outside AI declaration")

        # Abstract has zero numeric citation <sup> (exclude R^2 and 10^-k exponents)
        abs_block = md.split("## Abstract\n", 1)[1].split("**Keywords:**", 1)[0]
        if re.search(r"(?<!\*R\*)(?<!10)<sup>\d[\d,–-]*</sup>", abs_block):
            errs.append("Abstract must contain zero citations")

        # Numeric reconciliation against master_metrics.json
        mm = json.loads((RESULTS_DIR / "master_metrics.json").read_text(encoding="utf-8"))
        coh = mm["step3b_scale2_3_multiscale_ctl"]["birth_cohort_validation_N100k"]["base_rG_0.211"]
        expected_strs = [
            "0.4069",
            "19.86",
            "18,892",
            "524",
            f"{coh['comorbid_or']:.2f}",
            f"{coh['onset_asd_median']:.2f}",
            f"{coh['onset_scz_median']:.2f}",
        ]
        for s in expected_strs:
            if s not in md:
                errs.append(f"Missing reconciled master metric string `{s}` in Manuscript.md")

    # 3. Root reproducibility files
    for rf in ("README.md", "LICENSE", "CITATION.cff", "environment.yml", "requirements.txt", "run_all.py"):
        if not (WORKSPACE / rf).exists():
            errs.append(f"Missing root repository file: {rf}")

    if errs:
        print("MANUSCRIPT AUDIT FAILED:")
        for e in errs:
            print("  -", e)
        return 1

    print("MANUSCRIPT AUDIT PASSED: 0 errors across DOCX geometry/OMML, Markdown structure, strict ascending order, citations, AI isolation, and master_metrics reconciliation.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
