"""Verification tests for Step 1 acquired & harmonized datasets."""

import json
from pathlib import Path
import numpy as np
import pandas as pd

WORKSPACE = Path(__file__).resolve().parent.parent
RAW_DIR = WORKSPACE / "data" / "raw"
PROC_DIR = WORKSPACE / "data" / "processed"


def run_checks() -> None:
    # 1. Provenance
    prov_path = RAW_DIR / "provenance.json"
    assert prov_path.exists(), "Missing data/raw/provenance.json"
    prov = json.loads(prov_path.read_text(encoding="utf-8"))
    assert len(prov["files"]) >= 28, f"Expected >=28 provenance entries, got {len(prov['files'])}"
    for key, entry in prov["files"].items():
        p = WORKSPACE / entry["local_path"]
        assert p.exists() and p.stat().st_size > 0, f"Missing/empty raw file for {key}: {p}"
        assert len(entry["sha256"]) == 64, f"Invalid sha256 for {key}"

    # 2. Required processed files
    required_files = [
        "cpeb4_sequence_and_literature_verified.json",
        "gc25_fig4_tc_and_agg.csv",
        "gc25_edfig6_ph_and_agg.csv",
        "gc25_proteostat_and_kinetics.csv",
        "cpeb4_targets_parras2018.csv",
        "brainspan_metadata.csv",
        "brainspan_gene_info.csv",
        "brainspan_log2rpkm.npz",
        "brainspan_module_trajectories.csv",
        "psychencode_der13.csv",
        "psychencode_der14_cpeb4_and_summary.csv",
        "psychencode_der15.csv",
        "gandal2018_continuous_sumstats.csv",
        "harmonized_gene_universe.csv",
    ]
    for fn in required_files:
        p = PROC_DIR / fn
        assert p.exists() and p.stat().st_size > 0, f"Missing or empty processed file: {p}"

    # 3. Key integrity checks
    seq_info = json.loads((PROC_DIR / "cpeb4_sequence_and_literature_verified.json").read_text(encoding="utf-8"))
    assert seq_info["canonical_length_aa"] == 729
    assert seq_info["microexon4_aa_sequence"] == "ARTYGRRR"

    gc4 = pd.read_csv(PROC_DIR / "gc25_fig4_tc_and_agg.csv")
    assert gc4["chi_delta4"].isna().sum() == 0
    assert gc4["value"].isna().sum() == 0

    gced6 = pd.read_csv(PROC_DIR / "gc25_edfig6_ph_and_agg.csv")
    assert gced6["pH"].isna().sum() == 0

    gckin = pd.read_csv(PROC_DIR / "gc25_proteostat_and_kinetics.csv")
    assert gckin["y_val"].isna().sum() == 0

    parras = pd.read_csv(PROC_DIR / "cpeb4_targets_parras2018.csv", keep_default_na=False)
    assert (parras["mouse_symbol"] == "").sum() == 0

    bs_meta = pd.read_csv(PROC_DIR / "brainspan_metadata.csv")
    assert len(bs_meta) == 524
    assert bs_meta["age_pcw"].isna().sum() == 0
    assert bs_meta["log2_pcw"].isna().sum() == 0

    bs_gene = pd.read_csv(PROC_DIR / "brainspan_gene_info.csv")
    assert len(bs_gene) == 52376
    assert bs_gene["ensembl_gene_id"].isna().sum() == 0
    assert bs_gene["gene_symbol"].isna().sum() == 0

    npz = np.load(PROC_DIR / "brainspan_log2rpkm.npz", allow_pickle=False)
    assert npz["log2_rpkm"].shape == (52376, 524)
    assert not np.isnan(npz["log2_rpkm"]).any()

    gandal = pd.read_csv(PROC_DIR / "gandal2018_continuous_sumstats.csv", low_memory=False)
    assert len(gandal) > 20000
    assert gandal["ensembl_gene_id"].isna().sum() == 0
    assert "asd_all_logFC" in gandal.columns and "scz_cmc_logFC" in gandal.columns and "scz_gvex_logFC" in gandal.columns

    univ = pd.read_csv(PROC_DIR / "harmonized_gene_universe.csv", low_memory=False)
    assert len(univ) == 52376
    assert univ["ensembl_gene_id"].isna().sum() == 0
    assert univ["gene_symbol"].isna().sum() == 0
    assert "CPEB4" in set(univ["gene_symbol"])
    assert "asd_all_logFC" in univ.columns and "scz_cmc_logFC" in univ.columns and "is_int17_scz_hc" in univ.columns

    print("ALL STEP 1 DATA INTEGRITY CHECKS PASSED.")


if __name__ == "__main__":
    run_checks()
