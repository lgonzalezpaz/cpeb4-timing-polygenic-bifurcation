"""Automated mathematical & reproducibility tests for Scale 1 (Eqs. 1-6) and
Scales 2-3 Multiscale CTL Model, Sensitivity, Birth Cohort & In Silico Trials (Eqs. 7-16).

Run with:
    python -m unittest tests/test_math_reproducibility.py -v
"""

from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

WORKSPACE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE / "src"))

_spec = importlib.util.spec_from_file_location(
    "biophysical_calibration", WORKSPACE / "src" / "03_biophysical_calibration.py"
)
bc = importlib.util.module_from_spec(_spec)
assert _spec is not None and _spec.loader is not None
_spec.loader.exec_module(bc)

_spec_ctl = importlib.util.spec_from_file_location(
    "multiscale_ctl_model", WORKSPACE / "src" / "04_multiscale_ctl_model.py"
)
ctl = importlib.util.module_from_spec(_spec_ctl)
assert _spec_ctl is not None and _spec_ctl.loader is not None
_spec_ctl.loader.exec_module(ctl)

_spec_sens = importlib.util.spec_from_file_location(
    "sensitivity_and_cohort", WORKSPACE / "src" / "05_sensitivity_and_cohort.py"
)
sens = importlib.util.module_from_spec(_spec_sens)
assert _spec_sens is not None and _spec_sens.loader is not None
_spec_sens.loader.exec_module(sens)

RESULTS_DIR = WORKSPACE / "results"


class TestScale1BiophysicsAndKinetics(unittest.TestCase):
    """Verify Scale 1 calibration outputs, model selection, theorems, and RK45 vs Radau convergence."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.calib_path = RESULTS_DIR / "biophysical_calibration.json"
        cls.ms_path = RESULTS_DIR / "biophysical_model_selection.csv"
        cls.boot_path = RESULTS_DIR / "biophysical_bootstrap_samples.csv"
        assert cls.calib_path.exists(), "Run src/03_biophysical_calibration.py first."
        cls.calib = json.loads(cls.calib_path.read_text(encoding="utf-8"))
        cls.df_ms = pd.read_csv(cls.ms_path)
        cls.df_boot = pd.read_csv(cls.boot_path)

    def test_output_artifacts_and_seeding(self) -> None:
        self.assertEqual(self.calib["metadata"]["seed"], 20261119)
        self.assertEqual(len(self.df_boot), 4 * 5000)
        self.assertFalse(self.df_boot.isna().any().any())
        self.assertEqual(
            set(self.df_ms["dataset"]),
            {"pooled_all", "nCPEB4_DL488", "nCPEB4d4_AF647", "fov_paired_mean"},
        )
        self.assertEqual(len(self.df_ms), 16)

        p_pooled = self.calib["eq2_cooperative_hill_aggregation"]["pooled_all"]["parameters"]
        boot_pooled = self.df_boot[self.df_boot["dataset"] == "pooled_all"]
        q25, q975 = np.percentile(boot_pooled["chi_c"].to_numpy(), [2.5, 97.5])
        self.assertAlmostEqual(q25, p_pooled["chi_c"]["ci95"][0], places=10)
        self.assertAlmostEqual(q975, p_pooled["chi_c"]["ci95"][1], places=10)

        from scipy.optimize import least_squares

        fig4 = pd.read_csv(WORKSPACE / "data" / "processed" / "gc25_fig4_tc_and_agg.csv")
        f4d = fig4[fig4["source_sheet"] == "Fig.4d"]
        grp = f4d.groupby("chi_delta4")["value"].agg(["mean", "count"]).reset_index()
        chi_u = grp["chi_delta4"].to_numpy(dtype=float)
        sqrt_n_u = np.sqrt(grp["count"].to_numpy(dtype=float))
        vals_by_chi = [f4d[f4d["chi_delta4"] == c]["value"].to_numpy(dtype=float) for c in chi_u]
        p_m4 = np.array([
            p_pooled["A_min"]["point_estimate"],
            p_pooled["A_max"]["point_estimate"],
            p_pooled["chi_c"]["point_estimate"],
            p_pooled["n_H"]["point_estimate"],
        ])
        rng = np.random.default_rng(20261119)
        for b in range(20):
            ybar = np.array([v[rng.integers(0, len(v), size=len(v))].mean() for v in vals_by_chi])
            res = least_squares(
                lambda th: sqrt_n_u * (bc.m4_hill(chi_u, *th) - ybar),
                x0=p_m4,
                jac=lambda th: sqrt_n_u[:, None] * bc.jac_m4(chi_u, *th),
                bounds=([0.0, 5.0, 0.05, 1.0], [15.0, 60.0, 0.95, 200.0]),
                method="trf",
                ftol=1e-9,
                xtol=1e-9,
                gtol=1e-9,
                max_nfev=250,
            )
            self.assertAlmostEqual(float(res.x[2]), float(boot_pooled.iloc[b]["chi_c"]), places=10)
            self.assertAlmostEqual(float(res.x[3]), float(boot_pooled.iloc[b]["n_H"]), places=8)

    def test_eq1_protonation_and_buffering_identities(self) -> None:
        pka = self.calib["eq1_protonation_and_heterotypic_buffering"]["nmr_his_pka_fig2d"]["mean"]
        self.assertAlmostEqual(float(bc.eq1_his_protonation_fraction(pka, pka)), 0.5, places=12)
        self.assertGreater(float(bc.eq1_his_protonation_fraction(6.0, pka)), 0.90)
        self.assertLess(float(bc.eq1_his_protonation_fraction(8.0, pka)), 0.15)

        chis = np.linspace(0.0, 1.0, 21)
        h_tight = bc.eq1_unbuffered_hclust_fraction(chis, kappa_het=0.0)
        h_small = bc.eq1_unbuffered_hclust_fraction(chis, kappa_het=1e-8)
        self.assertTrue(np.allclose(h_tight, chis, atol=1e-12))
        self.assertTrue(np.all(h_small >= 0.0) and np.all(h_small <= 1.0))
        self.assertLess(float(np.max(np.abs(h_small - h_tight))), 1e-3)

    def test_eq2_and_eq3_model_selection_and_ph_validation(self) -> None:
        for ds in ["pooled_all", "nCPEB4_DL488", "nCPEB4d4_AF647", "fov_paired_mean"]:
            sub = self.df_ms[self.df_ms["dataset"] == ds].set_index("model_id")
            self.assertEqual(sub["aic"].idxmin(), "M4_CooperativeHill")
            self.assertEqual(sub["bic"].idxmin(), "M4_CooperativeHill")
            self.assertEqual(sub["loo_cv_rmse"].idxmin(), "M4_CooperativeHill")
            self.assertEqual(sub["loro_cv_rmse"].idxmin(), "M4_CooperativeHill")
            self.assertEqual(sub["loco_cv_rmse"].idxmin(), "M4_CooperativeHill")
            other_delta_aic = sub.drop("M4_CooperativeHill")["delta_aic"].min()
            self.assertGreater(float(other_delta_aic), 30.0)

        val = self.calib["empirical_kinetics_and_in_vivo_bounds"]["edfig6e_ph_and_time"][
            "zero_free_shape_eq1_eq2_day1_validation"
        ]
        self.assertGreater(val["chi_c_predicted_pH6"], 1.0)
        self.assertGreater(val["r2_cross_ph"], 0.80)
        self.assertLess(val["p_value"], 1e-20)

        tc_fit = self.calib["eq3_linear_cloud_point_thermodynamics"]["fig4c_linear_fit"]
        self.assertGreater(tc_fit["r2_condition_mean"], 0.98)
        self.assertTrue(tc_fit["quadratic_nonlinearity_test"]["is_strictly_linear"])

    def test_eq4_to_eq6_simplex_qss_and_mobius_hill_theorems(self) -> None:
        p = self.calib["eq4_to_eq6_ode_parameters_and_provenance"]["parameters"]
        nv = self.calib["eq4_to_eq6_analytical_and_numerical_verification"]["numerical_verification"]

        self.assertTrue(nv["all_tolerances_passed"])
        self.assertLess(nv["max_abs_diff_rk45_vs_radau_autonomous"], 1e-8)
        self.assertLess(nv["max_abs_diff_rk45_vs_radau_nonautonomous"], 1e-8)
        self.assertLess(nv["max_abs_err_rk45_vs_analytical_qss"], 1e-8)
        self.assertLess(nv["max_abs_err_radau_vs_analytical_qss"], 1e-8)

        for d_val in [0.0, 0.15, 0.5, 1.0, 2.0]:
            for chi_val in [0.0, 0.30, 0.38, 0.45, 1.0]:
                q = bc.eq4_to_eq6_qss(chi_val, d_val, p)
                rhs = bc._ode_rhs(0.0, np.array([q["L_star"], q["S_star"]]), chi_val, lambda _t, d=d_val: d, p)
                self.assertLess(abs(rhs[0]), 1e-13)
                self.assertLess(abs(rhs[1]), 1e-13)
                self.assertGreaterEqual(q["L_star"], 0.0)
                self.assertGreaterEqual(q["S_star"], 0.0)
                self.assertLessEqual(q["L_star"] + q["S_star"], 1.0 + 1e-15)
                self.assertGreaterEqual(q["Phi_star"], 0.0)
                self.assertLessEqual(q["Phi_star"], 1.0)
                self.assertLess(q["jacobian_trace"], 0.0)
                self.assertGreater(q["jacobian_det"], 0.0)

        for d_val in [0.15, 0.5, 1.0]:
            th = bc.eq4_to_eq6_critical_thresholds(d_val, p, phi_crit=0.50)
            q_at_eff = bc.eq4_to_eq6_qss(th["chi_c_eff_Phi_half"], d_val, p)
            self.assertAlmostEqual(q_at_eff["Phi_star"], 0.50, places=12)

            for chi_val in [0.1, 0.3, 0.38, 0.45, 0.8]:
                s_qss = bc.eq4_to_eq6_qss(chi_val, d_val, p)["S_star"]
                s_mobius = th["S_max_at_D"] * float(
                    bc.hill_activation(np.array([chi_val]), th["chi_half_lock"], p["n_H"])[0]
                )
                self.assertAlmostEqual(s_qss, s_mobius, places=12)

        th_w1 = bc.eq4_to_eq6_critical_thresholds(p["D_act_W1_childhood"], p)
        th_w2 = bc.eq4_to_eq6_critical_thresholds(p["D_act_W2_adolescent_PFC"], p)
        self.assertLess(th_w2["chi_c_eff_Phi_half"], 0.38)
        self.assertGreater(th_w1["chi_c_eff_Phi_half"], 0.38)

        reg = self.calib["eq4_to_eq6_analytical_and_numerical_verification"]["benchmark_qss_states"]
        self.assertGreater(reg["chi_0.30"]["W1_childhood"]["Phi_star"], 0.85)
        self.assertGreater(reg["chi_0.30"]["W2_adolescent_PFC"]["Phi_star"], 0.85)
        self.assertGreater(reg["chi_0.38"]["W1_childhood"]["Phi_star"], 0.50)
        self.assertLess(reg["chi_0.38"]["W2_adolescent_PFC"]["Phi_star"], 0.50)
        self.assertLess(reg["chi_0.45"]["W1_childhood"]["Phi_star"], 0.50)

    def test_live_ode_solver_convergence_and_simplex(self) -> None:
        from scipy.integrate import solve_ivp
        from scipy.special import expit

        p = self.calib["eq4_to_eq6_ode_parameters_and_provenance"]["parameters"]
        d_w1, d_w2 = p["D_act_W1_childhood"], p["D_act_W2_adolescent_PFC"]
        d_ramp = lambda t: d_w1 + (d_w2 - d_w1) * float(expit((t - 60.0) / 10.0))
        t_eval = np.linspace(0.0, 180.0, 361)

        rhs, jac = bc._make_ode_system(0.38, d_ramp, p)
        sol_rk = solve_ivp(rhs, (0.0, 180.0), [0.85, 0.0], method="RK45", t_eval=t_eval, rtol=1e-10, atol=1e-12)
        sol_rad = solve_ivp(rhs, (0.0, 180.0), [0.85, 0.0], method="Radau", jac=jac, t_eval=t_eval, rtol=1e-10, atol=1e-12)
        self.assertLess(float(np.max(np.abs(sol_rk.y - sol_rad.y))), 1e-8)

        rhs_c, jac_c = bc._make_ode_system(0.45, lambda _t: d_w2, p)
        sol_corner = solve_ivp(rhs_c, (0.0, 120.0), [0.0, 1.0], method="Radau", jac=jac_c, t_eval=np.linspace(0.0, 120.0, 241), rtol=1e-10, atol=1e-12)
        self.assertGreaterEqual(float(np.min(sol_corner.y)), -1e-12)
        self.assertLessEqual(float(np.max(np.sum(sol_corner.y, axis=0))), 1.0 + 1e-12)


class TestScale2And3MultiscaleCTL(unittest.TestCase):
    """Verify Eqs. (7)-(16), Huttenlocher landmarks, RK45 vs Radau, Sobol/PRCC, cohort, mouse/SSO, & master JSON."""

    @classmethod
    def setUpClass(cls) -> None:
        required = [
            "ctl_phase_diagrams.json",
            "ctl_trajectories.csv",
            "phase_grid_tau_chi.csv",
            "phase_grid_prs_chi.csv",
            "model_comparison.csv",
            "sensitivity_sobol.csv",
            "sensitivity_prcc.csv",
            "cohort_validation.csv",
            "cohort_rg_sweep.csv",
            "insilico_mouse_predictions.csv",
            "sso_rescue_curves.csv",
            "master_metrics.json",
        ]
        for fn in required:
            p = RESULTS_DIR / fn
            assert p.exists() and p.stat().st_size > 0, f"Missing or empty output: {p}"

        def _strict_no_nan(s: str) -> None:
            raise ValueError(f"Invalid JSON constant: {s}")

        cls.ctl_pd = json.loads(
            (RESULTS_DIR / "ctl_phase_diagrams.json").read_text(encoding="utf-8"),
            parse_constant=_strict_no_nan,
        )
        cls.master = json.loads(
            (RESULTS_DIR / "master_metrics.json").read_text(encoding="utf-8"),
            parse_constant=_strict_no_nan,
        )
        cls.df_traj = pd.read_csv(RESULTS_DIR / "ctl_trajectories.csv")
        cls.df_tau_chi = pd.read_csv(RESULTS_DIR / "phase_grid_tau_chi.csv")
        cls.df_prs_chi = pd.read_csv(RESULTS_DIR / "phase_grid_prs_chi.csv")
        cls.df_mc = pd.read_csv(RESULTS_DIR / "model_comparison.csv")
        cls.df_sobol = pd.read_csv(RESULTS_DIR / "sensitivity_sobol.csv")
        cls.df_prcc = pd.read_csv(RESULTS_DIR / "sensitivity_prcc.csv")
        cls.df_cohort = pd.read_csv(RESULTS_DIR / "cohort_validation.csv")
        cls.df_rg = pd.read_csv(RESULTS_DIR / "cohort_rg_sweep.csv")
        cls.df_mouse = pd.read_csv(RESULTS_DIR / "insilico_mouse_predictions.csv")
        cls.df_sso = pd.read_csv(RESULTS_DIR / "sso_rescue_curves.csv")

    def test_huttenlocher_landmarks_and_multiscale_convergence(self) -> None:
        lm = self.ctl_pd["huttenlocher_petanjek_control_landmarks"]
        self.assertGreaterEqual(lm["Ns_birth_0yr"], 0.78)
        self.assertLessEqual(lm["Ns_birth_0yr"], 0.85)
        self.assertGreaterEqual(lm["Ns_childhood_peak"], 1.45)
        self.assertLessEqual(lm["Ns_childhood_peak"], 1.52)
        self.assertGreaterEqual(lm["t_peak_yr"], 1.8)
        self.assertLessEqual(lm["t_peak_yr"], 3.0)
        self.assertGreaterEqual(lm["adolescent_pruning_decline_pct"], 35.0)
        self.assertLessEqual(lm["adolescent_pruning_decline_pct"], 42.0)
        self.assertGreaterEqual(lm["Ns_adult_30yr"], 0.95)
        self.assertLessEqual(lm["Ns_adult_30yr"], 1.03)

        nv = self.ctl_pd["numerical_verification"]
        self.assertTrue(nv["all_tolerances_passed"])
        self.assertLess(nv["max_abs_diff_rk45_vs_radau_state"], 1e-7)
        self.assertLess(nv["max_simplex_violation"], 1e-12)
        self.assertEqual(nv["max_Ns_negativity_violation"], 0.0)
        self.assertLess(nv["max_qss_vs_ode_Ns_diff"], 5e-3)

        # Trajectory invariance across all benchmark scenarios in ctl_trajectories.csv
        self.assertFalse(self.df_traj.isna().any().any())
        self.assertGreaterEqual(float(self.df_traj["L"].min()), 0.0)
        self.assertGreaterEqual(float(self.df_traj["S"].min()), 0.0)
        self.assertLessEqual(float((self.df_traj["L"] + self.df_traj["S"]).max()), 1.0 + 1e-12)
        self.assertGreaterEqual(float(self.df_traj["Phi"].min()), 0.0)
        self.assertLessEqual(float(self.df_traj["Phi"].max()), 1.0 + 1e-12)
        self.assertGreaterEqual(float(self.df_traj["Ns"].min()), 0.0)

    def test_live_coupled_multiscale_rk45_vs_radau_and_positivity(self) -> None:
        ctx = ctl.build_ctl_context()
        chi_fn = lambda t: ctl.eq14_chi_induction(t, 12.0, 0.08)
        sol_rad = ctl.solve_coupled_ode(chi_fn, 0.0, 1.5, ctx, method="Radau", rtol=1e-10, atol=1e-12)
        sol_rk = ctl.solve_coupled_ode(chi_fn, 0.0, 1.5, ctx, method="RK45", rtol=1e-10, atol=1e-12)
        max_diff = max(
            float(np.max(np.abs(sol_rk["L"] - sol_rad["L"]))),
            float(np.max(np.abs(sol_rk["S"] - sol_rad["S"]))),
            float(np.max(np.abs(sol_rk["Ns"] - sol_rad["Ns"]))),
        )
        self.assertLess(max_diff, 1e-7)
        self.assertGreaterEqual(float(np.min(sol_rad["Ns"])), 0.0)

        # Extreme ASD-PRS + severe splicing stress must preserve Ns >= 0 and simplex invariance
        sol_ext = ctl.solve_coupled_ode(lambda _t: 0.90, 4.0, 4.0, ctx, method="Radau")
        self.assertGreaterEqual(float(np.min(sol_ext["Ns"])), 0.0)
        self.assertGreaterEqual(float(np.min(sol_ext["L"])), -1e-12)
        self.assertGreaterEqual(float(np.min(sol_ext["S"])), -1e-12)
        self.assertLessEqual(float(np.max(sol_ext["L"] + sol_ext["S"])), 1.0 + 1e-12)

    def test_eq8_to_eq16_identities_phase_regimes_and_sso_monotonicity(self) -> None:
        # Eq. (9) bounded amplification
        p_vals = np.linspace(-10.0, 10.0, 41)
        g_vals = ctl.eq9_polygenic_amplification(p_vals, gamma_d=0.45, c_p=3.0)
        self.assertAlmostEqual(float(ctl.eq9_polygenic_amplification(0.0, 0.45, 3.0)), 1.0, places=14)
        self.assertTrue(np.all(g_vals > np.exp(-0.45 * 3.0)))
        self.assertTrue(np.all(g_vals < np.exp(0.45 * 3.0)))
        self.assertTrue(np.all(np.diff(g_vals) > 0.0))

        # Eq. (12)-(13) Psi bounds & all 4 regimes represented in phase diagrams
        self.assertTrue(np.all((self.df_tau_chi["Psi"] >= -1.0) & (self.df_tau_chi["Psi"] <= 1.0)))
        self.assertTrue(np.all((self.df_prs_chi["Psi"] >= -1.0) & (self.df_prs_chi["Psi"] <= 1.0)))
        self.assertAlmostEqual(ctl.eq13_phenotypic_bias_index(1.2, 1.2), 0.0, places=12)
        self.assertAlmostEqual(ctl.eq13_phenotypic_bias_index(0.0, 1.5), 1.0, places=12)
        self.assertAlmostEqual(ctl.eq13_phenotypic_bias_index(1.5, 0.0), -1.0, places=12)

        sens_regimes = set(self.df_tau_chi[self.df_tau_chi["background"] == "Sensitized_PRS"]["regime"])
        self.assertEqual(sens_regimes, {"Resilient", "ASD-only", "SCZ-only", "Comorbid"})
        shared_regimes = set(self.df_prs_chi[self.df_prs_chi["slice_name"] == "SharedRisk_Mean0.75"]["regime"])
        self.assertEqual(shared_regimes, {"Resilient", "ASD-only", "SCZ-only", "Comorbid"})

        # Eq. (15)-(16) SSO monotonicity in tau_rx and d_SSO + window divergence
        asd_d1 = self.df_sso[(self.df_sso["profile"] == "ASD_Severe_0.45_ASDPRS") & (self.df_sso["d_SSO"] == 1.0)].sort_values("tau_rx_yr")
        scz_d1 = self.df_sso[(self.df_sso["profile"] == "SCZ_Subthreshold_0.38_SCZPRS") & (self.df_sso["d_SSO"] == 1.0)].sort_values("tau_rx_yr")
        self.assertTrue(np.all(np.diff(asd_d1["R_ASD"].to_numpy()) <= 1e-12))
        self.assertTrue(np.all(np.diff(scz_d1["R_SCZ"].to_numpy()) <= 1e-12))
        self.assertLess(float(asd_d1[asd_d1["tau_rx_yr"] == 6.0]["R_ASD"].iloc[0]), 0.15)
        self.assertGreater(float(scz_d1[scz_d1["tau_rx_yr"] == 14.0]["R_SCZ"].iloc[0]), 0.80)

        # Dose monotonicity at fixed tau_rx = 0.5 yr for ASD and tau_rx = 14.0 yr for SCZ
        asd_t05 = self.df_sso[(self.df_sso["profile"] == "ASD_Severe_0.45_ASDPRS") & (self.df_sso["tau_rx_yr"] == 0.5)].sort_values("d_SSO")
        scz_t14 = self.df_sso[(self.df_sso["profile"] == "SCZ_Subthreshold_0.38_SCZPRS") & (self.df_sso["tau_rx_yr"] == 14.0)].sort_values("d_SSO")
        self.assertTrue(np.all(np.diff(asd_t05["R_ASD"].to_numpy()) >= 0.0))
        self.assertTrue(np.all(np.diff(scz_t14["R_SCZ"].to_numpy()) >= 0.0))

    def test_nested_model_comparison_and_global_sensitivity(self) -> None:
        self.assertEqual(self.df_mc.loc[self.df_mc["aic"].idxmin(), "model_id"], "H_full_Multiscale_CTL")
        self.assertEqual(int(self.df_mc.set_index("model_id").loc["H_full_Multiscale_CTL", "n_benchmarks_passed"]), 5)
        self.assertAlmostEqual(float(self.df_mc["akaike_weight"].sum()), 1.0, places=10)

        # Sobol bounds & CIs
        self.assertFalse(self.df_sobol.isna().any().any())
        for out_m in ["chi_c_eff_W2", "Psi"]:
            sub = self.df_sobol[self.df_sobol["output_metric"] == out_m]
            self.assertTrue(np.all((sub["S_Ti"] >= 0.0) & (sub["S_Ti"] <= 1.0)))
            self.assertTrue(np.all(sub["S_i"] <= sub["S_Ti"] + 0.05))
            self.assertTrue(np.all(sub["S_Ti_ci95_low"] <= sub["S_Ti_ci95_high"]))
            self.assertGreaterEqual(float(sub["S_Ti"].sum()), 0.99)

        # LHS-PRCC bounds & exact P-values
        self.assertFalse(self.df_prcc.isna().any().any())
        self.assertTrue(np.all((self.df_prcc["prcc"] >= -1.0) & (self.df_prcc["prcc"] <= 1.0)))
        self.assertTrue(np.all((self.df_prcc["p_value"] >= 0.0) & (self.df_prcc["p_value"] <= 1.0)))

    def test_birth_cohort_validation_and_deterministic_reproducibility(self) -> None:
        c_all = self.df_cohort.set_index("group")
        prev_asd = float(c_all.loc["ASD_all", "prevalence_pct"])
        prev_scz = float(c_all.loc["SCZ_all", "prevalence_pct"])
        self.assertAlmostEqual(prev_asd, 1.80, delta=0.05)
        self.assertAlmostEqual(prev_scz, 0.85, delta=0.05)

        comorb_or = float(c_all.loc["All", "emergent_comorbid_OR"])
        self.assertGreaterEqual(comorb_or, 2.08)
        self.assertLessEqual(comorb_or, 6.05)

        onset_asd = float(c_all.loc["All", "emergent_onset_ASD_median_yr"])
        onset_scz = float(c_all.loc["All", "emergent_onset_SCZ_median_yr"])
        self.assertGreaterEqual(onset_asd, 2.5)
        self.assertLessEqual(onset_asd, 6.5)
        self.assertGreaterEqual(onset_scz, 19.0)
        self.assertLessEqual(onset_scz, 25.5)

        chi_ctrl = float(c_all.loc["Resilient", "chi_W1_mean"])
        chi_asd = float(c_all.loc["ASD_all", "chi_W1_mean"])
        chi_scz = float(c_all.loc["SCZ_all", "chi_W2_mean"])
        self.assertGreater(chi_asd, chi_scz)
        self.assertGreater(chi_scz, chi_ctrl)
        self.assertGreaterEqual(chi_asd, 0.38)
        self.assertLessEqual(chi_asd, 0.45)
        self.assertGreaterEqual(chi_scz, 0.33)
        self.assertLessEqual(chi_scz, 0.38)

        # r_G sweep monotonicity
        df_rg_s = self.df_rg.sort_values("r_G")
        self.assertTrue(np.all(np.diff(df_rg_s["comorbid_OR"].to_numpy()) > 0.0))
        self.assertTrue(bool(df_rg_s["within_zheng2018_ci95"].all()))

        # Mouse trial 18 arms & power bounds
        self.assertEqual(len(self.df_mouse), 18)
        self.assertFalse(self.df_mouse.isna().any().any())
        self.assertTrue(np.all(self.df_mouse["n_per_group_ASD_90pct"] >= self.df_mouse["n_per_group_ASD_80pct"]))
        self.assertTrue(np.all(self.df_mouse["n_per_group_SCZ_90pct"] >= self.df_mouse["n_per_group_SCZ_80pct"]))

        # Live deterministic reproducibility of birth-cohort generator
        ctx = ctl.build_ctl_context()
        lat1 = sens._draw_cohort_latent_inputs(1000, ctx["t_grid"], seed=20261119)
        lat2 = sens._draw_cohort_latent_inputs(1000, ctx["t_grid"], seed=20261119)
        self.assertTrue(np.array_equal(lat1["z1"], lat2["z1"]))
        self.assertTrue(np.array_equal(lat1["chi_mat"], lat2["chi_mat"]))

    def test_master_metrics_integrity(self) -> None:
        self.assertEqual(self.master["metadata"]["seed"], 20261119)
        for sec in [
            "step1_data_and_sequence",
            "step2_bioinformatics",
            "step3a_scale1_biophysics",
            "step3b_scale2_3_multiscale_ctl",
            "step4_references",
        ]:
            self.assertIn(sec, self.master)
        self.assertEqual(self.master["step4_references"]["verified_count"], 62)
        self.assertTrue(
            self.master["step3b_scale2_3_multiscale_ctl"]["multiscale_numerical_verification"]["all_tolerances_passed"]
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
